---
name: substack-post-drafting
description: Drafts Substack posts in Patrick's voice.
version: 0.1.0
author: Hermes
license: MIT
metadata:
  hermes:
    tags: [Writing, Substack, Voice, Drafting]
---

# Substack Drafting in Patrick's Voice

Drafts Substack posts that sound like Patrick: conversational first-person narrative that starts with a personal moment, blends technical depth with dry wit, and lands on actionable takeaways. Not a replacement for research — the agent gathers sources with `web_extract`/`web_search`, then this skill shapes the prose. Does not publish to Substack; it produces a draft you edit and publish yourself.

## When to Use

- "Draft a Substack post about X in my voice"
- "Turn these notes into a Flotsam & Jetsom post"
- "Rewrite this technical finding as a substack post"
- "I want to write about [topic] but make it sound like my stuff"
- "Convert this LinkedIn text into a proper Substack draft"

## Prerequisites

- Your two existing posts: "When morning coffee becomes a security investigation..." and "They're paving over the moats and building superhighways..." (both at `https://prasta.substack.com/`, fetch with `web_extract`)
- Access to `web_extract` / `web_search` for sourcing technical claims
- Substack account for final publishing (this skill drafts; you edit and hit publish)

## How to Run

Load this skill, then pass the topic or raw notes. The agent:

1. Re-reads your two posts via `web_extract` on `https://prasta.substack.com/`
2. Notes the voice pattern for this piece (see Quick Reference)
3. Writes a draft using the structure below
4. Verifies the draft matches your voice

```
skill_view(name="substack-post-drafting")
draft_substack_post(topic="the real cost of agentic coding assistants", tone="investigative")
```

## Quick Reference

**Voice markers to hit:**
- Opens on a personal moment ("coffee in hand, dog at my feet", "on my personal machine")
- Alternate title: `### Alternate Title: [a sly PSA / confession / framing]`
- Casual asides: parenthetical links, emoji-free wit, inline footnotes
- One-liner verdicts on the tech: "48 hours. Not months. Two days."
- Dry signposting: "No Biggie.", "Yada yada.", "I'm choosing to believe that's a bug"
- Tech shorthand without apology: CLI commands in backticks, tags at the bottom
- Ends with a list of takeaways or habits (bulleted, 3–4 items)
- Tagline: "musing for my own amusement, and hopefully yours too."

**Structure:**
1. Hook (personal anecdote or discovery moment)
2. "Then I saw / I found / it turned out" — the pivot to finding
3. Technical explanation (the meat — CLI commands, API keys, configs)
4. "To be clear:" — a clarifying note that defuses alarmism
5. Actionable fix (commands to run, toggles to flip)
6. "The broader reminder" — the general takeaway
7. List of habits / what to keep in mind
8. Sign-off: optional cultural reference, sometimes with a link

## Procedure

**Step 1 — Map your voice from the two posts.**

| Element | "Coffee" post | "Moats" post |
|---|---|---|
| Opening | "I went to delete..." on his personal machine | Morning routine ("coffee in hand, dog at my feet") |
| Tone | Investigative, slightly alarmed but not panicked | Contemplative, market-observer vibe |
| Tech depth | Deep CLI config, AWS data paths | Market timing, iteration velocity |
| Takeaway format | Numbered list + "Read what tools add to..." | Single metaphor: "speed-to-market isn't a moat" |
| Sign-off | GI JOE PSA reference | Dog wants to go outside 🐾 |

**Step 2 — Gather sources.**

Use `web_extract` and `web_search` to verify technical claims before writing. Don't make up specs, API names, or command syntax — if you can't link it, don't state it.

**Step 3 — Write the draft.**

Follow this structure (adjust tone per the row above):

```
# [Title that sounds like a headline from a tech blog you half-trust]

### Alternate Title: [A sly framing device — PSA, confession, or hot-take setup]

[Personal moment that led to the discovery.]

[The pivot: "Then I saw..." / "This morning made it visceral." / "What I found..."]

[Technical explanation: 2-3 paragraphs of real meat. CLI commands in backticks,
 config snippets in code blocks, inline links to docs.]

[Clarification: "To be clear: this isn't X, and nothing was hidden." — defuses
 the reader's panic without soft-pedaling the real issue.]

[Actionable fix: exact commands to run, toggles to flip, links to settings UI.]

[Quirk note: one curious thing that surprised you, worth flagging on your own
 machine. Always phrased as "worth checking your own toggles for:"]

[Transition to broader takeaway: "The broader reminder is a trade we make
 constantly without noticing:" or similar.]

[Takeaway list: 3-5 bullets of habits or principles.]

[Sign-off: brief, human. A dog, a cold coffee, a cultural reference with a link.]
```

**Step 4 — Apply voice polish.**

Read the draft back. Check:
- [ ] Could Patrick have genuinely written this while drinking coffee and watching his dog?
- [ ] Does every technical claim have a source or a caveat?
- [ ] Is there exactly one dry wit aside (not more)?
- [ ] Does it end on a human moment, not a call-to-action to subscribe?
- [ ] Tags at the bottom in `#Tag1 #Tag2 #Tag3` format

## Pitfalls

- Don't overdo the wit — one good aside per post, not three.
- Don't editorialize about "evil corporations" — the alarmism is always undercut.
- Don't pad with "as we all know" — Patrick assumes competence in the reader.
- Don't end with "Subscribe for more" — let the post breathe, the footer already prompts.
- Your LinkedIn posts are shorter and more declarative; Substack drafts go deeper and slower.

## Verification

Run the draft through this self-check:

```bash
# Does it scan like existing posts?
# Compare draft word count + read-time estimate
wc -w draft.md
```

Then ask yourself: would this land in the same thread as the Kiro CLI and kickbacks.ai posts? If yes, it's yours. If it reads like a Medium post or a press release, rewrite the opening hook and the takeaway list.

## Templates

The following template is available at `templates/post-outline.md` (load via `skill_view`). It contains fill-in-the-blanks for each structural section above with your voice already baked into the phrasing suggestions.
