# Substack Post Outline (Patrick's Voice)

Fill each section. The phrasing suggestions are in your voice — tweak liberally, but keep the structure.

---

## Title

[Make it sound like a headline from a tech blog you half-trust. Not clickbait, but not boring. Something that tells the reader exactly what they'll find.]

### Alternate Title: [A sly PSA / confession / framing device]

---

## Opening (Personal Moment)

> [Start with a personal anecdote. Something you were doing that led to the discovery: "I went to delete an AI tool I'd stopped using...", "This morning made it visceral — coffee in hand, dog at my feet, catching up on morning tech news...", "On my personal machine...", etc.]

---

## The Pivot

> [The moment of realization. "Then I saw...", "This morning made it visceral.", "What I found...", "I tugged on the thread to see what it actually does.", etc.]

---

## Technical Explanation

> [The meat. 2-3 paragraphs. Use:
- CLI commands in backticks
- config snippets in code blocks
- inline links to docs
- one-sentence verdicts on the tech

Do NOT make up specs or API names — link everything.]

---

## Clarification (Defuse Panic)

> [To be clear: this isn't malware, and nothing was hidden. It's a documented, signed feature that ships _on_ by default, and it's a couple of commands to turn off.]

---

## Actionable Fix

```
[Exact commands to run, toggles to flip, links to settings UI. Numbered or bulleted.]
```

---

## Quirk Note (Worth Flagging)

> [One curious thing that surprised you, worth checking your own toggles for: in the desktop app, when I switched "X" off, it flipped "Y" back on. I'm choosing to believe that's a bug...]

---

## The Broader Reminder

> [The general takeaway framed as a trade-off: "convenience for access", "speed kills moats", etc. One good metaphor.]

---

## Takeaways / Habits

- [ ] Read what tools add to your shell startup files.
- [ ] When a config line "generates" code at runtime, find out what it generates.
- [ ] Check whether a feature runs locally or sends data out, and whether "improve our models" is on by default.
- [ ] Then decide, on purpose, whether the convenience is worth it.

---

## Sign-off

> [Brief, human. A dog, a cold coffee, a cultural reference with a link. No call-to-action to subscribe — the footer prompts already.]

---

## Tags

`#Tag1 #Tag2 #Tag3`
