---
name: job-search-warm-outreach
description: 'Draft warm outreach to former customers for intro requests.'
---

# Job Search Warm Outreach

Use when Patrick needs to send a concise, Patrick-voiced outreach note to former customers or contacts after a role change, to ask for warm intros to CS/biz-dev opportunities.

## Trigger
- Patrick mentions reaching out to a former customer/contact after being let go or leaving a role
- Patrick asks for a draft note to keep someone in mind for CS/biz-dev roles
- Any "former customer outreach" or "warm intro request" ask

## Output
One short draft in Patrick's voice, plus lane/context paragraph. No fluff, no apology theater, no overselling.

## Patrick's Parameters (standing)
- Target lane: VP / Director / Head of Customer Success, plus adjacent Ops/Strategy
- Floor: $200K+ base
- Location: remote or Vermont preferred
- Style: direct, warm but not performative, assumes the recipient remembers him positively

## Three Variants

**Variant A: LinkedIn-style / Short**
> [Name] — hope [company/product] is going well. I wanted to let you know I was let go from [prior company] on [date] and am back on the market. If any startups you're talking to have a need for a CS/biz-dev person, I'd appreciate the intro. Background: 10+ years SaaS CS/BD, VP/Dir/Head lane, remote or VT preferred.

Use when: the relationship was professional but not deeply personal, LinkedIn is the likely channel, recipient is busy.

**Variant B: Warmer**
> [Name], quick heads-up: I was let go from [prior company] on [date] and am actively looking for my next CS leadership role. With [company]'s [product/market position], I imagine you're talking to a lot of startups right now — if any need a CS/biz-dev operator, keep me in mind. Happy to share a resume or just chat through where I could add leverage.

Use when: rapport was good, recipient is likely still in founder/operator circles, feels like a natural conversation.

**Variant C: Reference the prior relationship explicitly**
> [Name] — you may remember me from [prior company]. I was let go on [date] and am back in the market for VP/Dir/Head of Customer Success or adjacent ops/biz-dev roles. If any of the startups you're working with need that lane, I'd value a warm intro. Remote or VT preferred.

Use when: the prior relationship is the main hook and should be front-and-center.

## Placeholders
- [Name] — first name, unless Patrick uses a nickname
- [company] — the contact's current company
- [product/market position] — one line on what they're building if relevant
- [prior company] — e.g., Qualcomm / Edge Impulse
- [date] — month + day is enough

## Delivery Guidance
- Channel: LinkedIn message or email, whichever is Patrick's normal touchpoint with the person
- Length: one paragraph, under 150 words if possible
- CTA: either "I'd appreciate the intro" (low-friction) or "keep me in mind" (even lower friction)
- Don't attach a resume in the first message; offer to share on reply
- If Patrick is unsure which variant, default to Variant B

## After Drafting
Patrick usually sends these himself. Do not send on his behalf unless explicitly asked.

## History
Created 2026-09-10 after outreach to Raghu Gundham / Avox Lab.
