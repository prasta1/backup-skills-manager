---
name: mnemonic-multi-machine-sync
description: Multi-machine Mnemosyne memory sync to replace Syncthing.
version: 0.2.0
author: Hermes
---

# Mnemosyne Multi-Machine Sync Setup

## Problem
Two Hermes agents (Studio + MacBook) both writing to shared memory files via Syncthing causes SQLite corruption and race conditions.

## Solution Architecture
- **Studio:** Canonical memory store with `mnemosyne sync-serve` running as launchd daemon, accessible via Tailnet
- **MacBook:** Client running `mnemosyne sync` in bidirectional mode against Studio's tailnet address
- **Syncthing:** Stop syncing `~/.hermes/memories/` directory entirely

## Verified Working Commands

### Initialize surface DB (Studio, first time only)
```bash
mnemosyne sync-init --db-path ~/.hermes/mnemosyne/data/mnemosyne_surface.db --yes
```

### Start sync server (Studio)
```bash
mnemosyne sync-serve \
  --db-path ~/.hermes/mnemosyne/data/mnemosyne_surface.db \
  --host 127.0.0.1 \
  --port 8765 \
  --api-key <generated-key>
```

**Note:** Currently binds to 127.0.0.1 only. Need to figure out TLS + Tailnet exposure for remote access.

### Sync client (MacBook)
```bash
mnemosyne sync \
  --db-path ~/.hermes/mnemosyne/data/mnemosyne_surface.db \
  --remote ws://studio.taile85139.ts.net:8765 \
  --mode bidirectional \
  --api-key <same-key> \
  --interval 60
```

### Key generation
```bash
mnemosyne sync-generate-key  # Returns encryption key for --encrypt
```

## Key Files
- Surface DB: `~/.hermes/mnemosyne/data/mnemosyne_surface.db`
- Main DB: `~/.hermes/mnemosyne/data/mnemosyne.db`
- Mnemosyne config: `~/.hermes/mnemosyne/config.yaml`
- Syncthing .stignore whitelist: MEMORY.md, USER.md, SOUL.md (should be updated to exclude memory DBs)

## Open Questions / Blockers
1. **TLS setup:** sync-serve supports `--behind-tls-proxy` and cert options, but TLS over Tailnet setup is undocumented
2. **DB relationship:** How does main `mnemosyne.db` relate to the surface DB? Does writing to the main DB automatically propagate to the surface?
3. **MBP installation:** Needs Mnemosyne installed (currently absent from MacBook)
4. **launchd services:** Need to create LaunchAgents for both sync-serve (Studio) and sync client (MacBook)
5. **Auth:** sync-serve supports API key and JWT, but cross-machine key management is unclear

## Offline Behavior (Verified from source)
- **Event-log architecture:** Every memory write is a row in `memory_events` with timestamp + event_id. NOT file-based like Syncthing.
- **Offline = clean pause.** Client loop (`mnemosyne sync --interval N`) catches connection errors and retries. Never crashes.
- **Outbox:** `sync_outbox_ack` table holds unacknowledged local events until remote ACKs them. Survives restarts (SQLite).
- **Pull cursor:** `last_pull_cursor_<remote_url>` in `sync_meta` tracks sync position. Incremental, idempotent.
- **Reconnect:** On return, pushes all queued events (server dedupes by event_id), pulls everything since cursor. One clean cycle.
- **Caveat:** No exponential backoff — polls every interval regardless. 30s request timeout. Use longer interval on battery.

## Current Status
- ✅ Surface DB initialization works
- ✅ sync-serve starts and accepts connections on localhost
- ✅ sync command exists and accepts --remote/--mode/--api-key
- ✅ Offline behavior verified: clean pause, outbox persistence, cursor-based pull
- ✅ Mnemosyne Memory System v3.15.1 installed on Studio via `uv tool install mnemosyne-memory`
- ⚠️ MBP has DIFFERENT `mnemosyne` package — the flashcard app (`mnemosyne.pyqt_ui`), NOT the memory system. Installed via pipx at `~/.local/pipx/venvs/mnemosyne-proj`. No databases or config dirs exist — appears unused.
- ⚠️ MBP does NOT have `mnemosyne-memory` installed. The `uv tool install` failed due to binary name conflict with flashcard app.
- ❌ Server not accessible on Tailnet (binds to 127.0.0.1 only)
- ❌ launchd services not configured
- ❌ Main mnemosyne.db → surface DB propagation mechanism unclear
- ❌ Syncthing hermes-env folder still paused on both machines

## CORRECTION (2026-08-28)
Two separate `mnemosyne` packages exist:
- `mnemosyne-memory` (Hermes memory) — import path: `mnemosyne.cli`, has subcommands `sync`, `sync-serve`, `sync-init`
- `mnemosyne` (flashcard app) — import path: `mnemosyne.pyqt_ui`, single binary with flags

The MBP has ONLY the flashcard version. Install memory system as `uv tool install mnemosine-memory` but need to rename the binary to avoid conflict.

## References
- Mnemosyne CLI commands found: `sync`, `sync-serve`, `sync-init`, `sync-status`, `sync-generate-key`
- Mnemosyne config fields: `sync_host`, `sync_port`, `sync_remote`, `sync_key`, `sync_encrypt`, `sync_roles`
- Hermes config (wrong file, corrected here): `config.yaml → mnemosyne/config.yaml`
