---
description: Memory-layer skills — semantic memory configuration, multi-machine sync, and guardrails against disabled providers.
---