---
name: email-triage-workflow
description: Routes between clef-flash and Devstral email triage paths.
version: 1.1.0
author: Ionga
---

# Email Triage Workflow

Routes between the two live Gmail triage paths: `email-triage-clef` (clef-flash, the accurate one)
and `email-triage-agent` (plain Devstral, no gate — this is what the 7:30am cron runs).

The `email-triage-laya` path was deleted 2026-10-04. Its 421M gate lost the ground-truth
bakeoff (2026-10-03) against clef-flash:71% false-positive rate vs 17%, so it was never
really gating and has no remaining role.

## Procedure

1.  **Path Selection:** Use `email-triage-clef` for interactive runs — it is the more accurate
    gate. Use `email-triage-agent` only because the daily cron is pinned to it.
2.  **Execution:** Execute the chosen skill. Note `email-triage-clef-test` is a duplicate copy of
    `email-triage-clef`; the fixes applied this session live in the `-test` copy only.
3.  **Review:** Use the shared draft queue at `~/.hermes/email-drafts/` to review, approve,
    discard, or manually edit generated responses, regardless of which path was taken.

## Pitfalls & Lessons

*   **Pitfall:** Concurrent execution of two triage skills against the same mailbox.
    *   **Mechanism:** All paths share the `.processed_ids` file and draft queue in
        `~/.hermes/email-drafts/`. Running two simultaneously causes race conditions and
        duplicate processing.
    *   **Lesson:** Never run two triage paths against the same mailbox in one window. Pick one.

*   **Pitfall:** `always_action` rules used to leave a sendable draft behind.
    *   **Mechanism:** The rule only scrubbed `reply_to`/`reply_body` on the noise→action
        promotion path. If the model had already called the thread a `reply`, the handler
        returned the data untouched, so an alert-robot reply reached the staging queue.
        Fixed 2026-10-04 in `email-triage-clef-test`; **the other copies still carry the bug.**
    *   **Lesson:** A rule that means "never send" must scrub the send fields unconditionally,
        not only on the branch where it happens to reclassify.

*   **Pitfall:** Reasoning labels drift from the model actually serving.
    *   **Mechanism:** The clef path was ported from Laya and kept a hardcoded `"Laya: "`
        prefix in its reasoning string, so every `drafts.json` entry and TOML header
        misattributed clef-flash verdicts.
    *   **Lesson:** When porting a triage path, grep the new file for the old model's name
        before trusting any recorded output.
