---
name: email-triage-agent
description: Gmail inbox triage - classify + draft replies, staged for approval. Alternate path without the Laya model.
version: 1.0.0
author: Ionga
tags: [email, gmail, imap, himalaya, triage, draft, automation]
metadata:
  hermes:
    tags: [email, gmail, imap, himalaya, triage, draft, automation]
---

# Email Triage Agent (plain — no Laya)

## When to Use

When you want a local LLM to triage your Gmail inbox, classify each thread, and draft reply
emails that you review before sending. The agent runs Himalaya against your configured Gmail
account, uses **ms-devstral-24b** (via llama-swap) for both classification and drafting, and
stages everything as pending drafts for explicit approval.

This is the **alternate path** to `email-triage-laya`. It needs **no Laya server, no
layá_client, no BGE-M3 retrieval** — just llama-swap. Use this when Laya is down, when you
want the full 24B model judging every thread, or when you want the simplest dependency set.

## Prerequisites

- Himalaya v2 installed (`brew install himalaya`)
- Gmail App Password configured in `~/.hermes/.env` as `GMAIL_APP_PASSWORD`
- Himalaya config at `~/.config/himalaya/config.toml` with your Gmail account
- `ms-devstral-24b` model available via llama-swap `:9292` (local, MPS)
- **No Laya dependency** — this path skips the Laya pre-filter entirely

## Quick Start

```bash
# Triage unread inbox, draft replies, stage for approval
hermes chat --toolsets "email,file,terminal,skills" -q "/email-triage-agent run"

# Review staged drafts
hermes chat --toolsets "email,file,terminal,skills" -q "/email-triage-agent review"

# Send approved drafts (this triggers the send-gate)
hermes chat --toolsets "email,file,terminal,skills" -q "/email-triage-agent send"
```

## Configuration

Set the following in your Hermes profile or environment:

- `GMAIL_APP_PASSWORD` — 16-char Gmail App Password (in `~/.hermes/.env`)
- `EMAIL_TRIAGE_MODEL` — model to use (defaults to `ms-devstral-24b`)
- `EMAIL_TRIAGE_LIMIT` — max threads to process per run (default: 20)
- `EMAIL_TRIAGE_FOLDERS` — comma-separated IMAP folders to scan (default: `INBOX`)
- `EMAIL_DRAFT_DIR` — where staged drafts live (default: `~/.hermes/email-drafts`)
- `EMAIL_TRIAGE_STAGE_CLASSES` — classifications that get a draft file (default:
  `action,reply,urgent-reply`). Everything else is logged to `classified.log` instead of
  being staged.

There is no `LAYA_URL` / `LAYA_API_KEY` / `LAYA_GATE_THRESHOLD` here — that is the
`email-triage-laya` skill's config surface. This path ignores it.

## Workflow

### 1. Scan (Read)
- Himalaya lists unread envelopes from the configured Gmail account
- For each unread thread, fetches full message content via `himalaya message read`
- Extracts sender, subject, date, body text

### 2. Classify (Local LLM)
Every thread goes through `ms-devstral-24b` (temp=0.3, body truncated to 8000 chars) and is
classified as:
- **urgent-reply** — needs a reply within 24h (people you know, time-sensitive)
- **reply** — needs a reply but not urgent
- **action** — needs action but no reply (review a doc, click a link, follow up)
- **waiting** — waiting on the sender, no action needed
- **reference** — keep for reference, no action
- **noise** — newsletters, promotions, alerts (no action)

### 3. Draft (Local LLM)
For threads classified as `urgent-reply` or `reply`:
- The local model drafts a reply in Patrick's voice
- Reply preserves thread context, answers every question, states uncertainty
- Draft is saved as a file: `EMAIL_DRAFT_DIR/<timestamp>_<id>.toml`
- Drafts include: original subject, reply-to, body, classification, confidence

### 4. Stage (Approval)
- Only `action`, `reply` and `urgent-reply` threads are written as draft files
- `noise`, `reference` and `waiting` are appended to `EMAIL_DRAFT_DIR/classified.log` and
  are NOT staged — this keeps the review queue to threads a human actually needs to see
- Drafts are NOT sent automatically
- Staged drafts sit in `EMAIL_DRAFT_DIR/` as pending
- Use `/email-triage-agent review` to see pending drafts
- Use `/email-triage-agent send` to send approved drafts (requires explicit approval)

### 5. Send (Gated)
- A deterministic shell script reads staged drafts
- You must explicitly mark each draft as approved in a JSON index
- Only approved drafts are sent via `himalaya message send`
- Each sent draft is logged to `EMAIL_DRAFT_DIR/sent.log`

### 6. Interactive review (chat seat only)

Same as the Laya path: `python3 triage.py review-choices` emits `clarify` question JSON,
chunked to <=5 questions per call, passed straight to the `clarify` tool. Act on answers
with `triage.py discard <id>` / `triage.py approve <id>`. `triage.py send` is still the
sole sender. Cron cannot click buttons — keep the interactive review on the chat seat.

### Manual sender rules (rules.yaml) — how to add one

Identical semantics to `email-triage-laya`. Rules live at
`~/.hermes/email-drafts/rules.yaml` (override path with `EMAIL_TRIAGE_RULES`).

- `never_draft:` — senders that must never stage a draft. Applied as classification
  `suppressed` (not in `STAGE_CLASSES`), log-line only, reply fields emptied.
- `always_action:` — senders whose threads always stage as `action` regardless of the
  model verdict. Replies suppressed; surface as action items, not sendable mail.

**Matching** is case-insensitive substring against BOTH sender address and display name.
**Precedence:** `apply_noreply_rule()` runs first (structural), then `apply_manual_rules()`
runs LAST and wins outright. A missing rules file = no rules; a malformed file logs a
warning and continues. Verify with `python3 triage.py rules`.

### No-reply sender rule (enforced in code, not the prompt)

Same code-enforced rule as the Laya path: senders whose address matches `NOREPLY_RE`
(`no-reply`, `noreply`, `donotreply`, `do-not-reply`, `notification(s)`, `notice`, `alert`,
`automated`, `mailer`, `newsletter`, `update(s)` as a delimited token in the local part):
- `reply`/`urgent-reply` verdicts downgrade to `action` when `ALERT_HINT_RE` finds alert
  language (billing, credits, expiring, deadline, failed, verify), otherwise to `noise`.
- `reply_to`, `reply_subject`, `reply_body` are ALWAYS emptied even for non-reply classes.
- `reasoning` is prefixed with `[no-reply rule]`.
Kill switch: `EMAIL_TRIAGE_NOREPLY_RULE=0`.

## Pitfalls

- **Same draft-dir rules as the Laya skill.** `~/.hermes/email-drafts` is shared; do not
  run both skills against the same mailbox in one window or they'll race on `.processed_ids`
  and the draft queue. Pick one path per run window.
- **`.processed_ids` must be MERGED, never overwritten.** Same invariant as `email-triage-laya`.
- **Classifier silent-loss mode:** one `choices` failure degrades to `reference` at
  confidence 0.0 and lands in `classified.log`. No retry. Known and accepted.
- **Never trust a `reply` classification on a no-reply sender.** The no-reply guard strips
  those in code; trust the `[no-reply rule]` prefix in the reasoning.
- **Noise threads still get a draft file written** with empty body; the send-gate skips
  empty bodies.
- **`discard <envelope_id>` removes staged drafts; id stays in `.processed_ids`** — a
  discarded thread is not re-triaged.
- **Gmail throttling:** IMAP LIST over a large mailbox can be slow; the limit flag controls
  batch size.
- **Env var expansion:** Himalaya v2 doesn't expand `${VAR}` in config — use
  `password.command = ["sh", "-c", "echo $GMAIL_APP_PASSWORD"]`.
- **Never auto-send:** the send-gate script must be invoked explicitly.

## Verification

```bash
# Check staged drafts (only actionable threads)
ls -la ~/.hermes/email-drafts/

# Non-actionable threads: logged, not staged
tail -20 ~/.hermes/email-drafts/classified.log

# Check send log
cat ~/.hermes/email-drafts/sent.log

# Verify IMAP still working
GMAIL_APP_PASSWORD="…" himalaya envelope list -a gmail
```

## Commands

- `/email-triage-agent run` — scan inbox, classify, draft, stage
- `/email-triage-agent review` — list pending drafts with classifications
- `python3 triage.py discard <envelope_id> [...]` — delete staged drafts (false positives)
- `python3 triage.py approve <envelope_id> [...]` — mark drafts approved (sets
  `approved = true`; reversible; sends NOTHING)
- `python3 triage.py review-choices` — emit `clarify` question JSON for the staged queue
- `/email-triage-agent send` — send approved drafts via send-gate
- `/email-triage-agent test-model` — verify llama-swap + model are reachable
