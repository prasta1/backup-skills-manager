#!/usr/bin/env python3
"""
fleet_catalog.py — derive a queryable inventory of the llama-swap model fleet.

Reads config.yaml (the single source of truth), measures every GGUF on disk,
resolves group membership and capability, folds in the newest benchmark CSV
that mentions each model, and emits catalog.json + catalog.md.

Read-only with respect to the fleet. The catalog is disposable: delete it and
nothing is lost. That property is the whole point — it cannot drift, because
it is never edited by hand.

Usage:
    fleet_catalog.py                 # write catalog.json + catalog.md
    fleet_catalog.py --check         # validate only, write nothing, exit 1 on problems
    fleet_catalog.py --no-bench      # skip CSV merge
    fleet_catalog.py --strict        # treat warnings as failures
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shlex
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("error: pyyaml missing. pip3 install pyyaml")


# --------------------------------------------------------------------------
# Tokenizer map. Verified 2026-09-28 with
# llama_benchy.corpus.LightweightTokenizer.from_pretrained().
# Keep in sync with the llama-benchy-quick-bench skill's references/tokenizers.md.
# "unresolved" means the canonical repo is gated (401) and no substitute has
# been load-tested — it does NOT mean gpt2 is acceptable.
# --------------------------------------------------------------------------
TOKENIZERS = {
    "ms-devstral-24b": ("mistralai/Devstral-Small-2-24B-Instruct-2512", "verified"),
    "ms-gemma-4-26b-moe": ("google/gemma-4-26B-A4B-it", "verified"),
    "ms-gemma-4-12b": ("google/gemma-4-12B-it", "verified"),
    "ms-gemma-4-e4b": ("google/gemma-4-E4B-it", "verified"),
    "ms-glm-4.6-vision": ("zai-org/GLM-4.6V-Flash", "verified"),
    "ms-kat-coder-v2.5": ("Kwaipilot/KAT-Coder-V2.5-Dev", "verified"),
    "ms-qwen3.6-35b-a3b": ("Qwen/Qwen3.6-35B-A3B", "verified"),
    "ms-qwen3-coder-30b": ("Qwen/Qwen3-Coder-30B-A3B-Instruct", "verified"),
    "ms-qwen3-vl-8b": ("Qwen/Qwen3-VL-8B-Instruct", "verified"),
    "ms-gpt-oss-20b": ("openai/gpt-oss-20b", "verified"),
    "ms-granite-4.2-3b": ("ibm-granite/granite-4.2-3b", "verified"),
    "ms-granite-4.2-8b": ("ibm-granite/granite-4.2-8b", "verified"),
    "ms-ministral-3-3b": ("mistralai/Ministral-3-3B-Instruct-2512", "verified"),
    "ms-qwen3.5-4b-mtp": ("Qwen/Qwen3.5-4B", "verified"),
    "ms-qwen3.8-27b-swift1.5": ("Qwen/Qwen3.8-27B", "substitute"),
    "ms-qwopus3.8-27b-flash": ("Qwen/Qwen3.8-27B", "substitute"),
    "ms-nuextract3": ("Qwen/Qwen3.5-4B", "substitute"),
    "ms-muse-glimmer-30b": (None, "unresolved"),
    # Embeddings: served, but no tokenizer needed and not chat-benchmarkable.
    "ms-bge-m3-1024": (None, "n/a-embeddings"),
    "ms-bge-reranker-v2-m3": (None, "n/a-embeddings"),
}

# Quantization tokens as they appear in GGUF filenames.
QUANT_RE = re.compile(
    r"(UD-Q\d+_[A-Z0-9_]+|MXFP\d|MXFP4|Q\d+_[A-Z0-9_]+|IQ\d+_[A-Z0-9_]+|F16|F32|BF16)",
    re.IGNORECASE,
)

# Params from a filename stem, e.g. "Qwen3-Coder-30B-A3B" -> total 30, active 3.
TOTAL_B_RE = re.compile(r"(?<![\w.])(\d+(?:\.\d+)?)B(?![\w])", re.IGNORECASE)
ACTIVE_B_RE = re.compile(r"[AE](\d+(?:\.\d+)?)B(?![\w])", re.IGNORECASE)

# Description prose that states active params, e.g. "MoE 3.6B active".
DESC_ACTIVE_RE = re.compile(
    r"(?:MoE|A3B|active)[^.;]{0,24}?(\d+(?:\.\d+)?)\s*B\s*active", re.IGNORECASE
)
DESC_SIZE_RE = re.compile(r"\((\d+(?:\.\d+)?)\s*GB\)", re.IGNORECASE)

CAPABILITY_ORDER = ["embedding", "extraction", "code", "vision", "general"]

# Explicit overrides where the id alone is not enough. Deliberately short:
# anything derivable from the id is derived, so these stay auditable. The
# free-text description is NOT consulted — see infer_capabilities.
CAPABILITY_OVERRIDES = {
    "ms-nuextract3": "extraction",
}
ARCH_OVERRIDES = {
    "ms-gemma-4-e4b": "moe",
    "ms-gemma-4-26b-moe": "moe",
    "ms-gpt-oss-20b": "moe",
    "ms-qwen3.6-35b-a3b": "moe",
    "ms-qwen3.5-4b-mtp": "moe",
    "ms-qwopus3.8-27b-flash": "moe",
    "ms-muse-glimmer-30b": "moe",
}


def parse_cmd(cmd: str) -> dict:
    """Pull the flags we care about out of a llama-server command line."""
    if not cmd:
        return {}
    # The config stores this as a folded/quoted multi-line string; shlex with
    # posix=True handles the single-quoted wrapper. ${PORT} etc are macros
    # that expand at llama-swap load time and are irrelevant here.
    try:
        toks = shlex.split(cmd, posix=True)
    except ValueError:
        toks = cmd.split()

    out: dict = {}
    i = 0
    while i < len(toks):
        t = toks[i]
        if t in ("--model", "--mmproj", "--ctx-size", "--parallel", "--spec-type",
                 "--spec-draft-n-max", "-md", "--n-gpu-layers", "--batch-size"):
            if i + 1 < len(toks):
                out[t] = toks[i + 1]
                i += 2
                continue
        i += 1
    return out


def file_size_gb(p: str | None) -> float | None:
    if not p:
        return None
    try:
        return round(os.path.getsize(p) / (1024 ** 3), 2)
    except OSError:
        return None


def infer_params(stem: str, desc: str) -> tuple[float | None, float | None, str]:
    """Return (params_total_b, params_active_b, arch).

    Never guesses. If the total is not stated in the filename or the
    description, it stays None. A wrong number is worse than a missing one.
    """
    arch = ARCH_OVERRIDES.get("", "dense")

    active = None
    m = ACTIVE_B_RE.search(stem)
    if m:
        active = float(m.group(1))
    if active is None:
        m = DESC_ACTIVE_RE.search(desc or "")
        if m:
            active = float(m.group(1))

    total = None
    if active is not None:
        # An "A3B"/"E4B" token is active-only; the leading number is the total.
        m = TOTAL_B_RE.search(stem)
        if m and float(m.group(1)) > active:
            total = float(m.group(1))
        arch = "moe"
    else:
        m = TOTAL_B_RE.search(stem)
        if m:
            total = float(m.group(1))
            # "27b" in the id alone doesn't prove MoE; only the A3B shape does.
            if re.search(r"[AE]\d+B", stem):
                arch = "moe"

    return total, active, arch


def infer_capabilities(model_id: str, has_mmproj: bool, group: str) -> list[str]:
    """Return every capability that applies, most specific first.

    Driven by the model id and group ONLY — never the free-text description.
    Descriptions contain incidental words that produce wrong answers: an
    earlier version matched "cod" anywhere in the prose and classified
    gemma-4-26b-moe as code, and matched "extraction" in gpt-oss-20b's
    "Hindsight memory extraction bakeoff" and called it an extractor.

    A model can legitimately be several things at once (devstral is a code
    model that also carries an mmproj), so this returns a list. Forcing one
    label loses information the fleet actually has.
    """
    if group == "embeddings" or model_id.startswith("ms-bge-"):
        return ["embedding"]

    caps: list[str] = []
    if model_id in CAPABILITY_OVERRIDES:
        caps.append(CAPABILITY_OVERRIDES[model_id])

    low = model_id.lower()
    if re.search(r"coder|devstral|kat-coder", low):
        caps.append("code")
    if re.search(r"nuextract", low):
        caps.append("extraction")
    if has_mmproj:
        caps.append("vision")
    if not caps:
        caps.append("general")

    seen: set[str] = set()
    return [c for c in caps if not (c in seen or seen.add(c))]


def load_bench(results_dir: Path) -> dict:
    """Fold in the newest benchmark CSV that mentions each model.

    Per-model, not global-newest: a model skipped in the last run should still
    show its most recent numbers rather than nulling out.
    """
    out: dict = {}
    if not results_dir.is_dir():
        return out

    # Recursive: benchmark runners write to <results_dir>/<run>/raw/*.csv, so a
    # flat glob finds nothing and silently nulls every bench field. Superseded
    # piles are excluded so a stale run cannot outrank a live one.
    files = sorted(
        (p for p in results_dir.rglob("*.csv") if "_superseded" not in p.parts),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for f in files:
        try:
            with f.open(newline="", encoding="utf-8") as fh:
                for row in csv.DictReader(fh):
                    mid = (row.get("model") or "").strip()
                    if not mid or mid in out:
                        continue
                    if (row.get("error") or "").strip():
                        continue
                    try:
                        med = float(row.get("median_tok_s") or 0) or None
                        q = float(row.get("quality_score") or 0)
                    except ValueError:
                        continue
                    if med is None:
                        continue
                    out[mid] = {
                        "tok_s": round(med, 1),
                        "quality": round(q, 2),
                        "source": f.name,
                        "mtime": datetime.fromtimestamp(
                            f.stat().st_mtime, timezone.utc
                        ).isoformat(),
                    }
        except OSError:
            continue
    return out


def build(config_path: Path, results_dir: Path) -> tuple[list[dict], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    try:
        cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as e:
        sys.exit(f"error: cannot read {config_path}: {e}")

    models = cfg.get("models") or {}
    groups = cfg.get("groups") or {}

    # group membership (a model may appear in more than one group)
    membership: dict[str, list[str]] = {}
    group_meta: dict[str, dict] = {}
    for gname, g in groups.items():
        if not isinstance(g, dict):
            continue
        group_meta[gname] = g
        for m in g.get("members") or []:
            membership.setdefault(m, []).append(gname)

    bench = load_bench(results_dir)

    rows: list[dict] = []
    for mid, m in models.items():
        if not isinstance(m, dict):
            errors.append(f"{mid}: entry is not a mapping")
            continue

        cmd = parse_cmd(m.get("cmd"))
        gguf = cmd.get("--model")
        mmproj = cmd.get("--mmproj")
        desc = " ".join((m.get("description") or "").split())
        stem = Path(gguf).stem if gguf else mid

        exists = bool(gguf) and os.path.isfile(gguf)
        if not gguf:
            errors.append(f"{mid}: no --model in cmd")
        elif not exists:
            # Distinguish "never downloaded" from "symlink points nowhere".
            # These need different fixes and look identical to os.path.isfile.
            if os.path.islink(gguf):
                tgt = os.readlink(gguf)
                if "\\" in tgt:
                    errors.append(
                        f"{mid}: BROKEN SYMLINK (escaped backslashes in target) "
                        f"-> {tgt}"
                    )
                else:
                    errors.append(
                        f"{mid}: BROKEN SYMLINK -> {tgt} (target absent)"
                    )
            else:
                errors.append(f"{mid}: gguf missing on disk: {gguf}")

        if not mmproj and not exists:
            pass
        if mmproj and not os.path.isfile(mmproj):
            warnings.append(f"{mid}: mmproj missing on disk: {mmproj}")

        gnames = membership.get(mid, [])
        if not gnames:
            warnings.append(
                f"{mid}: in models: but in no group — unreachable, still on disk"
            )
        for g in gnames:
            gm = group_meta.get(g, {})
            if gm.get("members") and mid not in gm["members"]:
                errors.append(f"{mid}: listed in group {g} inconsistently")

        total_b, active_b, arch = infer_params(stem, desc)
        quant_m = QUANT_RE.search(stem)
        tok, tok_src = TOKENIZERS.get(mid, (None, "unmapped"))
        caps = infer_capabilities(mid, bool(mmproj), gnames[0] if gnames else "")

        try:
            ctx = int(cmd.get("--ctx-size") or 0) or None
            par = int(cmd.get("--parallel") or 0) or None
        except ValueError:
            ctx = par = None
        try:
            ttl = int(m.get("ttl")) if m.get("ttl") is not None else None
        except (TypeError, ValueError):
            ttl = None

        persistent = any(
            bool((group_meta.get(g) or {}).get("persistent")) for g in gnames
        )

        rows.append({
            "id": mid,
            "display_name": m.get("name") or mid,
            "groups": sorted(gnames),
            "persistent": persistent,
            "gguf_path": gguf,
            "gguf_exists": exists,
            "gguf_size_gb": file_size_gb(gguf),
            "mmproj_path": mmproj,
            "mmproj_size_gb": file_size_gb(mmproj),
            "vision": bool(mmproj),
            "ctx_size": ctx,
            "parallel": par,
            "spec_type": cmd.get("--spec-type"),
            "ttl": ttl,
            "quant": quant_m.group(1) if quant_m else None,
            "params_total_b": total_b,
            "params_active_b": active_b,
            "arch": arch,
            "capabilities": caps,
            "capability": caps[0],
            "tokenizer": tok,
            "tokenizer_source": tok_src,
            "bench": bench.get(mid),
            "description": desc,
        })

    # Group members that do not exist in models: at — the exact failure mode
    # the studio-* -> ms-* rename produced.
    for mid in membership:
        if mid not in models:
            errors.append(f"{mid}: group member with no models: entry (orphan id)")

    rows.sort(
        key=lambda r: (
            CAPABILITY_ORDER.index(r["capabilities"][0])
            if r["capabilities"] and r["capabilities"][0] in CAPABILITY_ORDER
            else 99,
            -(r["params_total_b"] or r["params_active_b"] or 0),
            r["id"],
        )
    )
    return rows, errors + warnings


MD_COLUMNS = [
    ("id", "id"),
    ("cap", "capabilities"),
    ("group", "groups"),
    ("size_gb", "gguf_size_gb"),
    ("total_b", "params_total_b"),
    ("active_b", "params_active_b"),
    ("quant", "quant"),
    ("vision", "vision"),
    ("ctx", "ctx_size"),
    ("mtp", "spec_type"),
    ("tok_s", "bench.tok_s"),
    ("qual", "bench.quality"),
]


def render_md(rows: list[dict], stamp: str) -> str:
    def cell(r: dict, key: str) -> str:
        if key == "capabilities":
            return "+".join(r["capabilities"])
        if key == "groups":
            return ",".join(r["groups"]) or "**none**"
        if key == "vision":
            return "yes" if r["vision"] else ""
        if key == "spec_type":
            return "mtp" if r["spec_type"] and "mtp" in r["spec_type"] else ""
        if key.startswith("bench."):
            b = r.get("bench") or {}
            v = b.get(key.split(".", 1)[1])
            return "" if v is None else str(v)
        v = r.get(key)
        if v is None:
            return ""
        if isinstance(v, bool):
            return "yes" if v else ""
        if isinstance(v, float):
            return f"{v:g}"
        return str(v)

    head = "| " + " | ".join(h for h, _ in MD_COLUMNS) + " |"
    rule = "|" + "|".join("---" for _ in MD_COLUMNS) + "|"
    body = [
        "| " + " | ".join(cell(r, k) for _, k in MD_COLUMNS) + " |" for r in rows
    ]

    total = sum(r["gguf_size_gb"] or 0 for r in rows)
    by_cap: dict[str, int] = {}
    for r in rows:
        for c in r["capabilities"]:
            by_cap[c] = by_cap.get(c, 0) + 1

    foot = [
        "",
        f"**{len(rows)} models, {total:.1f} GB of GGUF on disk.**",
        "",
        "Capability counts (a model can appear more than once): "
        + ", ".join(f"{k} {v}" for k, v in sorted(by_cap.items()))
        + ".",
        "",
        "Blank `total_b` means the parameter count is not stated in the filename "
        "or description — it was not guessed.",
        "Blank `tok_s`/`qual` means no successful benchmark CSV mentions this "
        "model.",
        "`groups` = **none** means the model is in `models:` but unreachable by "
        "llama-swap and still occupying disk.",
        "",
        f"Generated {stamp} from "
        "`~/.hermes/llama-swap/config.yaml` by the `fleet-catalog` skill. "
        "Do not hand-edit — re-run the generator.",
    ]
    return "\n".join([head, rule, *body, *foot]) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", type=Path,
                    default=Path("~/.hermes/llama-swap/config.yaml").expanduser())
    ap.add_argument("--results-dir", type=Path,
                    default=Path("~/.hermes/benchmark_results").expanduser())
    ap.add_argument("--out-dir", type=Path,
                    default=Path("~/.hermes/llama-swap").expanduser())
    ap.add_argument("--check", action="store_true",
                    help="validate only, write nothing")
    ap.add_argument("--no-bench", action="store_true", help="skip CSV merge")
    ap.add_argument("--strict", action="store_true",
                    help="treat warnings as failures")
    args = ap.parse_args()

    if not args.config.is_file():
        sys.exit(f"error: config not found: {args.config}")

    results_dir = Path("/nonexistent") if args.no_bench else args.results_dir
    rows, problems = build(args.config, results_dir)

    missing = [r["id"] for r in rows if not r["gguf_exists"]]
    orphans = [r["id"] for r in rows if not r["groups"]]
    total_gb = sum(r["gguf_size_gb"] or 0 for r in rows)

    if problems:
        for p in problems:
            print(f"  {p}", file=sys.stderr)
    print(
        f"{len(rows)} models, {len(missing)} missing gguf, {len(orphans)} orphans"
    )

    if args.check:
        if problems and (args.strict or missing or orphans):
            print("check FAILED", file=sys.stderr)
            return 1
        print("check OK")
        return 0

    args.out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    payload = {
        "generated": stamp,
        "source_config": str(args.config),
        "model_count": len(rows),
        "total_gguf_gb": round(total_gb, 2),
        "problems": problems,
        "models": rows,
    }
    (args.out_dir / "catalog.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )
    (args.out_dir / "catalog.md").write_text(render_md(rows, stamp), encoding="utf-8")

    print(f"wrote {args.out_dir / 'catalog.json'}")
    print(f"wrote {args.out_dir / 'catalog.md'}")
    return 1 if (missing or orphans) else 0


if __name__ == "__main__":
    sys.exit(main())
