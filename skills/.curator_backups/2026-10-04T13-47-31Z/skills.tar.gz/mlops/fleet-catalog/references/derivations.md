# Field derivations and known fleet facts

Every field in `catalog.json` is read from config, measured from disk, or left
`null`. This file records how each one is derived so a surprising value can be
traced to its source instead of trusted.

## Derived from `cmd:` (authoritative)

| Field | Source flag | Notes |
|-------|-------------|-------|
| `gguf_path` | `--model` | Absolute path from the config |
| `mmproj_path` | `--mmproj` | Absent = text-only |
| `ctx_size` | `--ctx-size` | Total context, not per-request |
| `parallel` | `--parallel` | Concurrent slots per model |
| `spec_type` | `--spec-type` | `ngram-simple`, `draft-mtp,ngram-simple`, etc. |

The `mtp` column in the table shows `mtp` only when `spec_type` contains `mtp`.

## Measured from disk (authoritative)

`gguf_size_gb` / `mmproj_size_gb` are `os.path.getsize` in GiB. These override
any size written in the description prose. `granite-4.2-3b` advertises 2.2GB
and measures 2.09; that is rounding, not a conflict.

## Heuristic (leave `null` rather than guess)

- `quant` — regex over the GGUF filename stem.
- `params_total_b` — leading `\d+B` in the stem.
- `params_active_b` — an `A3B`/`E4B` token, else `(\d+)B active` in the
  description.
- `arch` — `moe` if an active-count token is present, else `dense`.
- `capabilities` — from the model **id** and group only. The description is
  never consulted; see below.

### Why the description is not consulted for capability

The first version matched the free-text description and got it visibly wrong:

- `ms-gemma-4-26b-moe` → "code", because the pattern `cod` matched somewhere
  in the prose.
- `ms-gpt-oss-20b` → "extraction", because its description says "Hindsight
  memory **extraction**/consolidation bakeoff".

Prose is where provenance and decisions live, not taxonomy. The id and the
group are the only stable signals. A model can carry more than one capability
(devstral is `code+vision`), so the field is a list, not a scalar.

## Known `null` values and why they are left alone

| Model | Null field | Reason |
|-------|-----------|--------|
| `ms-gemma-4-e4b` | `params_total_b` | "E4B" states 4B *active*; the total is never stated |
| `ms-bge-*` | both | BGE encoders are conventionally not described in B |
| `ms-kat-coder-v2.5` | both | Filename is `KAT-Coder-V2.5-Dev`, no size token |
| `ms-glm-4.6-vision` | both | `GLM-4.6V-Flash`, no size token |
| `ms-muse-glimmer-30b` | `params_active_b` | 30B stated, MoE active count not |

Filling these in by hand would make the catalog a second source of truth,
which is the exact failure this tool exists to prevent. If you learn a real
number, put it in the config description and re-derive.

## The naming defect this catalog exposes

A digit in an id does not mean one thing across the fleet:

- `ms-granite-4.2-3b` — 3B **dense**.
- `ms-gemma-4-e4b` — 4B **active** of a larger MoE.
- `ms-qwen3.5-4b-mtp` — 4B, MoE-shaped.
- `ms-qwen3.6-35b-a3b` — 35B total, 3B active.
- `ms-gpt-oss-20b` — 20B total, 3.6B active.

`total_b` and `active_b` are separate columns precisely so this ambiguity is
visible instead of baked into the key. Do not "fix" it by renaming; the ids
are referenced by skills, crons, and watchdogs, and the 2026-09-10 rename
already demonstrated the cost.

## Backslash-escaped symlinks (resolved 2026-09-29)

`--check` reported four entries whose GGUF symlinks pointed at
`/Users/macstudio\.hf\/hub/...` — Windows-style separators on a Unix path.
On a case-insensitive APFS volume these resolve to nothing while `ls -la`
still shows a plausible-looking link, so they went unnoticed until a load
test. `ms-qwopus3.8-27b-flash` (16.8GB GGUF + 1.8GB mmproj) and
`ms-qwen3.5-4b-mtp` (2.8GB) were both unloadable; the weights were present
in `~/.hf/hub` the whole time, so no re-download was needed.

Fixed with `ln -sfn` to forward-slash targets, then verified three ways:
the link resolves, the GGUF header reads *through* it, and the model
generates a correct answer through llama-swap. `ms-qwopus3.8-27b-flash`
was later cut from the fleet on vision-benchmark grounds; its `.hf` blobs
went with it.

**If this recurs**, the check that catches it is reading bytes through the
link, not just `[ -e ]`:
`head -c4 "$link" | xxd -p` should print `47475546` for a GGUF.

## Benchmark merge

`bench` takes the newest CSV (by mtime) that mentions each model, **not** the
newest CSV overall. Rows with a non-empty `error` column are skipped. A model
absent from all successful rows gets `bench: null` rather than a stale number.

Quality scores come from `benchmark-model-fleet`'s deterministic pattern
matchers. They are not comparable across task families, and a `0.0` often
means the model put its output in a reasoning block rather than that it
failed.
