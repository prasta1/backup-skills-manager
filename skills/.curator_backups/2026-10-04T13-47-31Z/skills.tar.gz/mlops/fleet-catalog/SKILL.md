---
name: fleet-catalog
description: Generate a derived catalog of the served model fleet.
version: 0.1.0
author: Hermes
platforms: [macos]
metadata:
  hermes:
    tags: [LlamaSwap, Inventory, Fleet, Provenance]
---

# Fleet Catalog Generator

Build a queryable inventory of every model llama-swap serves, derived mechanically from `config.yaml` plus the latest benchmark CSVs. One source of truth, one generated artifact, zero hand-maintained copies.

**What it does**: parses the llama-swap config, stats every GGUF on disk, resolves group and capability, folds in the most recent benchmark numbers, and emits `catalog.json` + a flat `catalog.md` table.

**What it does NOT do**: rename anything, edit `config.yaml`, or make judgment calls. Every field is either read from the config, measured from disk, or marked `null`. It is a mirror, not an editor.

**Key dependency**: `config.yaml` (source of truth), Python stdlib + `pyyaml`. No network.

## When to Use

- "What do I actually have, and what is it for?"
- "Which models are vision-capable and which are embeddings?"
- "What is the disk cost of the fleet, per model?"
- "Did the rename break anything?" (a stale id shows up as an orphan)
- Before pruning, deleting, or reordering the ondemand list.
- Any time you are about to hand-copy a model id into a second file.

Do **not** use it to change the fleet. It is deliberately read-only.

## Prerequisites

- `~/.hermes/llama-swap/config.yaml` exists.
- `python3` with `pyyaml` (`python3 -c "import yaml"`).
- Benchmark CSVs in `~/.hermes/benchmark_results/` are optional; results columns fill in when present.

## How to Run

Invoke through the `terminal` tool:

```bash
python3 scripts/fleet_catalog.py                 # write catalog.json + catalog.md
python3 scripts/fleet_catalog.py --check         # exit 1 if anything is wrong, write nothing
python3 scripts/fleet_catalog.py --out-dir ~/Desktop
python3 scripts/fleet_catalog.py --no-bench      # skip CSV merge, isolate config problems
```

`--check` is the one to wire into a cron or pre-commit habit: it validates without writing, so it can run on every config edit.

## Quick Reference

| Flag | Default | Notes |
|------|---------|-------|
| `--config` | `~/.hermes/llama-swap/config.yaml` | Source of truth |
| `--results-dir` | `~/.hermes/benchmark_results` | Benchmark CSVs |
| `--out-dir` | `~/.hermes/llama-swap` | Where catalog files land |
| `--check` | off | Validate only, write nothing, exit 1 on problems |
| `--no-bench` | off | Skip CSV merge |
| `--strict` | off | Treat warnings as failures |

Emits `catalog.json` (full records) and `catalog.md` (sortable table).

Catalog fields: `id`, `display_name`, `groups`, `persistent`, `gguf_path`, `gguf_exists`, `gguf_size_gb`, `mmproj_path`, `mmproj_size_gb`, `vision`, `ctx_size`, `parallel`, `spec_type`, `ttl`, `quant`, `params_total_b`, `params_active_b`, `arch`, `capabilities` (list), `capability` (first), `tokenizer`, `tokenizer_source`, `bench`, `description`.

## Procedure

1. **Run `--check` first** on any config edit. It reports missing GGUFs, orphan group members, and models absent from every group, without writing.

2. **Read `catalog.md` for the fleet view** — sorted by capability then size. This is the file to read when deciding what to keep.

3. **Use `catalog.json` for anything programmatic.** It is the artifact downstream tools should read instead of re-parsing `config.yaml` or re-typing an id.

4. **Re-run after every config edit.** The catalog is disposable. Never hand-edit it; if a field is wrong, the config or the disk is wrong.

5. **Wire `--check` into the rename workflow.** The `ms-*` rename broke four downstream systems because copies had drifted. A catalog regenerated in the same commit makes the drift visible immediately.

## Pitfalls

- **A broken symlink and a missing file need different fixes and look identical to `os.path.isfile`.** The generator distinguishes them and prints `BROKEN SYMLINK` with the target. None are in that state right now, but this is the failure mode that recurs: backslash-escaped targets (`/Users/macstudio\.hf\/hub/...`) produce a link that `ls -la` looks fine and `[ -e ]` says is dead. Fix with `ln -sfn` using forward slashes, then confirm by reading bytes *through* the link, not just resolving it.

- **Capability is derived from the id and group only, never the description.** Prose carries provenance and decisions, not taxonomy. An earlier version matching the description called gemma-4-26b-moe a "code" model and gpt-oss-20b an "extraction" model. If a capability looks wrong, the id is the thing to change, not the classifier.

- **`null` means unknown, not zero.** Param counts come from filename and description heuristics. Gemma 4 E4B reports `params_total_b: null` with `params_active_b: 4` because the total is genuinely not stated anywhere. Do not fill these in by hand; a wrong number here is worse than a missing one. `references/derivations.md` lists every known null and why.

- **A digit in an id does not mean parameter count.** `ms-granite-4.2-3b` is a dense 3B; `ms-gemma-4-e4b` is 4B *active* out of a larger MoE; `ms-qwen3.5-4b-mtp` is the same shape. This is the one real naming defect in the fleet. The catalog separates `params_total_b` from `params_active_b` so the ambiguity is visible instead of baked into the key.

- **A model in `models:` but in no group is unreachable.** llama-swap will not serve it, but the GGUF still occupies disk. `--check` flags this as an orphan.

- **Benchmark columns are per-CSV, not per-model.** A model absent from the newest CSVs shows `bench: null` even though older runs exist. The catalog takes the newest CSV that mentions each model, not the newest CSV overall.

- **Benchmark CSVs live in subdirectories, so the search must be recursive.** Runners write `<results_dir>/<run>/raw/*.csv`. A flat `glob("*.csv")` finds zero files and silently nulls `bench` for the entire fleet with no error — the run still exits 0. `load_bench` uses `rglob` and skips any path containing `_superseded`. If every `tok_s`/`qual` column goes blank at once, suspect the glob before suspecting the fleet.

- **Sizes are the GGUF on disk, not the advertised model size.** A Q4 quant of a 27B lands near 16 GB. The catalog reports measured bytes; the description's "(16.8GB)" prose is ignored.

- **The catalog is not a lockfile.** Deleting it loses nothing. That is the point.

- **Derive capabilities from the model id and group only.** Free-text descriptions in `config.yaml` produce false positives (`ms-gemma-4-26b-moe` was classified `code` from its description).
- **Retired is not broken.** `ms-qwopus3.8-27b-flash` and `ms-qwen3.5-4b-mtp` were removed from the llama-swap config (Qwopus on 2026-10-01); an earlier note blaming escaped-backslash symlinks was wrong. On a model 404, read `curl -s 127.0.0.1:9292/v1/models` before suspecting disk.
- **`--check` first.** `python3 scripts/fleet_catalog.py --check` validates the fleet (missing GGUFs, orphans, broken links) before generating `catalog.json`/`catalog.md`.

## Verification

```bash
python3 scripts/fleet_catalog.py --check
```

Pass condition: exit 0, and a line reading `N models, 0 missing gguf, 0 orphans`. A non-zero exit names the offending ids.

`--check` covers config and disk integrity only; it does not validate the benchmark merge. A green check with an all-blank `tok_s` column is a failed verification, not a pass. Confirm the merge separately: 14 of 19 models carry `bench` as of 2026-10-03. The five legitimate gaps are the 4 embeddings (never benchmarked, not throughput-bound) and `ms-nemotron-3.5-lightning-30b`, which was only ever benchmarked as the distinct MacBook build `mb-nemotron-omni-30b` — its numbers are not transferable across host, quant, and weights.

Current state is **exit 0**: `19 models, 0 missing gguf, 0 orphans` (verified 2026-09-29). The four backslash-escaped symlinks that once made `--check` exit 1 have been repaired and load-tested.

---

Load field derivations, known nulls, and the current broken-entry list on demand:
`skill_view(name='fleet-catalog', file_path='references/derivations.md')`
