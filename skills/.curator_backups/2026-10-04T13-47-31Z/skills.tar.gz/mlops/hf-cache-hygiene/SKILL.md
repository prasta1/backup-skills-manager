---
name: hf-cache-hygiene
description: "Audit and prune HF cache to reclaim disk space."
version: 0.1.0
author: Hermes
license: MIT
tags: [huggingface, cache, disk, maintenance, mlops]
platforms: [macos]
metadata:
  hermes:
    tags: [HuggingFace, Cache, Disk, Maintenance]
---

# Hugging Face Cache Hygiene

Audit and prune the Hugging Face cache store (`~/.hf/hub`) to reclaim disk space from orphaned blobs, incomplete downloads, and detached revisions. Does NOT touch the curated model tree at `~/models` — `hf cache` commands never modify it.

## When to Use

- Disk is tight and you need to reclaim space
- After a failed or interrupted `hf download`
- As part of any disk-pressure investigation
- When `du -sh ~/.hf` is much larger than `hf cache list` reports
- Studio's Data volume was 92% full earlier — check `~/.hf` there too

## Prerequisites

- `hf` CLI installed (`curl -LsSf https://hf.co/cli/install.sh | bash -s`)
- On Studio: `HF_HOME` is set in `~/.zshenv` AND in the unsloth plist. Check which host you're on before acting.
- On MacBook: `HF_HOME=/Users/prasta/.hf`

## How to Run

Invoke all commands through the `terminal` tool. Always run `--dry-run` first, report what will be deleted, and get explicit confirmation before running `-y`.

## Quick Reference

| Command | Purpose |
|---------|---------|
| `hf cache list` | List repos, sizes, last_accessed |
| `hf cache list --show-warnings` | Also show inconsistencies (missing blobs, missing snapshots) |
| `hf cache prune --dry-run` | Preview what prune will delete |
| `hf cache prune -y` | Delete detached revisions, incomplete downloads, unreferenced blobs |
| `hf cache rm <repo>` | Remove a specific repo |
| `hf cache verify` | Checksum a repo revision |

## Procedure

1. **Check which host you're on.** Studio has `HF_HOME` in `~/.zshenv` and the unsloth plist. MacBook uses `HF_HOME=/Users/prasta/.hf`. Run `echo $HF_HOME` through `terminal` to confirm.

2. **Compare total size vs listed size.** Run `du -sh ~/.hf` and `hf cache list` through `terminal`. A large gap means orphaned blobs.

3. **Run dry-run prune.** `hf cache prune --dry-run` through `terminal`. Report the count and total size of what will be deleted to the user. Get explicit OK before proceeding.

4. **Execute prune.** `hf cache prune -y` through `terminal`. This removes detached revisions, incomplete downloads, AND unreferenced shared blobs.

5. **Check for broken shells.** `hf cache list --show-warnings` through `terminal`. Repos with broken symlinks or no snapshots dir are skipped ("Repo ignored"). List them and ask before deleting the folders manually.

6. **Verify.** Re-run `hf cache list --show-warnings` and confirm the repo list and sizes are unchanged. Confirm `~/models` is untouched.

## Pitfalls

- `hf cache scan` NO LONGER EXISTS. Do not use it.
- The plain `list` output only mentions incomplete downloads. The real prune also deletes unreferenced shared blobs — the summary understates what prune will do.
- Repos with broken symlinks or no snapshots dir are skipped by both `list` and `prune`. They are empty shells that must be removed manually.
- If `hf download` stalls on Studio, use `HF_HUB_DISABLE_XET=1`. Stalled downloads are one source of incomplete blobs.
- `hf cache` commands NEVER touch `~/models`. Do not "clean" the curated model tree as part of cache hygiene.

## Verification

After pruning, run `hf cache list --show-warnings` through `terminal` and confirm:
- The repo list and sizes match the pre-prune state
- No new warnings appear
- `~/models` is untouched
