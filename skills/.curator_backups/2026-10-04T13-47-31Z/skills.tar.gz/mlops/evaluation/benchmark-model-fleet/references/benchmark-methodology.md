# Benchmark Methodology

## Test Setup

- **Endpoint**: llama-swap API at `http://127.0.0.1:9292` (OpenAI-compatible)
- **Model loading**: On-demand — llama-swap loads models when first requested. First request may take 30-300s for 20-30 GB models.
- **Retries**: 30 attempts with 5s delay for HTTP 503/502/504 (model swapping).
- **Timeout**: 300s per request (enough for 26 GB model load + inference).

## Coding Benchmarks

### Prompts
The built-in coding set (`scripts/prompts.py`) has 10 prompts; the `prompts/*.py` task families
(web_frontend, data_analysis, structured_extraction, tool_calling, instruction_following,
sql_generation) each define their own. The original audit used 4 prompts (csv_parser,
go_json_tags, rust_closure_borrow, npm_diff).

### Quality Scoring
- Each prompt has a deterministic scorer (`scripts/prompts.py`)
- 5 checks × 0.2 points = max 1.0
- Pattern-based (string matching), not LLM-judged
- Models without specific scorers default to 0.8 quality (text output > 100 chars)

### Thinking Mode Handling
- Non-thinking models: `max_tokens=512`, `enable_thinking` unset
- Qwen3 thinking models: Two configs tested:
  - `thinking_2k`: `max_tokens=2048`, thinking enabled (default)
  - `no_thinking`: `max_tokens=512`, `enable_thinking=false`
- **Finding**: Thinking overhead (2048 vs 512 tokens) provides zero quality improvement on these prompts. Output appears in `reasoning_content` field, `content` stays empty with max_tokens=512.

## Vision Benchmarks

### Prompts (4)
1. **describe_scene** — "Describe what you see in this image in detail."
2. **count_objects** — "How many people are in this image? Count carefully..."
3. **technical_detail** — "What technical equipment or tools can you identify?"
4. **contextual_reasoning** — "If this scene represents a real situation..."

### Image Input
- Local PNG file loaded as base64 data URI: `data:image/png;base64,...`
- **Critical**: llama-swap mmproj does NOT support URL image fetching. All URL-based image attempts fail.
- Test image: `test_image.png` (600×400, hiking scene via placehold.co)

### Vision Quality Scoring
- Not yet LLM-judged — uses char count as a proxy for output detail
- Future: Replace with semantic quality scoring

## Statistical Method

- 1 warmup + 3 timed runs per prompt per model
- tok/s = completion_tokens / elapsed_time
- **Median** of the 3 timed runs (robust against outliers from model loading)
- Warmup run also triggers model loading for on-demand models

## Scatter Plot Design

### Coding Speed × Quality
- X: median tok/s (higher = faster)
- Y: quality score 0-1 (higher = better)
- Bubble size: disk usage in GB (larger = more storage)
- Color: MoE (blue), Vision (orange), Standard (red)
- Deleted models: grey X markers with grey labels
- Legend: top-left, outside plot area

### Vision Speed × Output Detail
- X: vision tok/s
- Y: output character count (proxy for detail)
- Same color/marker scheme

### Speed × Efficiency
- X: coding tok/s
- Y: tok/s per GB (speed ÷ disk size)
- Shows diminishing returns: small models have 30-50x higher efficiency but no unique role

## Key Findings from the Audit

1. **Small models are speed traps**: qwen3-4b, phi4-mini hit 110+ tok/s but 0.80 quality — same as 20 GB models
2. **Thinking overhead**: No quality gain from Qwen3 thinking modes at 4B scale (2048 tokens vs 512 = identical 0.80 quality)
3. **Vision efficiency**: qwen3-VL-8b matches muse-glimmer-30b detail (1034 chars) at 2.7x speed, 1/3 disk
4. **Quality leaders**: kat-coder-v25 (0.95 coding) and devstral-24b (0.95 coding) — both kept despite speed trade-offs
5. **MoE sweet spot**: qwen36-35b-a3b at 78 tok/s + 0.85 quality + vision capability — the most versatile model
