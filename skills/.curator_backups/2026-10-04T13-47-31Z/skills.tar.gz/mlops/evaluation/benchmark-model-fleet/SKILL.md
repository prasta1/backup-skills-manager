---
name: benchmark-model-fleet
description: Benchmark LLM speed, vision, quality and scatter plots.
version: 0.2.0
author: Hermes
categories: [mlops, evaluation]
tags: [Benchmarking, LLM, Visualization, Matplotlib]
---

# Model Fleet Benchmark & Visualization

Benchmark a fleet of llama-swap-hosted models — coding speed, vision performance, quality scoring, and scatter plot generation. Originally built to audit and right-size a 171 GB model fleet down to 110 GB (recovering 61 GB) while mapping speed × quality trade-offs.

**What it does**: Run coding/vision benchmarks against a llama-swap endpoint, compute quality scores via deterministic pattern matchers, generate matplotlib scatter plots (Speed × Quality, Vision Speed × Detail, Speed × Efficiency), and produce consolidated ranked reports.

**What it does NOT do**: Manage model lifecycle (loading, removal, disk cleanup). That's handled by separate llama-swap config operations. This skill only benchmarks, scores, visualizes, and reports.

**Key dependency**: llama-swap running with an OpenAI-compatible API (default `llama-swap-studio` = `http://127.0.0.1:9292`), matplotlib installed (`pip3 install matplotlib`). stdlib otherwise.

## When to Use

- Audit a model fleet's speed/quality tradeoffs before deletions
- Compare thinking vs non-thinking model variants
- Benchmark vision models (mmproj) with consistent image input
- Generate scatter plots showing deleted models greyed-out alongside active ones
- Produce ranked tables for reporting to stakeholders

## Prerequisites

- llama-swap running: `llama-swap :9292` (OpenAI-compatible endpoint). Verify with `scripts/discover_endpoints.py`.
- matplotlib: `pip3 install matplotlib`
- A test image for vision benchmarks, **paired with its rubric**: `scripts/test_image_user.png` + `prompts/vision_user.py` (default), or `scripts/test_image_workshop.png` + `prompts/vision_grounded.py`. The benchmark sends base64 data URIs, not URLs — llama-swap mmproj requires `data:image/png;base64,...`. **Do not use the legacy `scripts/test_image.png`** — it is a grey placeholder with a caption, not a photograph.
- Knowledge of model names as served by llama-swap (e.g. `ms-qwen3-coder-30b`) — or just run `run_interactive.py`, which reads them from the endpoint.

## How to Run

### Interactive (preferred)

`scripts/run_interactive.py` asks six questions before spending any GPU time —
which machine, what you want to measure, which models, how hard, where results
land, and a final confirm. It then drives the whole pipeline including the merge
step that is easy to forget.

```bash
python3 scripts/run_interactive.py              # interview, then run
python3 scripts/run_interactive.py --dry-run    # show the plan, run nothing
python3 scripts/run_interactive.py --preset vision
```

Every answer defaults to the cheap/safe option. `--non-interactive --profile
<profile.json>` replays a saved run for cron. **Use this unless you have a
specific reason not to** — a full `--all-models` coding sweep is ~2 hours on this
hardware, and the interview is what stops that from happening when you only
wanted to check two models.

### Manual

All scripts live in `scripts/`; run them from the skill root.

```bash
# 1. See what's live and what model ids each endpoint serves
python3 scripts/discover_endpoints.py --models

# 2. Run coding benchmarks (built-in coding prompts; requires --models or --all-models)
python3 scripts/benchmark.py --models ms-qwen3-coder-30b ms-devstral-24b
python3 scripts/benchmark.py --all-models          # every LLM the endpoint reports

# 3. Run vision benchmarks (uses scripts/test_image.png by default)
#    (models are unloaded after each benchmark by default; pass --no-unload to keep them resident)
python3 scripts/benchmark.py --vision --models ms-qwen3-vl-8b ms-glm-4.6-vision
python3 scripts/benchmark.py --models ms-qwen3-coder-30b --no-unload   # keep loaded after
python3 scripts/benchmark.py --vision --models ms-qwen3-vl-8b ms-glm-4.6-vision

# 4. Generate scatter plots + the PDF (uses references/model-config.json)
python3 scripts/generate_scatter.py --results-dir ~/.hermes/benchmark_results
# multi-machine fleet: one set of plots per box as well
python3 scripts/generate_scatter.py --results-dir ~/.hermes/benchmark_results \
    --model-config <dir>/model-config.json --per-machine

# 5. Generate consolidated ranked report (rankings are PER MACHINE, see below)
python3 scripts/generate_final_report.py --results-dir ~/.hermes/benchmark_results
python3 scripts/generate_final_report.py --results-dir ~/.hermes/benchmark_results \
    --model-config <dir>/model-config.json --out <dir>/report.txt
# --combined  one table across all machines instead
```

Plots: `scatter_coding.png`, `scatter_vision.png`,
`scatter_coding_efficiency.png`, plus `..._mac_studio_m3_ultra.png` /
`..._macbook_pro_m5.png` variants under `--per-machine`. `--combined-only`
suppresses the all-machines set.

The same run also writes **`scatter_plots.pdf`** — a document, not just a pile of
images: a cover page, a table of contents with real page numbers, a per-machine
summary page, then every chart as its own page. It is on by default; `--no-pdf`
restores PNG-only output. Pages are native vector, so a 12-page report is ~90 KB.
Every page shares the chart paper size (15.5×10.5 in); the text pages lay out in
an A4-width column aligned with the chart titles.

**Reading the output.** Per-machine speed × quality plots (and vision, when it is
rubric-graded) draw the **Pareto frontier**: a dashed staircase through the
models nothing else beats on both axes, with the beaten region shaded and its
models dimmed. That is the keep list. The combined plot skips it — a frontier
across machines would rank the hardware. The PDF summary page lists the same
frontier per machine (computed from the same rows as the chart), and for a group
spanning machines shows no speed-derived line at all, only best quality. The
text report opens each machine with a matching `VERDICT` block and marks
frontier rows `◆` in the coding table; it reads the CSVs rather than
model-config.json, so its frontier can differ from the PDF's by a model where
the two sources disagree on a score.

Results land in `~/.hermes/benchmark_results/` (override with `--results-dir`):
- `coding_bench_<timestamp>.csv` / `vision_bench_<timestamp>.csv` — raw per-model results
- `scatter_coding.png`, `scatter_vision.png`, `scatter_coding_efficiency.png`
- `scatter_plots.pdf` — cover + contents + summary + all charts
- ranked tables printed to stdout by `generate_final_report.py`

## Quick Reference

| Command | Purpose |
|---------|---------|
| `scripts/discover_endpoints.py` | Probe all registered endpoints, list live ones + model ids |
| `scripts/benchmark.py` | Coding/vision benchmark, writes CSV. **The canonical benchmark.** |
| `scripts/run_interactive.py` | **Interactive front-end** — asks what to measure before spending GPU time |
| `scripts/build_model_config.py` | Merge CSVs + on-disk GGUF sizes into model-config.json. **Reconciles against the llama-swap config** — ids no machine can load are marked `deleted`, not silently kept |
| `scripts/generate_scatter.py` | Matplotlib scatter plots (speed×quality, vision, efficiency) **+ `scatter_plots.pdf`** (cover, contents, summary, all charts) |
| `scripts/generate_final_report.py` | Consolidated ranked tables |
| `scripts/prompts.py` | Built-in coding prompts + quality scorers |
| `prompts/vision_user.py` | **Grounded vision rubric** — the one to use (`--prompts-file`) |
| `prompts/vision_grounded.py` | Second grounded rubric, for `test_image_workshop.png` |
| `references/vision_ground_truth_user.json` | Verified ground truth for `test_image_user.png` |
| `references/vision_ground_truth.json` | Verified ground truth for `test_image_workshop.png` |
| `test_vision_user.py` / `test_vision_rubric.py` | Rubric unit tests — run after ANY scorer change |
| `references/endpoints.json` | Endpoint registry (llama-swap, LM Studio, oMLX, mlx_lm, Ollama, vLLM) |
| `references/model-config.json` | Model metadata — **generated by build_model_config, not hand-edited** |
| `references/benchmark-methodology.md` | Full methodology docs |

**Key API endpoints**:
- `POST http://127.0.0.1:9292/v1/chat/completions` — completion request
- `GET http://127.0.0.1:9292/v1/models` — list available models

**Endpoints**: `--endpoint` takes a registry name from `references/endpoints.json` (`llama-swap-studio`, `llama-swap-studio-tailnet`, `llama-swap-mbp`, `lm-studio`, `omlx`, `mlx-lm`, `ollama`, `vllm`) or a full URL. Default is `llama-swap-studio`. Run `scripts/discover_endpoints.py` first — most endpoints are down at any given time, which is expected. A dead endpoint fails preflight in <0.1s instead of retrying 30x per call, and ids the server does not serve are skipped with a warning.

**Auth**: endpoints that require a key (e.g. oMLX) set an `api_key` field in `endpoints.json` — `file:/path/to.json#/json/pointer` (read from a JSON file), `env:VARNAME`, or a literal. Both `discover_endpoints.py` and `benchmark.py` send it as a Bearer header. oMLX serves on **:8010** (settings.json `server.port`), not 8000, and requires its key.

**Task families**: `--prompts-file prompts/<family>.py` swaps the rubric. CSVs are named after the family so runs do not collide. Deterministic scoring is best for sql_generation (queries are executed against an in-memory SQLite and result sets compared), excellent for structured_extraction / tool_calling / instruction_following, good for web_frontend and data_analysis, and impossible for summarization or creative writing — do not fake those with pattern matchers.

## Procedure

1. **Verify llama-swap is running**: `python3 scripts/discover_endpoints.py` — confirm `llama-swap-studio` is UP and note the model ids. llama-swap loads models on-demand, so first requests may take time (retry on 503).

2. **Prepare test image** (for vision benchmarks): a PNG at `scripts/test_image.png`. The benchmark reads it as base64 and sends `data:image/png;base64,...` — llama-swap mmproj does NOT fetch URLs.

3. **Edit `references/model-config.json`**: List every model to benchmark with its metadata:
   ```json
   [{"name": "ms-qwen3-coder-30b", "size_gb": 16, "type": "MoE", "deleted": false}]
   ```
   Fields: `name` (llama-swap model ID), `size_gb` (for bubble size + efficiency), `type` (MoE/Vision/Standard/Embeddings for coloring), `deleted` (grey X marker on plots), plus `coding_spd`/`quality`/`vision_spd`/`vision_chars` (results go here after benchmarking). This is the single source of truth for plots and reports.

   **In practice you should not hand-edit this — `build_model_config.py` generates it** (step 4 below), and the merge now sets `deleted` itself. Hand-edits are overwritten on the next merge, and a hand-edited file is how stale ids survived here for weeks.

   **Staleness rule.** The merge's name universe is the union of *every* CSV ever written, and nothing ever removes a name — so a model that was benchmarked once, then pruned or renamed, would otherwise stay forever, rendered as a LIVE bubble. `reconcile()` prevents that: an id survives only if the local llama-swap config declares it, or it carries a prefix owned by another machine (derived from `endpoints.json` + which prefixes this config actually declares). Everything else gets `deleted: true` + `not_loadable: true` — greyed on the plots, left out of every frontier and marked `deleted` in the report's rankings, and kept as an audit trail. Run with `--no-reconcile` to opt out.

4. **Run coding benchmarks**: `python3 scripts/benchmark.py --models <id> ...` (or `--all-models`). For each model: 1 warmup + 3 timed runs per prompt (`--runs` and `--limit-prompts` adjust this). Median tok/s is recorded. Quality is scored by the rubric's pattern matchers; a prompt with **no** scorer falls back to 0.8, which is a placeholder, not a measurement — treat any model relying on it as unscored.

5. **Run vision benchmarks**: `python3 scripts/benchmark.py --vision --prompts-file prompts/vision_user.py --image-path scripts/test_image_user.png --models <id> ...`. **Always pass `--prompts-file` and the matching `--image-path`** — see the Vision rubric section below for why the default is not trustworthy.

6. **Generate scatter plots + PDF**: `python3 scripts/generate_scatter.py --results-dir <dir>`. Plots are saved as `scatter_coding.png`, `scatter_vision.png`, `scatter_coding_efficiency.png`; `scatter_plots.pdf` collects them behind a cover, table of contents and summary page. Pass `--model-config` to override the default `references/model-config.json`. Add `--per-machine` for a per-box set. Pass `--no-pdf` for PNGs only.

7. **Generate final report**: `python3 scripts/generate_final_report.py` consolidates all CSVs into ranked tables, one section per machine plus a cross-machine comparison.

## Vision benchmarking — read this before trusting a vision number

**The old vision path scored nothing and must not be used.** `benchmark.py`
passed `scorers = None` for vision, so every model took the 0.8 unscored default
and the only real signal was `quality_chars` — a character count of the response.
A model that padded its answer scored higher, so the axis rewarded verbosity and
invention. Worse, the test image was a flat grey rectangle with a caption printed
on it, so every score was measuring hallucination against a blank.

Two grounded rubrics now exist, each paired with an image whose contents are
verified in a `references/vision_ground_truth*.json`:

| rubric | image | use |
|--------|-------|-----|
| `prompts/vision_user.py` | `scripts/test_image_user.png` | **default choice** — real photo, genuinely ambiguous |
| `prompts/vision_grounded.py` | `scripts/test_image_workshop.png` | generated scene, 3 people / workshop |

```bash
python3 scripts/benchmark.py --vision \
  --prompts-file prompts/vision_user.py \
  --image-path scripts/test_image_user.png \
  --models ms-qwen3-vl-8b ms-glm-4.6-vision \
  --runs 1 --enable-thinking false \
  --results-dir ~/.hermes/benchmark_results/vision-$(date +%Y%m%d)
```

**Rubric and image are a matched pair.** `benchmark.py` warns when the image does
not match the rubric's recorded ground truth, because a scorer verified against
one picture is meaningless on another. If you swap the image, re-verify it and
rewrite the ground-truth JSON in the same change.

What makes `vision_user.py` discriminate (the first rubric gave every model
1.00, which ranks nothing):

- **negative existence** — "how many are wearing a red top?" The answer is
  **zero**. Her top is light, so a model pattern-matching light→a-colour says 1
  and is wrong.
- **spatial trap** — "the person on the far left". There is no person there; the
  horse is. The only person stands on the right.
- **small object** — the cat is bottom-corner and occluded by the fence.
- **calibration** — two background elements are genuinely ambiguous. Hedging or
  listing plausible readings scores; confident fabrication does not. This is the
  axis a character count structurally cannot express.

**After changing any scorer, run `python3 test_vision_user.py` and
`test_vision_rubric.py`.** Both must pass. The scorers are regex-heavy and have
a history of silently returning `None` (treated as a low score) when a phrasing
is not covered — see the pitfalls below.

- **Rank vision by the rubric, never by character count — in the report too, not
  just the plot.** The plot was fixed to use `vision_quality` while
  `generate_final_report.py` still sorted by `quality_chars`, so the two
  artifacts ranked the same models differently. Sorting by speed put
  `ms-ministral-3-3b` at #1 (97.5 tok/s, 0.50 quality) and `mb-qwen3-vl-8b` at
  #9 (36.4 tok/s, 1.00). On the rubric, qwen3-vl-8b is #1 and ministral-3-3b is
  #13th. Chars stay as a diagnostic column only. The report reads
  `vision_quality` from model-config.json so a scorer fix applied via
  `--vision-results-dir` is honoured instead of being silently reverted.

**Treat vision tok/s as unreliable.** Measured medians on this box ranged from
1.4 to 80.8 tok/s for the same model across prompts, with completion tokens
swinging 94→512. The quality axis is the trustworthy part of a vision run.

## Results are reported PER MACHINE — do not flatten them

`generate_final_report.py` and `generate_scatter.py` split everything by the
machine that produced it. This is not cosmetic. **tok/s is only comparable
within one box**: the Studio's 151 tok/s and the MBP's 16 tok/s on the same
task are a fact about the hardware, not the model. A single combined ranking
puts `mb-smollm3-3b` (91.9 tok/s, quality 0.65) at #2 overall, above
`ms-gemma-4-12b` (51.8 tok/s, quality 0.35) — implying the 3B laptop model is
the better coder, when within each machine the ordering is different. Each box
also serves a different roster, so a merged table implies comparisons that do
not exist.

Machine identity comes from `scripts/machines.py`, keyed on the `endpoint`
column already in every CSV (measured fact), falling back to the `id_prefix`
in `references/endpoints.json` for rows that lack one. Adding a machine means
adding a prefixed endpoint entry — no code change. Note `load_machines()`
yields `(url, (name, prefix))`; destructure both halves, or the prefix length
comes back as the URL length and every id loses its first two characters.

Two useful consequences:

- **Per-machine rankings answer "which model should this box use".**
- **The cross-machine table answers "why does the same model differ".** It
  strips the prefix so `ms-devstral-24b` and `mb-devstral-24b` line up as one
  model on two boxes. That is the only genuinely cross-hardware comparison
  available, and it is where quantization and runtime differences show up:
  qwen3-vl-8b scored 0.75 coding / 0.88 vision on the Studio and 0.80 / 1.00
  on the MBP, while qwen3.8-27b-swift1.5 collapsed from 0.80 / 0.88 to
  0.50 / 0.62. NOT a quant difference — verified 2026-10-03: both hosts run
  byte-identical Q4_K_M + F16 mmproj (SHA256-matched), identical llama.cpp
  0.5.0 binary, and identical perception (both place the woman right of the
  horse). The gap is a real, unexplained host-level execution difference
  (M3 Ultra vs M5): the MBP deterministically fails the spatial_left trap
  (0.0 x5) while the Studio passes under every MTP recipe (1.0 x5). Same
  family as the documented MTP-throughput inversion between hosts. The
  laptop should not be trusted for this spatial task.

## Pitfalls

- **Two concurrent sweeps silently destroy one CSV.** CSV names are
  `<prefix>_<timestamp>.csv`; two runs launched together start their first model
  in the same second, so the names collide and the slower process OVERWRITES
  the faster one's file. A two-machine sweep lost a full 4-prompt coding result
  (rows present in the log, absent from every CSV). Names now carry
  microseconds. If you run two machines at once, still diff the model count in
  the CSVs against the model count in the logs before trusting the merge.

- **`adjustText` can fling a label off-canvas and `bbox_inches='tight'` will
  follow it there.** One escaped label turned a 15.5x10.5in figure into
  66x12,440in and a 116 MB PNG that never finished writing. `_resolve_labels`
  now leaves in-bounds labels alone and pulls escaped ones back beside their own
  marker — do NOT snap them all to the nearest edge, which stacks every escaped
  label into one unreadable corner. All savefig calls go through `_savefig()` so
  dpi and pad live in one place. PDF chart pages do NOT use the tight bbox: they
  save at the fixed 15.5×10.5in figure size (tight_layout fits the content), so
  every page in the document is the same size.

- **adjustText 1.x silently ignores the 0.x keyword names.** `expand_points`,
  `expand_text`, `lim`, `precision` and `autoalign` raise no error — they are
  swallowed — so labels were barely de-overlapped and piled on top of each
  other. `_resolve_labels` uses the 1.x names (`expand`, `force_text`,
  `force_static`, `iter_lim`, `ensure_inside_axes`). Check
  `inspect.signature(adjust_text)` before tuning it.

- **A fixed y-axis floor hides the models a fleet audit exists to find.** The
  coding plot was clamped at `ylim(0.55, …)`, so every model scoring below 0.55
  (ms-nuextract3, the granite family, ms-trinity, ms-gemma-4-12b — 9 Studio
  models) was silently off the chart. The floor now follows the data.

- **Do not trust a vision model's description of label layout.** Two reads of a
  correct 28-label plot both reported "all labels stacked in the top-right
  corner, unreadable." Measuring the rendered text extents showed 16 overlapping
  pairs out of 378 and ZERO labels outside the axes — the plot was fine and the
  reads were wrong; 28 leader lines just look like a wall when skimmed. Verify
  geometry numerically (`get_window_extent`) before "fixing" a layout.

- **The Homebrew python has no `adjustText`, and pip is PEP-668 blocked.** Use a
  throwaway venv (`python3.14 -m venv /tmp/benchvenv && pip install matplotlib
  numpy adjustText`) rather than `--break-system-packages`. Default `python3` is
  3.9 with a numpy built for 3.14 and cannot import matplotlib at all.

- **A PDF summary that averages across machines contradicts the skill's own
  rule.** The summary page first printed "All Machines — 197.1 GB on disk" and a
  combined mean tok/s. Both were wrong: only one host's models carry `size_gb`,
  so the total silently covered 23 of 41 models, and averaging tok/s across
  hardware is exactly the comparison the per-machine split exists to prevent.
  Partial totals now print as `197.1 GB across 16 sized`, and any group spanning
  machines gets its speed average suppressed with a note. The same rule covers
  every speed-derived line — "Fastest", best tok/s/GB and the frontier are all
  hidden for a mixed group; only quality is ranked there. When adding a summary
  number, ask which subset it actually covers before printing it.

- **`matplotlib.backends.backend_pdf` is not an attribute until you import it.**
  `matplotlib.use('Agg')` does not load the PDF backend, so
  `matplotlib.backends.backend_pdf.PdfPages` raises AttributeError. Use
  `from matplotlib.backends.backend_pdf import PdfPages`.

- **`global X` at module level is a SyntaxError, not a no-op.** Resetting a
  module counter inside an `if __name__ == '__main__':` block must be a plain
  assignment — the block IS module scope, so adding `global` there fails with
  "name is assigned to before global declaration".

- **A blank PDF page is worse than no page.** A group with no vision or
  efficiency data still writes a placeholder PNG (existing behaviour worth
  keeping), but those must be passed `pdf=None` — otherwise a 12-page report
  carries four empty pages. Page numbers in the contents are assigned from a
  plan that skips those axes, so the two stay consistent.

- **The merge's name universe never shrinks — reconcile it or you get ghosts.**
  `read_rows` globs `{prefix}_*.csv` with no recency window and unions every
  distinct model name found, so a model benchmarked once and later pruned or
  renamed lives in `model-config.json` forever. `deleted` was hardcoded `False`
  and nothing ever set it `True`, which made the grey-X "deleted" rendering in
  `generate_scatter.py` permanently dead code: a pruned 8B sat at rank #2 on the
  coding chart at 134.8 tok/s for weeks, indistinguishable from a real model.
  11 such ghosts accumulated. `reconcile()` now decides from the llama-swap
  config, and `--carry-forward` stops a partial run shrinking a 41-row fleet
  file to the 2 models it just touched.

- **Never infer "this prefix is local" from the URL.** `endpoints.json` has
  `llama-swap-mbp-loopback` at `127.0.0.1:8999` carrying prefix `mb-`, so a
  loopback-means-local test classifies the MacBook's entire roster as local and
  marks all 14 `mb-*` models deleted on the Studio — silently dropping a whole
  machine's results. Derive it from the config instead: a prefix is local iff
  this host's config declares a key carrying it. That is self-consistent on both
  boxes, where the URL is not.

- **Two files claimed to be the source of truth.** `run_interactive.py` wrote the
  merge to `<results_dir>/model-config.json` while `generate_scatter.py` and
  `generate_final_report.py` both default to reading
  `references/model-config.json`. Nothing reconciled them, so the interactive
  path — the documented preferred one — never updated the file the charts read.
  The two files now have separate jobs. **`<run>/model-config.json` is the run
  view**: built from that run's CSVs only, and what that run's plots and report
  read. **`references/model-config.json` is the fleet view**: the latest known
  value per model per field across every run. The interactive flow writes the
  run view, then folds the run into the fleet view with `--carry-forward`. Only
  the built-in coding family folds in, because `--family` writes its scores
  into the coding fields. Carry-forward fills the fields a run did not measure
  from the previous fleet row, so a vision-only run cannot wipe coding scores.

- **Skipping `build_model_config.py` silently re-plots the PREVIOUS run.** The
  plotting scripts read `references/model-config.json` and never read the CSVs.
  A fresh benchmark that skips the merge produces confident plots of old numbers.
  `run_interactive.py` does the merge for you; if you run the steps by hand, do
  not skip it. It also needs `--family <prefix>_bench` for a non-default rubric
  (default `coding_bench`), or it globs nothing and merges an all-null config.

- **`from prompts import <family>` does not work.** `scripts/prompts.py`
  *shadows* the `prompts/` directory of the same name, so that import resolves to
  the module file and raises ImportError. Load families by path via
  `parse_prompts_file()`, as `benchmark.py` now does internally.

- **A model advertised by llama-swap can still be unloadable.** Two models
  (`ms-qwopus3.8-27b-flash`, `ms-qwen3.5-4b-mtp`) appeared in `/v1/models` but
  returned HTTP 500 on every request: their GGUF symlinks had been created with
  backslash-escaped paths (`/Users/macstudio\.hf\/...`), so the link target was
  a literal, non-existent filename. `ls -la` on the model dir and
  `[ -e "$path" ]` per target will find it; `build_model_config.py` reports
  `!! GGUF path broken` and a 0.0 GB size as a signal. The weights were present
  the whole time — no re-download needed, just `ln -sfn` with unescaped paths.

- **A two-machine fleet breaks the size merge.** `build_model_config.py` stats
  GGUF paths from the config of whichever host runs it, so a Studio-side merge
  reports every `mb-*` model as 0.0 GB with `broken_paths` — the paths live on
  the MBP. Measure sizes on the host that holds the weights and pass
  `--extra-sizes <json>` (map of `{id: {size_gb, broken: []}}`); local entries
  always win. Without this the efficiency plot has every remote model at zero
  size.

- **`--model` in a prose comment reads as a broken GGUF path.** The size
  scraper takes the token after `--model`/`-m`/`--mmproj`; a config comment
  containing that literal word yields a bare word like `wired`, which then gets
  reported as a missing file. Paths are filtered on containing `/`. A
  `!! GGUF path broken` flag on a model that just benchmarked cleanly is this
  bug, not a real missing file — confirm with `ls` before re-downloading
  anything.

- **A rubric that gives every model 1.00 ranks nothing.** The first grounded
  vision rubric scored 1.00 across the board because the scene (3 people, 3
  prominent objects) was too easy: the ground truth was unambiguous *and*
  trivial. Difficulty has to come from somewhere real — a photo with occlusion,
  attribute-filtered counting, a spatial trap, and genuinely ambiguous elements.
  Verify discrimination with a deliberately weaker model before trusting a
  ranking.

- **Keep scorers on a 0–1 scale with no weight juggling.** Two bugs in a row came
  from weighting: letting each prompt's ceiling be its own axis weight (a perfect
  answer scored 0.20 on one prompt, 0.35 on another), then "fixing" it by
  dividing by the weight without multiplying first (scores of 2.86 and 5.00).
  Write each specific scorer to return 0–1 and use it directly. The weights in
  the ground-truth JSON document priority for a human reader; they are not
  arithmetic.

- **A scorer can punish the answer the prompt ASKED for.** `color_counts` in
  `prompts/vision_user.py` binds a count to a colour word, so a bare `0, 0` or
  `none / none` returned None and scored 0.00 — while a verbose `Red: 0 /
  Blue: 0` scored 1.00 for the identical fact. The prompt says "Give a number
  for each. If there are none, say none", so terseness IS compliance. glm-4.6v
  and gemma-4-12b lost 0.25 each before a positional fallback was added (bind
  numbers in asked order when no colour anchor exists, only when the count
  matches the number of colours). General rule: when a scorer returns None,
  re-read the PROMPT before blaming the model — and verify with a live probe,
  not the CSV, because a 0.00 next to a short `quality_chars` is the tell.

- **A 0.00 quality with a full 512-token completion is a budget artifact, not
  a bad answer.** R1-style models emit `reasoning_content` and leave `content`
  empty; `benchmark.py` reads `content` first and only falls back to
  `reasoning_content`. Confirm by probing the endpoint directly and comparing
  `content_chars` vs `reasoning_chars` in the raw response. Raising
  `--max-tokens` does NOT help if the template ignores `enable_thinking: false`
  — on `mb-deepseek-r1-32b` at 512 tokens: content 0 chars, reasoning 2228.

- **Pairing numbers to colours by distance is wrong.** In "1 person in a red top
  and 0 wearing blue", the `0` is *closer* to "red" (14 chars) than red's own `1`
  is (18). Nearest-overall sends both halves of "nobody in red and nobody in
  blue" to red. Anchor on the colour words and cut the text at them, then bind
  each number to the region it falls in. Also: a bare "no" is a zero count, a
  lookahead window must be wide enough to contain a whole colour word (24 chars
  clipped "blue" to "blu"), and "zero people in red" is a colour count while
  "only one person in the image" is a headcount.

- **Streaming endpoints inflate tok/s if elapsed is measured before the body read**: oMLX (and any SSE/chunked server) sends headers before the body finishes streaming. If `elapsed` is captured on entering the `urlopen` context (before `resp.read()`), it under-measures time and tok/s balloons (a 27B MLX model read as 255 tok/s when the real number was 34). Measure elapsed AFTER `resp.read()` completes. llama-swap buffers the full body so it was unaffected, but the fix is correct for every endpoint.
- **Qwen3 thinking models**: When `max_tokens=512`, Qwen3 thinking models put all output in `reasoning_content` and leave `content` empty — quality scores show 0.0. Fix: pass `--enable-thinking=false` with `--max-tokens 512`, or `--max-tokens 2048` with thinking enabled.
- **Vision URL vs base64**: llama-swap mmproj API does not support URL image fetching. URL-based image inputs fail with errors. Always use `data:image/png;base64,...`.
- **On-demand model loading**: llama-swap swaps models in on first request. Retry on HTTP 503/502/504 with 5s delay, up to 30 attempts.
- **4B models are deceptively fast**: Tiny models (qwen3-4b, phi4-mini) hit 110+ tok/s but quality is capped at 0.80 — speed without capability. Compare quality, not just speed.
- **Deleted model labels overlap**: On coding plot, the three 110+ tok/s 4B models cluster near each other. Use vision or efficiency plot for clearer separation.
- **Legend placement**: One row above the plot, right-aligned opposite the subtitle (`loc='lower right', bbox_to_anchor=(1.0, 1.008)`), listing only the types present. Inside the axes it covered the top-left corner — where a slow, high-quality model plots and where the frontier starts.
- **Embeddings in the config**: `model-config.json` includes bge embedding/reranker entries (`type: "Embeddings"`). They plot as grey diamonds; they are not benchmarked (no coding/vision scores).

## Verification

```bash
# Verify all scripts run cleanly
python3 scripts/generate_scatter.py --output-dir /tmp/skill_test --results-dir /dev/null
python3 scripts/generate_final_report.py --model-config references/model-config.json
```

Check that `scatter_coding.png`, `scatter_vision.png`, and `scatter_coding_efficiency.png` are created with:
- Legend as one row above the plot, top right
- Deleted models as grey X markers with grey labels
- Model name annotations on active model markers (uniform size; type is shape + colour)
- Per-machine speed × quality: dashed frontier staircase, beaten models dimmed,
  subtitle reading `N models · K on the frontier`
- The lowest-scoring model is on the chart, not below the y-axis

Check `scatter_plots.pdf` exists and its page count matches the printout
(`N pages: 3 front matter + M charts`).

**Verify the front matter by looking at it, not by reading the .pdf.** Text
overlap and page-number drift are invisible in the file itself and there is no
PDF renderer on this box (`pdftoppm`, `mutool`, `gs`, Quartz all absent). Render
the pages straight to PNG through the same code path the PDF uses:

```bash
python3 scripts/generate_scatter.py --results-dir <dir> \
    --model-config references/model-config.json --per-machine \
    --preview-pages /tmp/fm
```

Then inspect `/tmp/fm/page1.png` (cover), `page2.png` (contents), `page3.png`
(summary) with `vision_analyze`. `--preview-pages` reuses the same group plan
and the same page functions as the real run, so what you inspect is what the
PDF contains — and it prints the last chart page so you can confirm the contents
entries land inside the document.

Do not "fix" a layout from a vision read alone. Two reads of a correct 28-label
plot both reported it as a stacked mess; measuring the rendered text extents
showed 16 overlapping pairs out of 378 and zero labels outside the axes. Confirm
geometry numerically before changing spacing.

---

Load methodology details on demand:
`skill_view(name='benchmark-model-fleet', file_path='references/benchmark-methodology.md')`

Load the optimization-comparison layer on demand:
`skill_view(name='benchmark-model-fleet', file_path='references/optimization-comparisons.md')`

Load Qwen3.8-27B-specific sweep config on demand:
`skill_view(name='benchmark-model-fleet', file_path='references/qwen38-27b-sweep-paths.md')`

## lm-evaluation-harness Benchmarking

For evaluating LLMs on academic benchmarks (MMLU, GSM8K, HumanEval, HellaSwag, TruthfulQA, ARC, WinoGrande), use the EleutherAI lm-evaluation-harness — the industry standard used by HuggingFace and major labs. Full task reference and API/distributed/custom-task guides live in the archived `evaluating-llms-harness` skill under `~/.hermes/skills/.archive/`.

### Quick setup

```bash
pip install lm-eval
```

### Core reasoning benchmarks

- MMLU (Massive Multitask Language Understanding) — 57 subjects, multiple choice
- GSM8K — Grade school math word problems
- HellaSwag — Common sense reasoning
- TruthfulQA — Truthfulness and factuality
- ARC (AI2 Reasoning Challenge) — Science questions

### Code benchmarks

- HumanEval — Python code generation (164 problems)
- MBPP (Mostly Basic Python Problems) — Python coding

### Backend options

- **HuggingFace**: standard, slower
- **vLLM**: 5-10x faster with PagedAttention

### Common issues

- **Slow evaluation:** use vLLM backend, reduce num_fewshot to 0, or evaluate subset of MMLU (mmlu_stem)
- **Out of memory:** use --batch_size 1 or load_in_8bit=True
- **HumanEval not executing code:** pip install human-eval and use --allow_code_execution
- **Different results than reported:** verify num_fewshot count and exact task name

### When to use vs benchmark-model-fleet

- Use **lm-evaluation-harness** when: benchmarking on academic standards (MMLU, GSM8K), comparing model quality with standardized prompts, reporting reproducible metrics
- Use **benchmark-model-fleet** (this skill) when: auditing a local model fleet for speed/quality tradeoffs, right-sizing deployments, generating scatter plots of model performance

## References

- `references/vision-benchmark-protocol.md`: vision run protocol, ranking rules, oMLX endpoint quirks (moved from MEMORY.md 2026-10-01)
