#!/usr/bin/env bash
# benchy.sh — thin wrapper around llama-benchy that supplies the two flags
# llama-swap requires and llama-benchy will not default to correctly.
#
#   ./benchy.sh <model-id> [extra llama-benchy flags...]
#
# Example:
#   ./benchy.sh ms-kat-coder-v2.5
#   ./benchy.sh ms-gemma-4-12b --pp 2048 --tg 64 --depth 0 8192 16384 32768
#
# The wrapper pins --latency-mode api (the generation probe includes
# llama-swap's on-demand model load, which zeroes est_ppt and drops the pp row
# from the table) and resolves --tokenizer from the verified fleet map.

set -euo pipefail

BASE_URL="${BENCHY_BASE_URL:-http://127.0.0.1:9292/v1}"
OUT_DIR="${BENCHY_OUT_DIR:-/Users/macstudio/.hermes/benchy}"

if [ $# -lt 1 ]; then
  echo "usage: $0 <model-id> [llama-benchy flags...]" >&2
  echo "  env: BENCHY_BASE_URL (default http://127.0.0.1:9292/v1)" >&2
  echo "       BENCHY_OUT_DIR  (default /Users/macstudio/.hermes/benchy)" >&2
  exit 2
fi

MODEL="$1"; shift

# Verified 2026-09-28 against llama_benchy.corpus.LightweightTokenizer.
# See references/tokenizers.md for provenance and the gated-repo notes.
case "$MODEL" in
  ms-devstral-24b)          TOK=mistralai/Devstral-Small-2-24B-Instruct-2512 ;;
  ms-gemma-4-26b-moe)       TOK=google/gemma-4-26B-A4B-it ;;
  ms-gemma-4-12b)           TOK=google/gemma-4-12B-it ;;
  ms-gemma-4-e4b)           TOK=google/gemma-4-E4B-it ;;
  ms-glm-4.6-vision)        TOK=zai-org/GLM-4.6V-Flash ;;
  ms-kat-coder-v2.5)        TOK=Kwaipilot/KAT-Coder-V2.5-Dev ;;
  ms-qwen3.6-35b-a3b)       TOK=Qwen/Qwen3.6-35B-A3B ;;
  ms-qwen3-coder-30b)       TOK=Qwen/Qwen3-Coder-30B-A3B-Instruct ;;
  ms-qwen3-vl-8b)           TOK=Qwen/Qwen3-VL-8B-Instruct ;;
  ms-gpt-oss-20b)           TOK=openai/gpt-oss-20b ;;
  ms-granite-4.2-3b)        TOK=ibm-granite/granite-4.2-3b ;;
  ms-granite-4.2-8b)        TOK=ibm-granite/granite-4.2-8b ;;
  ms-ministral-3-3b)        TOK=mistralai/Ministral-3-3B-Instruct-2512 ;;
  ms-qwen3.5-4b-mtp)        TOK=Qwen/Qwen3.5-4B ;;
  # Canonical repos are gated (401) -> verified same-family substitutes.
  ms-qwen3.8-27b-swift1.5)  TOK=Qwen/Qwen3.8-27B ;;
  ms-qwopus3.8-27b-flash)   TOK=Qwen/Qwen3.8-27B ;;
  ms-nuextract3)            TOK=Qwen/Qwen3.5-4B ;;
  ms-muse-glimmer-30b)      TOK="" ;;   # UNRESOLVED - supply --tokenizer yourself
  *)                        TOK="" ;;
esac

case "$MODEL" in
  ms-bge-*)
    echo "error: $MODEL serves embeddings; llama-benchy only hits /v1/chat/completions" >&2
    exit 2 ;;
esac

if [ -z "$TOK" ] && ! printf '%s\n' "$@" | grep -q -- '--tokenizer'; then
  echo "warning: no verified tokenizer for '$MODEL'." >&2
  echo "         llama-benchy will silently fall back to gpt2 and mis-size --pp/--depth." >&2
  echo "         pass --tokenizer <owner>/<repo> or a local dir. See references/tokenizers.md" >&2
fi

command -v llama-benchy >/dev/null 2>&1 || {
  echo "error: llama-benchy not on PATH (uv tool install llama-benchy)" >&2
  exit 127
}

mkdir -p "$OUT_DIR"
STAMP="$(date +%Y%m%d-%H%M%S)"
SAFE="$(printf '%s' "$MODEL" | tr -c 'A-Za-z0-9._-' '_')"

ARGS=(
  --base-url "$BASE_URL"
  --model "$MODEL"
  --latency-mode api
  --format json
  --save-result "$OUT_DIR/${SAFE}-${STAMP}.json"
)
[ -n "$TOK" ] && ARGS+=(--tokenizer "$TOK")

echo "benchy: $MODEL -> ${OUT_DIR}/${SAFE}-${STAMP}.json"
exec llama-benchy "${ARGS[@]}" "$@"
