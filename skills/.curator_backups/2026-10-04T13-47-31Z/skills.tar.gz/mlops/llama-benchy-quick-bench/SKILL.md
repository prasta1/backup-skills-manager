---
name: llama-benchy-quick-bench
description: Quick throughput + depth benchmarking via llama-benchy.
version: 0.1.0
author: Hermes
platforms: [macos, linux]
metadata:
  hermes:
    tags: [Benchmarking, LLM, LlamaCpp, Throughput]
---

# llama-benchy Quick Bench

Measure prompt-processing (prefill) t/s, decode t/s, TTFT, and depth degradation on any OpenAI-compatible endpoint using `llama-benchy`. It is the fast path for "how fast is this model, and does it fall off at 32K context" — a single warm run is seconds.

**What it does**: microbenchmarks an already-running endpoint. No model loads, no scoring rubrics, no plots.

**What it does NOT do**: quality or capability evaluation. It has zero notion of whether the model is *good*. For speed-vs-quality tradeoffs use `skill_view(name='benchmark-model-fleet')`; for academic suites use lm-evaluation-harness.

**Key dependency**: an OpenAI-compatible `/v1/chat/completions` endpoint (llama-swap on :9292) and the `llama-benchy` CLI. No other packages.

## When to Use

- "How fast is ms-kat-coder-v2.5 right now?"
- "Does decode fall off at 32K context?" (a `--depth` sweep)
- "Is the new GGUF quant faster than the old one?"
- "Is llama-swap actually using prefix caching, or is it re-prefilling?"
- "Give me prefill t/s and TTFT for these two models."

Do **not** use it to rank models by quality — it cannot see quality.

## Prerequisites

- llama-benchy installed (`uv tool install llama-benchy`; verify with `llama-benchy --version` through the `terminal` tool).
- An endpoint. Studio llama-swap: `--base-url http://127.0.0.1:9292/v1`.
- **`--model` is mandatory** on llama-swap. Auto-detection reads `/v1/models`, and the tool hard-errors when more than one model is listed — llama-swap has 20. Read live ids with `terminal`: `curl -s http://127.0.0.1:9292/v1/models`.
- **`--tokenizer` is mandatory in practice.** See Pitfalls — this is the one that silently corrupts results.
- Embedding/reranker models (`ms-bge-*`) cannot be benchmarked; they serve no `/v1/chat/completions`.

## How to Run

**Start here — the interactive front-end.** It asks what you're trying to
measure before spending any inference time, because the answer picks the flags
and the fastest and slowest options differ by ~100x:

```bash
python3 scripts/benchy_interactive.py
```

Five questions: goal (baseline / depth sweep / prefix caching / concurrency /
smoke / custom), which models, how many runs, is the box quiet, confirm. It
reads `catalog.json` when present to annotate models with size, capability, and
vision support, and it **refuses models whose GGUF is missing or is a broken
symlink** before spending a model load discovering that.

Add `--dry-run` to see the plan and the exact command per model without
running anything.

**One model, no questions** — the thin wrapper, via the `terminal` tool.
`benchy.sh` takes exactly one model id and does NOT sweep; use the interactive
front-end for more than one:

```bash
# Quick single-shot: prefill + decode on one model
scripts/benchy.sh ms-kat-coder-v2.5

# Explicit shape
scripts/benchy.sh ms-qwen3-coder-30b --pp 2048 --tg 128 --runs 3

# Depth sweep
scripts/benchy.sh ms-gemma-4-12b --pp 2048 --tg 64 --depth 0 8192 16384 32768
```

**Non-interactive** for cron or scripted use — replays a saved plan:

```bash
python3 scripts/benchy_interactive.py --non-interactive --profile plan.json
```

Raw invocation (what either wrapper expands to):

```bash
llama-benchy \
  --base-url http://127.0.0.1:9292/v1 \
  --model ms-granite-4.2-3b \
  --tokenizer ibm-granite/granite-4.2-3b \
  --pp 2048 --tg 128 \
  --latency-mode api \
  --format md --save-result /Users/macstudio/.hermes/benchy/out.json
```

Long sweeps go to the background: `terminal(command=..., background=True, notify=True)`.

## Quick Reference

| Flag | Default | Notes |
|------|---------|-------|
| `--base-url` | required | e.g. `http://127.0.0.1:9292/v1` |
| `--model` | auto | **Always pass on llama-swap** |
| `--tokenizer` | = model | **Always pass**; HF `namespace/model` or local dir |
| `--pp` | `2048` | Prompt-processing token counts, nargs+ |
| `--tg` | `32` | Generation token counts, nargs+ |
| `--depth` | `0` | Synthetic prior-context tokens, nargs+ |
| `--runs` | `3` | Timed runs per shape |
| `--warmup-runs` | `1` | Discarded warmups; `0` for a fast run |
| `--latency-mode` | `api` | **Use `api`.** `generation` breaks pp on llama-swap |
| `--exact-tg` | off | Sends `min_tokens`+`ignore_eos` to pin output length |
| `--no-cache` | off | Unique requests + `cache_prompt=false` |
| `--enable-prefix-caching` | off | Two-step cached-vs-cold measurement (needs `--depth > 0`) |
| `--concurrency` | `1` | nargs+; llama-swap serializes, so this tests the proxy |
| `--format` | `md` | `md` / `json` / `csv` |
| `--save-result` | — | Output file |
| `--emit-progress PATH` | off | JSONL event stream; `-` for stdout |
| `--skip-coherence` | off | Bypass the Paris gate |
| `--extra-body k=v` | — | Merged into each request body |

Run order for multiple values is **depth → pp → tg → concurrency** (all combinations).

Result columns: `t/s`, `peak t/s` (decode only), `ttfr`, `est_ppt`, `e2e_ttft`; `t/s (total)` / `t/s (req)` appear when `--concurrency > 1`. Rows are labelled `pp2048`, `tg32`, `pp2048 @ d8192`, `ctx_pp @ d8192`.

`benchy_interactive.py` emits one JSON per model into a timestamped run dir and writes `plan.json` recording the exact shape, so any run can be replayed with `--non-interactive --profile`.

### Measurement goals (the first question it asks)

| Goal | Shape | Answers |
|------|-------|---------|
| `quick` | pp 2048, tg 128, depth 0 | "how fast is it" |
| `depth` | pp 2048, tg 64, depth 0/8K/16K/32K | "does it fall off at length" |
| `cache` | as depth + `--enable-prefix-caching` | "is the prefix being reused" |
| `load` | pp 2048, tg 64, concurrency 1/2/4 | "how does it behave under load" |
| `smoke` | pp 256, tg 32, 1 run, no warmup | "is it alive" |
| `custom` | you type pp/tg/depth | anything else |

Measured cost: `smoke` on one warm 3B is ~2s; `quick` on one cold 24B is ~2 min; `depth` across all 16 benchmarkable models is ~2h20. The confirm-step estimate budgets a full cold load per model, so it errs high.

## Procedure

1. **Resolve the model id** — `terminal`: `curl -s http://127.0.0.1:9292/v1/models`. Never type an id from memory; the 2026-09-10 `studio-*` → `ms-*` rename hard-404s stale ids with "no router for requested model" and no fallback.

2. **Resolve the tokenizer** — look the id up in `references/tokenizers.md`, or let `scripts/benchy.sh` do it. Every id in that table was load-tested; entries marked UNRESOLVED need `--tokenizer` supplied by hand.

3. **Warm the model first.** llama-swap loads on demand (ttl 900). The first request absorbs the load. A cold granite-4.2-3b run took 3m28s wall clock; the same run warm took **2.3s**. Fire one throwaway completion before timing anything.

4. **Run the baseline shape** — `--pp 2048 --tg 128 --runs 3 --latency-mode api`. Confirm the pp row appears in the table; if it doesn't, see Pitfalls.

5. **Add a depth sweep** when context behavior is the question: `--depth 0 8192 16384 32768`. Depth is the single most useful axis here — decode t/s at depth 0 says nothing about how the model feels in a real 30K conversation.

6. **Save JSON** for anything you intend to compare later: `--format json --save-result <path>`. `json` is the only format that carries the per-metric `mean`/`std`/`values` structure, so md tables can't be diffed programmatically.

7. **Isolate the box** for numbers you intend to act on. A resident LM Studio model or a second loaded llama-swap model corrupts decode t/s. Check before and after.

## Pitfalls

- **The interactive front-end will not prompt without a tty.** `benchy_interactive.py` exits 2 if stdin is not a terminal, so piping answers in silently does nothing. Drive it from a real terminal, or use `--dry-run` / `--non-interactive --profile`.

- **Depth can exceed a model's context and the run fails or truncates.** The interview warns when `max(depth) + 2048` exceeds a model's `--ctx-size` from `catalog.json`. Most of the fleet is 65536 so depth 32768 is safe; the `ms-bge-*` pair at 8192 is not benchmarkable anyway.

- **`ms-qwopus3.8-27b-flash` is registered but not on disk.** Broken GGUF symlink with escaped backslashes in the target. Auto-excluded by the interactive front-end and flagged by the `fleet-catalog` skill. Benchmarking it wastes a model load and then fails.

- **`ms-qwen3.5-4b-mtp` is NOT broken — this note used to say it was, and it was wrong.** Verified serving 2026-10-01 (HTTP 200, 124.7 tok/s, MTP draft 75/79). It is also excluded by the interactive front-end, so do not trust that exclusion. The cause of the confusion is real but different: it is the ONLY Qwen model whose bytes live outside `~/models`, sitting in a symlink that resolves into the superseded `~/.hf/hub` cache. It resolves fine today because that cache still exists. Anyone auditing "which models are outside the canonical tree" should expect exactly this one, and should check `[ -e "$(readlink -f ...)" ]` rather than assuming a path shape means breakage.

- **`--latency-mode generation` silently deletes the prefill row on llama-swap.** The probe sends `max_tokens=1, stream=True` and times to the first response chunk — which on llama-swap includes on-demand model load. Measured: 48,573 ms and 11,187 ms average "latency" on a 3B model. Since `est_ppt = max(0, ttfr − latency)`, that zeroed `est_ppt` to 0.0 and **the entire `pp` row vanished from the results table** with no warning. With `--latency-mode api` the same command reported `pp256 = 2055 t/s, est_ppt 125.51 ms`. The upstream README recommends `generation`; ignore it on llama-swap.

- **Omitting `--tokenizer` silently falls back to gpt2.** llama-swap ids like `ms-granite-4.2-3b` are not `namespace/model`, so the HF lookup 401s and the tool prints a two-line error, then continues with `gpt2`. Prompt sizing, `--pp`, and `--depth` are then counted in gpt2 tokens, not the model's. Observed: the same corpus measured 171,736 tokens under gpt2 vs 143,827 under the real Ministral tokenizer — a 19% error, silently applied to every prefill number. The corpus cache is keyed on URL, not tokenizer, so switching tokenizers silently re-slices the same cached book.

- **The coherence test is a hard gate.** After warmup the tool asks "capital of France, one word" and exits with status 1 unless `paris` appears in `content`, `reasoning`, or `reasoning_content`. It reads reasoning fields, so thinking models pass, but a small or heavily-quantized model can still fail a healthy endpoint. Pass `--skip-coherence` when you've already validated the model.

- **Gated HF repos return 401 and fall back to gpt2.** `numind/NumExtract3-1.5`, `swiftlang/Swift-1.5`, `inclusionAI/Muse-Glimmer-30B`, and `Qwen/Qwen3.8-27B-Flash` all 401 unauthenticated. `references/tokenizers.md` lists a load-tested substitute for each; set `HF_TOKEN` to use the canonical repo.

- **First run of a new corpus downloads Sherlock Holmes** from Project Gutenberg into `~/.cache/llama-benchy/<md5>.txt`. Needs outbound network; subsequent runs read the cache.

- **Block-streaming backends report blank decode t/s.** If the server emits the whole response in one content-bearing chunk, `t/s` is left empty rather than printing a protocol-timing artifact. llama-swap streams properly, so this bites oMLX/LM Studio more than the proxy.

- **`--concurrency > 1` measures llama-swap, not the weights.** The proxy serializes per model. The table labels are honest (`t/s (total)` vs `t/s (req)`) but the result says more about queueing than inference.

- **llama-benchy does not unload models.** It leaves whatever it loaded resident for the ttl window. Benchmarking a long list back-to-back will hold each model for 15 minutes after its run.

- **Depth sweeps are slow, not instant.** `--pp 512 --tg 64 --depth 0 4096` on granite-4.2-3b took 6m25s wall clock, nearly all of it the cold load plus the 4096-token prefill. Budget minutes, not seconds, and run it in the background.

- **Performance only.** llama-benchy measures throughput and latency; it says nothing about output quality (chat or data-analysis correctness). Use benchmark-model-fleet for quality.

## Comparing two configurations: `scripts/llm-abtest.py`

`llama-benchy` answers "how fast is this model". It does **not** answer "is
config X faster than config Y", which is the question behind every tuning
lever. This harness does, and its whole purpose is to refuse to call a
difference real when it is noise.

**Why a separate tool.** Measured on this box (ms-ministral-3-3b, 128 pinned
output tokens, 8 runs): mean 122.97 tok/s, sd 2.15, **CV 1.75%**, with a
**-1.6% drift inside a single 10-second window**. So a "run A, change flag,
run B" comparison hands the entire drift to whichever arm ran second, and any
result under ~2% is unfalsifiable. Minimum detectable effect by pair count:

| pairs | MDE |
|-------|-----|
| 4 | ±4.1% |
| 6 | ±2.8% |
| 8 | ±2.3% |
| 10 | ±2.0% |

Paired interleaving roughly halves the noise: the same 8-pair null test gave
sd 1.05 tok/s paired vs ~2.0 unpaired, MDE 1.00% vs 2.29%.

```bash
# Step 1 — always do this first. Establish YOUR noise floor.
scripts/llm-abtest.py noise --model ms-ministral-3-3b --pairs 8

# Step 2 — request-level lever against the live endpoint, no config touched
scripts/llm-abtest.py ab --model ms-gemma-4-26b-moe \
    --request temperature=0.7 --pairs 6

# Step 3 — server-level lever. Spawns a PRIVATE llama-server per arm;
# never touches the llama-swap config or the production endpoint on :9292.
scripts/llm-abtest.py ab --model ms-gemma-4-26b-moe \
    --model-path ~/models/gguf/unsloth/gemma-4-26B-A4B-it-qat-GGUF/gemma-4-26B-A4B-it-qat-UD-Q4_K_XL.gguf \
    --flag=--parallel=2 --pairs 6

# Step 4 — the only honest way to evaluate --parallel: concurrent clients
scripts/llm-abtest.py ab --model m --model-path <gguf> \
    --flag=--parallel=2 --pairs 6 --concurrency 4
```

Verdicts are `WIN`, `LOSS`, or `INCONCLUSIVE`, and a difference must clear
**both** p<0.05 **and** the MDE bar before it is called anything. `INCONCLUSIVE`
is the expected default, not a failure.

### Pitfalls

- **`--flag=--parallel=2`, not `--flag --parallel=2`.** argparse reads a
  value beginning with `-` as the next option. The script normalises
  `--name=value` into two argv entries because **llama.cpp's own parser
  rejects the `=` form** — `--parallel=2` dies with `error: invalid argument`.
  Either spelling works on the command line; both reach llama.cpp as
  `--parallel 2`.

- **Server mode pins `--ctx-size` to 8192 by default, and it must.** Leaving
  context at the model's trained maximum makes each private server allocate a
  full-size KV cache; two of them exhaust the Metal buffer pool and both die
  with `Insufficient Memory` — *not* a system-OOM, and not fixable by having
  96 GB. Metal's buffer pool is far smaller than system RAM on unified memory.
  Pass `--ctx N` to raise it when context is the variable under test.

- **Two full-size servers may still not fit alongside resident llama-swap
  models.** The preflight prints resident GB and warns. If a server dies with
  `Insufficient Memory`, let the resident models expire past their `ttl`, or
  shrink `--ctx`. Arm A's log is `/tmp/abtest-<port>.log`.

- **`min_tokens` pins the output; without it you are timing EOS luck.** Every
  rep sends `min_tokens = max_tokens = --tokens` at `temperature 0`, so decode
  work is identical across arms. Raise `--tokens` for a stabler t/s estimate —
  at 128 the per-run sd was ~2%, at 64 it roughly doubles.

- **A reasoning model can look like it returned nothing.** Arm B's coherence
  check reads `reasoning_content` as well as `content`; without that, a
  thinking model burns the 96-token probe budget on a preamble and fails a
  healthy server. This is the same trap that made `ms-qwen3.5-4b-mtp` look
  invalid in the first place.

- **Use `--served-name` when the private server is not llama-swap.** A
  standalone `llama-server` answers to whatever name you send in the body;
  `llm-abtest.py ab --model-path ... --served-name m` sends `m`.

- **Never test a lever with `--parallel > 1` at concurrency 1.** One client
  cannot occupy two slots, so the measurement is guaranteed inconclusive —
  as it should be. That is a true negative, not a harness bug.

- **Do not port any of these numbers between machines.** Same rule as
  `--spec-draft-n-max` above; see the top of `config.yaml`.

## Verification

```bash
scripts/benchy.sh ms-granite-4.2-3b --pp 256 --tg 32 --runs 1 --warmup-runs 0
```

`llm-abtest.py` has its own statistics test — run it after touching any of
the math:

```bash
python3 scripts/validate_abtest.py   # must print "all statistics validated"
```

It checks `t_sf`/`t_ppf` against Simpson integration and published critical
values, `betainc` against the integer-parameter binomial sum, MDE against its
own closed form, and the paired test against a hand calculation. Two bugs it
caught during development, both of which would have produced confident wrong
verdicts: `mde()` looked up its power term at `1-power` against a two-sided
inverse (targeting the 90th percentile, inflating MDE ~1.17x), and an
all-zero difference set returned p=0.0 instead of p=1.0.

Pass condition — a table with **two** rows and non-zero `est_ppt`:

```
| ms-granite-4.2-3b |  pp256 |  2055.61 ± 0.00 |  127.93 ± 0.00 |  125.51 ± 0.00 |  127.93 ± 0.00 |
| ms-granite-4.2-3b |   tg32 |   122.42 ± 0.00 |                |                |                 |
```

A `tg`-only table means the prefill row was lost — go back and check `--latency-mode`. A `Falling back to 'gpt2' tokenizer` line means `--tokenizer` is missing.

---

Load the verified model→tokenizer map on demand:
`skill_view(name='llama-benchy-quick-bench', file_path='references/tokenizers.md')`
