# Operations Notes (migrated from MEMORY.md 2026-09-13)

Procedural/troubleshooting content migrated out of the always-injected memory store during the
2026-09-13 prune. Memory is capped at 12K chars and re-sent on every turn, so procedures belong
here where they load only when relevant. Source snapshot: `git -C ~/.hermes show 91b3be0:memories/MEMORY.md`.

## Alert routing on the Studio (audited 2026-09-16)

Everything infra-alerting is **Discord-only, and has been since 2026-08-28**; Telegram keeps only
two paths (deadman + gateway lifecycle notices), both documented below. Map:

| Producer | Where it pages |
|---|---|
| Outcomes 1h, Memory 5m, Health 5m, Embedding 15m, Auth 15m, Gateway Lifecycle 1m, Weekly Report | Discord #alert-infra `1522663709091168537` (via cron `deliver`) |
| `hermes-git-backup.sh` (launchd, daily 03:30) | Discord #alert-infra, posted by the script itself via `hermes send -t discord` — independent of the cron ticker |
| `watchdog_deadman.sh` (launchd, 10m) | **Telegram DM only** (`hermes send -t telegram`: home channel) — ticker staleness + broken alert path |
| Gateway start/stop notices | Both DMs (Discord `1539964352575307797` + Telegram `2058810010`) |
| Briefs / Gmail triage | #news-brief `1542864535826735194` / #alert-email `1544358067318038568` |

**Coverage gaps that remain:** Prometheus/node_exporter/blackbox/Grafana all run with **zero alert
rules**; Mnemosyne `sync-serve` has no watcher (its 6h health cron is disabled);
`llama_swap_monitor.py` posts to #alert-infra but nothing schedules it (dormant).

**How to audit this class of question:** read `j['deliver']` for every job in
`~/.hermes/cron/jobs.json`, then grep `~/.hermes/scripts/*.sh` for direct `"$HERMES_BIN" send -t`
calls (script-level sends bypass cron routing entirely), then
`/usr/libexec/PlistBuddy -c "Print :ProgramArguments" ~/Library/LaunchAgents/*.plist` for launchd
producers. `delivery_outcome` in `~/.hermes/cron/executions.db` shows `delivered` vs `suppressed`
(empty output) vs null, but not the target.

## Prometheus / node_exporter / Grafana (Studio)

All three are brew services (`sh.brew.prometheus`, `sh.brew.node_exporter`, `sh.brew.grafana`).
Prometheus 3.14 binds loopback `:9090`; since 2026-09-16 it is also reachable tailnet-only at
`https://studio.taile85139.ts.net:9090` via `tailscale serve --bg --https=9090 http://127.0.0.1:9090`.
**Grafana is on `:3001`; `:3000` is Open WebUI (OrbStack).** Retention 15d.

- **No alert rules anywhere**: Prometheus has no `rule_files`, Grafana has 0 rows in `alert_rule` and
no receivers. The stack can be read, never pages.
- Metric sources: `macmon` (job `studio`/`macbook`, `:9199`, CPU/GPU/RAM/power/temp), node_exporter
(`:9100`) with the **textfile collector** at `/opt/homebrew/var/node_exporter/textfiles`, and
blackbox HTTP probes (`:9115`). Collector jobs (`com.*.textfile`) rewrite `agent_health.prom`,
`hermes_usage.prom`, `claude_code_usage.prom` every few minutes; series land under `job="node-studio"`.
- `hermes_model_*` labels: `host`, `model`, `provider`, `kind` (input/output/cache_read/reasoning),
`tier` (cloud/local/unknown). `claude_code_*` adds `project`. `agent_running` /
`agent_last_exit_status` are keyed by launchd `label`.
- **Prometheus has no saved dashboards or image export**, so the repeatable views are
  (a) bookmarks: `/query?gN.expr=...&gN.tab=0|1&gN.range_input=24h` (any number of graphs, tab=1 is
  the table view), and (b) `~/.hermes/monitoring/prom_snapshot.py --hours N`, which renders
  `fleet/studio/usage/claude_code.png` from the query API. Query cheatsheet:
`~/.hermes/monitoring/prometheus-queries.md`.
- **macOS tailnet self-test trap:** you cannot curl your own `100.x` address from the node that owns
it (no `tailscale0`); a `000` there is not evidence the service is unreachable. Verify from another
node.

## The outcomes watchdog (`scripts/watchdog_outcomes.sh`)

Hourly `no_agent` job `a51280fccc82`; stdout is the alert, empty output = healthy. Sections: cron
status/delivery errors, git-backup freshness, **hindsight dump freshness (added 2026-09-16)**, runaway
`hermes serve`, MCP servers enabled-but-failing. Tunables are env vars:
`OUTCOMES_MAX_SERVE`, `OUTCOMES_BACKUP_MAX_AGE_H` (36), `OUTCOMES_MCP_MAX_AGE_SEC` (8h),
`OUTCOMES_HINDSIGHT_MAX_AGE_H` (**80h** — the dump job is Mon/Wed/Fri, so 36h false-pages every
Monday), `OUTCOMES_ALERT_REPEAT` (5 cycles before auto-ack and quiet for 24h).

- The hindsight check reads the **newest dump's mtime** (`~/backups/hindsight/hindsight-*.dump`),
not the log text — the log's `Sun Sep 13 03:10:07 EDT 2026` stamps need locale/zone parsing.
- `alert_key <key> <msg>` turns the key into a **filename**, so the key is sanitized to
`[:alnum:]._:-` before use. An unsanitized key (a cron message containing `/` and a newline) built a
nonexistent nested path, the state write failed under `set -e`, and the watchdog died silently —
taking every alert it exists to send with it.
- Silence one alert by hand: `~/.hermes/scripts/ack_outcomes.sh <key>` (`-r` to un-ack). State lives
in `~/.hermes/state/watchdog-outcomes/<key>.{count,first_seen,last_seen,ack_until,sig}`.
- **Test edits in an isolated `HERMES_HOME`**, not just `bash -n`: the script dies on a missing
`cron/jobs.json`, so a real-state dry run proves nothing about the branches you added.

Procedural/troubleshooting content migrated out of the always-injected memory store during the
2026-09-13 prune. Memory is capped at 12K chars and re-sent on every turn, so procedures belong
here where they load only when relevant. Source snapshot: `git -C ~/.hermes show 91b3be0:memories/MEMORY.md`.

Procedural/troubleshooting content migrated out of the always-injected memory store during the
2026-09-13 prune. Memory is capped at 12K chars and re-sent on every turn, so procedures belong
here where they load only when relevant. Source snapshot: `git -C ~/.hermes show 91b3be0:memories/MEMORY.md`.

## macOS / Tailscale networking

- macOS Tailscale uses the **utun4** interface; there is **no `tailscale0`**. Binding a process to
a `100.x` address directly will not work.
- **RETIRED 2026-09-27**: the Hermes web UI (`127.0.0.1:8787`, `com.hermes.webui`) is disabled.
It was NOT tailnet-exposed despite this note and its own launcher comment claiming so — `tailscale
serve` maps 5200, 6333, 8010, 8188 and 8642, never 8787. Nothing depended on it (no hermes-agent
call sites, cron `platform: webui` is provenance only, state dir last written Sep 22), so it was
retired rather than repaired. See DEV-408.
- The tailnet binding rule still applies to the services that ARE served: bind loopback and let
`tailscale serve` map them; clients reach those only on the tailnet with **MagicDNS enabled**.

## Gateway: lifecycle, launchd, Photon

- The Studio gateway runs as a launchd service. Restart with the modern syntax:

```bash
launchctl bootout gui/$(id -u)/ai.hermes.gateway
sleep 3
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/ai.hermes.gateway.plist
```

- **The agent cannot restart the gateway from inside it** — the guard blocks it (SIGTERM would kill
the command before it completed), and a detached/delayed wrapper is refused too. Hand the user
`/restart` in chat (graceful; drains active runs first) or `hermes gateway restart` from a shell
outside the app.
- **Photon sidecar** needs `npm install` in `plugins/platforms/photon/sidecar/`.
- API server listens on **:8642**; desktop app remote is `studio.taile85139.ts.net:9119`.
- MBP convenience aliases: `hstudio`, `hrun` (plus `hwork`, `hpersonal`).

## Gateway lifecycle notifications

Sent per-platform to the HOME channel, gated by `gateway_restart_notification` (currently `true`).
There is **no dedicated alerts-channel routing in core** (feature request filed:
NousResearch/hermes-agent #76780). These are the **only** messages that still reach Telegram: the
start/stop notice goes to the Telegram DM `2058810010` *and* the Discord DM
`1539964352575307797`.

**Destination control lives in the cron job's `deliver`, not in config.** `telegram.allowed_chats`
is an *inbound group gate* (`plugins/platforms/telegram/adapter.py::_check_group_trigger_rules`,
skipped entirely when empty) — it never routed outbound alerts. To retire a platform as an alert
target, edit every job's `deliver` string (set with `hermes cron ...`; tracked in
`~/.hermes/cron/jobs.json`, which the git backup commits, so the switch is auditable).

Legacy Telegram alerts channel: `-1003940233719` ("Hermes Alerts"). It was the watchdog fan-out
target until 2026-08-28, when every watchdog job's `deliver` became Discord-only. The bot is still
an admin of it; `allowed_chats` no longer lists it. To stop it cold, remove the bot from the
channel (or leave it — nothing targets it).

## config.yaml corruption pattern (Hermes)

List-valued fields (`plugins.enabled`, `model_catalog.excluded_providers`) sometimes get written as
Python/JSON **strings** instead of YAML lists. They still load, and are silently ignored. Fixed
`plugins.enabled` on the Studio 2026-08-02; filed Linear DEV-347.

**Always type-check list fields when auditing config.** To hide a provider from Hermes pickers use
`model_catalog.excluded_providers` — `hermes tools disable` does **not** hide providers.

Remember `hermes config set <key> <value>` is the only sanctioned write path; the `patch` tool
refuses `config.yaml` outright.

## `memory` tool: `replace` on `target=user` clobbers the whole file

Verified 2026-09-17. Calling the memory tool with `action=replace`, `target=user`, and an `old_text`
substring that matched inside the **first** entry rewrote `USER.md` down to that entry plus the
trailing one. 5,528 chars and 9 `##` sections became 769 chars and 2 entries. The other 8 sections
(Identity, Professional, Qualcomm accounts, Home AI Stack, Communication Preferences, Technical
Conventions, Community, Interests) were gone from disk.

**Never use the memory tool to edit USER.md.** Edit `~/.hermes/memories/USER.md` directly with the
`patch` tool, then re-check the section count. Same care for MEMORY.md.

Recovery path, in order:

1. `git -C ~/.hermes show HEAD:memories/USER.md` — `memories/` is in the .gitignore allowlist, so the
   pre-clobber version is in git. This is the fastest and most complete source.
2. `~/.hermes/memories/USER.md.bak-prune-*` — prune-era backups, older but present.
3. Before restoring, confirm byte size **and** `grep -c '^## '` against the known-good counts.

Then prove the restore with `git diff memories/USER.md`: the diff must contain only the intended
change. A diff showing whole-file replacement means the restore is wrong.

One follow-on trap: `memories/` is whitelisted, so any stray file dropped there (e.g. a
`.CLOBBERED-*` rescue copy) gets committed by the next backup run. Clean up rescue copies.

## Disabling an MCP server

`hermes mcp` has **no `disable` subcommand**. Manually comment out or remove the server in
`~/.hermes/config.yaml` under **both** `mcp.servers` and any later top-level block, then restart the
gateway. (See also the MCP auth/reload traps in SKILL.md — an already-registered server keeps
retrying with its captured config until the process reloads.)

## Dashboard auth internals

Dashboard auth uses an `scrypt` `password_hash` plus an HMAC secret. A past OAuth mismatch turned
out to be a **redirect URI mismatch**, fixed by matching the dashboard's canonical URL.

## Git / GitHub

- GitHub hard-blocks objects over **100 MB** (e.g. `state.db`). Keep them excluded from commits or
pushes fail.
- Hermes backup remote: origin is `https://github.com/prasta1/backup-hermes-macstudio.git`.

## Skills directory hygiene (historical churn, resolved)

`~/.hermes/skills/` accumulated symlinks/submodule pointers to `~/.agents/skills/`, which produced
unworkable ~394-file git churn. Symlinked external skill roots also make "every SKILL.md change is a
normal file modification" an unsafe assumption when staging.

**Standing rule: skills live as real directories under `~/.hermes/skills/`.** If the churn returns,
restore by copying the real trees from `~/.agents/skills/` back in as normal directories.

## OOM triage

Distinguish three cases: **container cap hit** vs **leak** vs **host-pressure collateral kill**.
LM Studio Metal OOM plus orphan helper processes plus low `vm_stat` free pages indicates *host
pressure*, not a container limit.

## Hermes-webui vs gateway (separate launchd jobs)

`hermes-webui/server.py` (`com.hermes.webui`, :8787, **retired/disabled 2026-09-27**) and the
gateway (`ai.hermes.gateway`, :8642) are **separate launchd jobs**. The 409 `agent_runtime_stale` fix is to set config.yaml
`webui_chat_backend: gateway` and export the gateway-mode env vars in `hermes-webui-launch.sh`.
That workaround is retired.

**Quirk:** `/api/health/agent`'s `gateway_chat` field reads **env vars only**, never config.yaml.

## `hermes update` merge conflict on the custom `local` branch

The updater tracks `local` (fork branch: discord brief embeds, config/email fixes) and merges
`origin/main` **in place** rather than resetting. On conflict it aborts the whole update and
leaves the tree unchanged — nothing was half-applied, so resolve in
`~/.hermes/hermes-agent` and re-run.

1. **Preview without touching the tree:** `git merge-tree --write-tree --name-only local origin/main`
   (git ≥ 2.38) prints the conflicted paths. Expect it to be one file, not many.
2. `git merge origin/main` — let every other file auto-merge.
3. **Resolve by keeping BOTH sides; never drop the local side.** Read both diffs against the
   merge base (`git diff $(git merge-base local origin/main) <side> -- <path>`).
4. **The trap: an upstream refactor of the block your local code sits next to.** Keeping the
   local hunk verbatim re-introduces a stale override that silently reverts upstream's
   refactor. In the Sep-2026 merge, upstream replaced `DiscordAdapter.send_exec_approval` with
   `_EA_*` constants + `_exec_approval_cmd_budget` + `_send_exec_approval_prompt`, moving the
   public method to `BasePlatformAdapter`. Correct resolution: keep the local additions
   (`_parse_brief_content`, `_send_brief_embed`), **delete** the local `send_exec_approval`
   override, splice upstream's block after it.
   Verify the deletion landed: `'send_exec_approval' in DiscordAdapter.__dict__` must be
   `False` while `hasattr(...)` stays `True` via the base class.
5. **Take upstream's helper swaps inside the same hunk** — e.g. local `return {"error": ...}`
   became upstream `send_error(...)` from `gateway.platforms._shared`. Keep upstream.
6. Verify before committing: no leftover markers (`grep -n '^<<<<<<<\|^>>>>>>>\|^=======$'`),
   `python3 -m py_compile <file>`, then import the plugin for real:
   `./venv/bin/python3 -c "import importlib; importlib.import_module('plugins.platforms.discord.adapter')"`.
   **The Studio has NO pytest in any venv or system Python — the MacBook is the only box that runs
   the suite** (`venv/bin/python`, pytest 9.1.1 as of 2026-10-02). Sync changed files over SSH to
   run tests there; verify they match with `shasum -a256` before trusting a result.
7. `git add <paths> && git commit --no-edit`, confirm
   `git rev-list --left-right --count local...origin/main` ends in `0`, then re-run `hermes update`
   to finish dependency sync + service restart.

**Never `git reset --hard` or rebase to "fix" this** — local commits must survive.

## Two-machine commits: verify the parent before calling it a fork (2026-10-02)

The Studio and the MacBook each hold a `local` checkout of `~/.hermes/hermes-agent`. A change made
on both produces **two commits with different SHAs that share the same parent** — siblings, not a
diverged history. Confirm with `git rev-parse HEAD^` on each before characterizing it:

```
Studio:  edd949fc15  ─┐
                      ├─ parent: 1bb632be38  (identical)
MBP:     6c370f2778  ─┘
```

Identical trees, differing tips. **There is nothing to reconcile and no work is lost** — the only
consequence is that a future `git push` from one side cannot fast-forward the other, which needs a
`fetch` plus `reset --hard` (or a cherry-pick), not a merge.

**Do not infer divergence from differing SHAs.** During the Honcho prune I reported the two commits
as having "no shared ancestry" by reasoning from the SHAs alone, without checking parents. They
shared full ancestry, one commit deep. Read `HEAD^` before making any claim about fork state.

Pick a canonical machine at the moment you first push or open a PR — not before. While `local` stays
unpushed (deliberately: it carries ~40 private patches absent from any remote), duplicated local
commits cost nothing.

## Wide pytest sweeps on the MacBook: raise the fd limit first

The MBP shell has `ulimit -n 256`. Running thousands of tests in one pytest process exhausts file
descriptors and produces a wall of `OSError: [Errno 24] Too many open files` reported as mass `E`
errors that look exactly like broken code. Measured 2026-10-02: the same sweep reported mass errors
at the default limit and **2207 passed** with the limit raised.

```bash
ssh macbookpro 'cd ~/.hermes/hermes-agent && ulimit -n 10240 && venv/bin/python -m pytest tests/hermes_cli/ -q -p no:randomly'
```

`pytest-timeout` is **not** installed (`--timeout=` is an unrecognized argument), so bound a run
with the shell `timeout` command instead.

**Establish a baseline before blaming your own change.** `git stash push --include-untracked`,
re-run, `git stash pop`. Two known pre-existing failures on the MBP as of 2026-10-02:
6 in `tests/hermes_cli/test_commit_build_cli.py` and 2 Telegram collection errors from a missing
`python-telegram-bot`. Both reproduce identically with changes stashed.

Also: `ulimit -n 256` on the MBP means a *partial* run can hide which failures are real. Read the
actual `AssertionError`, not the pass/fail list — during this prune two successive "fixes" were
attempts against a false negative (a piped-away merge exit code read as "0 conflicts" when the
merge had failed outright).

## Bundled plugins: the greyed-out capability list is a directory scan

Settings -> Capabilities enumerates providers by **iterating the plugin directories**, not from any
config flag. `plugins/memory/_iter_provider_dirs()` is a bare `iterdir()` over
`plugins/memory/`, first-seen-wins across bundled, user, and project roots. There is **no exclusion
or tombstone mechanism** — `hermes plugins disable memory/<name>` does not work for bundled
providers (they are not in the plugin registry, so the command reports "No plugin named ...").

So a greyed-out row for a bundled provider is not a stale config entry. It means the directory
exists and no config file was found at any `resolve_config_path()` candidate. The only way to
remove one is to delete its directory from the checkout, which means a local commit that the next
`hermes update` will re-conflict against — see the `hermes update` section above. Enable
`git config rerere.enabled true` (done 2026-10-02 on both machines) so repeat conflicts resolve
themselves.

Deleting a bundled provider does **not** stop `hermes update` from calling into it: check
`hermes_cli/update_cmd_maint.py` for per-update syncs that import the removed module. The Honcho
removal found `_sync_profiles_after_update()` calling `import_provider_module("honcho", "cli")` on
every update, hidden inside `suppress(Exception)` — it could not crash the update, which is exactly
why it would have failed silently forever.

## Codebase review method

When reviewing an entire codebase with no fixed point, classify findings as: **hard break**,
**latent risk**, **polish/data quality**. Report exact `file:line` references and lead with what is
currently broken before latent risk or polish.

## Disk space: Time Machine local snapshots

Local Time Machine snapshots pin disk blocks after deletion, so `df -h` under-reports free space. Reclaim with `sudo tmutil thinlocalsnapshots /` (needs a real Terminal; the Hermes TUI has no sudo TTY).
