---
name: comfyui
description: Generate images, video, and audio via diffusion workflows.
version: 5.1.0
author: [kshitijk4poor, alt-glitch, purzbeats]
license: MIT
platforms: [macos, linux, windows]
compatibility: "Requires ComfyUI (local, Comfy Desktop, or Comfy Cloud) and comfy-cli (auto-installed via pipx/uvx by the setup script)."
prerequisites:
  commands: ["python"]
setup:
  help: "Run scripts/hardware_check.py FIRST to decide local vs Comfy Cloud; then scripts/comfyui_setup.sh auto-installs locally (or use Cloud API key for platform.comfy.org)."
metadata:
  hermes:
    tags:
      - comfyui
      - image-generation
      - stable-diffusion
      - flux
      - sd3
      - wan-video
      - hunyuan-video
      - creative
      - generative-ai
      - video-generation
    related_skills: [stable-diffusion]
    category: creative
---

# ComfyUI

Generate images, video, audio, and 3D content through ComfyUI using the
official `comfy-cli` for setup/lifecycle and direct REST/WebSocket API
for workflow execution.

## What's in this skill

**Reference docs (`references/`):**

- `official-cli.md` — every `comfy ...` command, with flags
- `rest-api.md` — REST + WebSocket endpoints (local + cloud), payload schemas
- `workflow-format.md` — API-format JSON, common node types, param mapping
- `template-integrity.md` — converting `comfyui-workflow-templates` from
  editor format to API format: Reroute bypass, dotted dynamic-input keys
  (`values.a`, `resize_type.width`), Cloud quirks (302 redirect, 1 concurrent
  free-tier job, 1080p VRAM ceiling), Discord-compatible ffmpeg stitch.
  Authored by [@purzbeats](https://github.com/purzbeats). Load this whenever
  you're starting from an official template.

**Scripts (`scripts/`):**

| Script | Purpose |
|--------|---------|
| `_common.py` | Shared HTTP, cloud routing, node catalogs (don't run directly) |
| `hardware_check.py` | Probe GPU/VRAM/disk → recommend local vs Comfy Cloud |
| `comfyui_setup.sh` | Hardware check + comfy-cli + ComfyUI install + launch + verify |
| `extract_schema.py` | Read a workflow → list controllable params + model deps |
| `check_deps.py` | Check workflow against running server → list missing nodes/models |
| `auto_fix_deps.py` | Run check_deps then `comfy node install` / `comfy model download` |
| `run_workflow.py` | Inject params, submit, monitor, download outputs (HTTP or WS) |
| `comfy-assets.py` | **Web-asset pipeline: prompt → correctly-sized, correctly-formatted site imagery.** Pairs with the `impeccable` skill for front-end work. |
| `run_batch.py` | Submit a workflow N times with sweeps, parallel up to your tier |
| `ws_monitor.py` | Real-time WebSocket viewer for executing jobs (live progress) |
| `health_check.py` | Verification checklist runner — comfy-cli + server + models + smoke test |
| `fetch_logs.py` | Pull traceback / status messages for a given prompt_id |

**Example workflows (`workflows/`):** SD 1.5, SDXL, Flux Dev, SDXL img2img,
SDXL inpaint, ESRGAN upscale, AnimateDiff video, Wan T2V. See
`workflows/README.md`.

## When to Use

- User asks to generate images with Stable Diffusion, SDXL, Flux, SD3, etc.
- User wants to run a specific ComfyUI workflow file
- User wants to chain generative steps (txt2img → upscale → face restore)
- User needs ControlNet, inpainting, img2img, or other advanced pipelines
- User asks to manage ComfyUI queue, check models, or install custom nodes
- User wants video/audio/3D generation via AnimateDiff, Hunyuan, Wan, AudioCraft, etc.

## This machine (Mac Studio) — read this first

The generic instructions below describe ComfyUI everywhere. This machine differs
in ways that will waste your time if you assume otherwise.

| | |
|---|---|
| **Server** | `http://127.0.0.1:8188` — the default in `_common.py` is already correct |
| **Install** | `/Users/macstudio/ComfyUI` (comfy-cli managed), ComfyUI **0.37.0**, Python 3.11, torch 2.13.0 |
| **Model library** | `/Users/macstudio/ComfyUI-Shared/models` (~104 GB) — wired via `extra_model_paths.yaml` in the install root |
| **comfy-cli** | `/Users/macstudio/ComfyUI/venv/bin/comfy` — **NOT on PATH.** Use the absolute path or activate the venv |
| **Device** | MPS, 96 GB unified, shared VRAM |
| **Comfy Desktop** | deleted 2026-09-26. Do not reference `/Applications/Comfy Desktop.app`, `~/ComfyUI-Installs`, or `~/Library/Application Support/Comfy Desktop` — all removed. Backup of the user dir at `~/Documents/comfy-desktop-backup/` |

Start the server (there is deliberately **no launchd job** — it does not autostart):

```bash
/Users/macstudio/ComfyUI/venv/bin/comfy launch -- --port 8188
# or directly:
cd /Users/macstudio/ComfyUI && ./venv/bin/python main.py --port 8188
```

**Which interpreter runs the scripts:** both work. `python` is 3.14.7, `python3` is
3.9.6. The scripts declare 3.10+ but `from __future__ import annotations` makes
them run under 3.9 too — verified by actually executing `health_check.py`,
`check_deps.py` and `run_workflow.py` under both. Prefer `python`.

**Why there's no Desktop app:** Patrick works in a browser against
`127.0.0.1:8188` and does not want the server autostarting. Don't propose a
`KeepAlive` LaunchAgent or standardizing on Desktop — both were considered and
rejected.

**Disk is tight.** 94 GB free of 926 GB. The Qwen-Image-2.1 weights alone are
40 GB (bf16 + int8_convrot). Check `df -h /System/Volumes/Data` before
downloading anything else.

## Architecture: Two Layers

```
┌─────────────────────────────────────────────────────┐
│ Layer 1: comfy-cli (official lifecycle tool)        │
│   Setup, server lifecycle, custom nodes, models     │
│   → comfy install / launch / stop / node / model    │
└─────────────────────────┬───────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────┐
│ Layer 2: REST/WebSocket API + skill scripts         │
│   Workflow execution, param injection, monitoring   │
│   POST /api/prompt, GET /api/view, WS /ws           │
│   → run_workflow.py, run_batch.py, ws_monitor.py    │
└─────────────────────────────────────────────────────┘
```

**Why two layers?** The official CLI is excellent for installation and server
management but has minimal workflow execution support. The REST/WS API fills
that gap — the scripts handle param injection, execution monitoring, and
output download that the CLI doesn't do.

## Quick Start

### Detect environment

```bash
# What's available?
command -v comfy >/dev/null 2>&1 && echo "comfy-cli: installed"
curl -s http://127.0.0.1:8188/system_stats 2>/dev/null && echo "server: running"

# Can this machine run ComfyUI locally? (GPU/VRAM/disk check)
python scripts/hardware_check.py
```

If nothing is installed, see **Setup & Onboarding** below — but always run the
hardware check first.

### One-line health check

```bash
python scripts/health_check.py
# → JSON: comfy_cli on PATH? server reachable? at least one checkpoint? smoke-test passes?
```

## Core Workflow

### Step 1: Get a workflow JSON in API format

Workflows must be in API format (each node has `class_type`). They come from:

- ComfyUI web UI → **Workflow → Export (API)** (newer UI) or
  the legacy "Save (API Format)" button (older UI)
- This skill's `workflows/` directory (ready-to-run examples)
- Community downloads (civitai, Reddit, Discord) — usually editor format,
  must be loaded into ComfyUI then re-exported

Editor format (top-level `nodes` and `links` arrays) is **not directly
executable**. The scripts detect this and tell you to re-export.

### Step 2: See what's controllable

```bash
python scripts/extract_schema.py workflow_api.json --summary-only
# → {"parameter_count": 12, "has_negative_prompt": true, "has_seed": true, ...}

python scripts/extract_schema.py workflow_api.json
# → full schema with parameters, model deps, embedding refs
```

### Step 3: Run with parameters

```bash
# Local (defaults to http://127.0.0.1:8188)
python scripts/run_workflow.py \
  --workflow workflow_api.json \
  --args '{"prompt": "a beautiful sunset over mountains", "seed": -1, "steps": 30}' \
  --output-dir ./outputs

# Cloud (export API key once; uses correct /api routing automatically)
export COMFY_CLOUD_API_KEY="comfyui-..."
python scripts/run_workflow.py \
  --workflow workflow_api.json \
  --args '{"prompt": "..."}' \
  --host https://cloud.comfy.org \
  --output-dir ./outputs

# Real-time progress via WebSocket (requires `pip install websocket-client`)
python scripts/run_workflow.py \
  --workflow flux_dev.json \
  --args '{"prompt": "..."}' \
  --ws

# img2img / inpaint: pass --input-image to upload + reference automatically
python scripts/run_workflow.py \
  --workflow sdxl_img2img.json \
  --input-image image=./photo.png \
  --args '{"prompt": "make it watercolor", "denoise": 0.6}'

# Batch / sweep: 8 random seeds, parallel up to cloud tier limit
python scripts/run_batch.py \
  --workflow sdxl.json \
  --args '{"prompt": "abstract"}' \
  --count 8 --randomize-seed --parallel 3 \
  --output-dir ./outputs/batch
```

`-1` for `seed` (or omitting it with `--randomize-seed`) generates a fresh
random seed per run.

### Step 4: Present results

The scripts emit JSON to stdout describing every output file:

```json
{
  "status": "success",
  "prompt_id": "abc-123",
  "outputs": [
    {"file": "./outputs/sdxl_00001_.png", "node_id": "9",
     "type": "image", "filename": "sdxl_00001_.png"}
  ]
}
```

## Decision Tree

| User says | Tool | Command |
|-----------|------|---------|
| **Lifecycle (use comfy-cli)** | | |
| "install ComfyUI" | comfy-cli | `bash scripts/comfyui_setup.sh` |
| "start ComfyUI" | comfy-cli | `comfy launch --background` |
| "stop ComfyUI" | comfy-cli | `comfy stop` |
| "install X node" | comfy-cli | `comfy node install <name>` |
| "download X model" | comfy-cli | `comfy model download --url <url> --relative-path models/checkpoints` |
| "list installed models" | comfy-cli | `comfy model list` |
| "list installed nodes" | comfy-cli | `comfy node show installed` |
| **Execution (use scripts)** | | |
| "is everything ready?" | script | `health_check.py` (optionally with `--workflow X --smoke-test`) |
| "what can I change in this workflow?" | script | `extract_schema.py W.json` |
| "check if W's deps are met" | script | `check_deps.py W.json` |
| "fix missing deps" | script | `auto_fix_deps.py W.json` |
| "generate an image" | script | `run_workflow.py --workflow W --args '{...}'` |
| "use this image" (img2img) | script | `run_workflow.py --input-image image=./x.png ...` |
| "8 variations with random seeds" | script | `run_batch.py --count 8 --randomize-seed ...` |
| "show me live progress" | script | `ws_monitor.py --prompt-id <id>` |
| "fetch the error from job X" | script | `fetch_logs.py <prompt_id>` |
| **Direct REST** | | |
| "what's in the queue?" | REST | `curl http://HOST:8188/queue` (local) or `--host https://cloud.comfy.org` |
| "cancel that" | REST | `curl -X POST http://HOST:8188/interrupt` |
| "free GPU memory" | REST | `curl -X POST http://HOST:8188/free` |

## Setup & Onboarding

When a user asks to set up ComfyUI, **the FIRST thing to do is ask whether
they want Comfy Cloud (hosted, zero install, API key) or Local (install
ComfyUI on their machine)**. Don't start running install commands or hardware
checks until they've answered.

**Official docs:** https://docs.comfy.org/installation
**CLI docs:** https://docs.comfy.org/comfy-cli/getting-started
**Cloud docs:** https://docs.comfy.org/get_started/cloud
**Cloud API:** https://docs.comfy.org/development/cloud/overview

### Step 0: Ask Local vs Cloud (ALWAYS FIRST)

Suggested script:

> "Do you want to run ComfyUI locally on your machine, or use Comfy Cloud?
>
> - **Comfy Cloud** — hosted on RTX 6000 Pro GPUs, all common models pre-installed,
>   zero setup. Requires an API key (paid subscription required to actually run
>   workflows; free tier is read-only). Best if you don't have a capable GPU.
> - **Local** — free, but your machine MUST meet the hardware requirements:
>   - NVIDIA GPU with **≥6 GB VRAM** (≥8 GB for SDXL, ≥12 GB for Flux/video), OR
>   - AMD GPU with ROCm support (Linux), OR
>   - Apple Silicon Mac (M1+) with **≥16 GB unified memory** (≥32 GB recommended).
>   - Intel Macs and machines with no GPU will NOT work — use Cloud instead.
>
> Which would you like?"

Routing:

- **Cloud** → skip to **Path A**.
- **Local** → run hardware check first, then pick a path from Paths B–E based on the verdict.
- **Unsure** → run the hardware check and let the verdict decide.

### Step 1: Verify Hardware (ONLY if user chose local)

```bash
python scripts/hardware_check.py --json
# Optional: also probe `torch` for actual CUDA/MPS:
python scripts/hardware_check.py --json --check-pytorch
```

| Verdict    | Meaning                                                       | Action |
|------------|---------------------------------------------------------------|--------|
| `ok`       | ≥8 GB VRAM (discrete) OR ≥32 GB unified (Apple Silicon)       | Local install — use `comfy_cli_flag` from report |
| `marginal` | SD1.5 works; SDXL tight; Flux/video unlikely                  | Local OK for light workflows, else **Path A (Cloud)** |
| `cloud`    | No usable GPU, <6 GB VRAM, <16 GB Apple unified, Intel Mac, Rosetta Python | **Switch to Cloud** unless user explicitly forces local |

The script also surfaces `wsl: true` (WSL2 with NVIDIA passthrough) and
`rosetta: true` (x86_64 Python on Apple Silicon — must reinstall as ARM64).

If verdict is `cloud` but the user wants local, do not proceed silently.
Show the `notes` array verbatim and ask whether they want to (a) switch to
Cloud or (b) force a local install (will OOM or be unusably slow on modern models).

### Choosing an Installation Path

Use the hardware check first. The table below is the fallback for when the
user has already told you their hardware:

| Situation | Recommended Path |
|-----------|------------------|
| `verdict: cloud` from hardware check | **Path A: Comfy Cloud** |
| No GPU / want to try without commitment | **Path A: Comfy Cloud** |
| Windows + NVIDIA + non-technical | **Path B: ComfyUI Desktop** |
| Windows + NVIDIA + technical | **Path C: Portable** or **Path D: comfy-cli** |
| Linux + any GPU | **Path D: comfy-cli** (easiest) |
| macOS + Apple Silicon | **Path B: Desktop** or **Path D: comfy-cli** |
| Headless / server / CI / agents | **Path D: comfy-cli** |

For the fully automated path (hardware check → install → launch → verify):

```bash
bash scripts/comfyui_setup.sh
# Or with overrides:
bash scripts/comfyui_setup.sh --m-series --port=8190 --workspace=/data/comfy
```

It runs `hardware_check.py` internally, refuses to install locally when the
verdict is `cloud` (unless `--force-cloud-override`), picks the right
`comfy-cli` flag, and prefers `pipx`/`uvx` over global `pip` to avoid polluting
system Python.

---

### Path A: Comfy Cloud (No Local Install)

For users without a capable GPU or who want zero setup. Hosted on RTX 6000 Pro.

**Docs:** https://docs.comfy.org/get_started/cloud

1. Sign up at https://comfy.org/cloud
2. Generate an API key at https://platform.comfy.org/login
3. Set the key:
   ```bash
   export COMFY_CLOUD_API_KEY="your-comfyui-key"
   ```
4. Run workflows:
   ```bash
   python scripts/run_workflow.py \
     --workflow workflows/flux_dev_txt2img.json \
     --args '{"prompt": "..."}' \
     --host https://cloud.comfy.org \
     --output-dir ./outputs
   ```

**Pricing:** https://www.comfy.org/cloud/pricing
**Concurrent jobs:** Free/Standard 1, Creator 3, Pro 5. Free tier
**cannot run workflows via API** — only browse models. Paid subscription
required for `/api/prompt`, `/api/upload/*`, `/api/view`, etc.

---

### Path B: ComfyUI Desktop (Windows / macOS)

One-click installer for non-technical users. Currently Beta.

**Docs:** https://docs.comfy.org/installation/desktop
- **Windows (NVIDIA):** https://download.comfy.org/windows/nsis/x64
- **macOS (Apple Silicon):** https://comfy.org

Linux is **not supported** for Desktop — use Path D.

---

### Path C: ComfyUI Portable (Windows Only)

**Docs:** https://docs.comfy.org/installation/comfyui_portable_windows

Download from https://github.com/comfyanonymous/ComfyUI/releases, extract,
run `run_nvidia_gpu.bat`. Update via `update/update_comfyui_stable.bat`.

---

### Path D: comfy-cli (All Platforms — Recommended for Agents)

The official CLI is the best path for headless/automated setups.

**Docs:** https://docs.comfy.org/comfy-cli/getting-started

#### Install comfy-cli

```bash
# Recommended:
pipx install comfy-cli
# Or use uvx without installing:
uvx --from comfy-cli comfy --help
# Or (if pipx/uvx unavailable):
pip install --user comfy-cli
```

Disable analytics non-interactively:
```bash
comfy --skip-prompt tracking disable
```

#### Install ComfyUI

```bash
comfy --skip-prompt install --nvidia              # NVIDIA (CUDA)
comfy --skip-prompt install --amd                 # AMD (ROCm, Linux)
comfy --skip-prompt install --m-series            # Apple Silicon (MPS)
comfy --skip-prompt install --cpu                 # CPU only (slow)
comfy --skip-prompt install --nvidia --fast-deps  # uv-based dep resolution
```

Default location: `~/comfy/ComfyUI` (Linux), `~/Documents/comfy/ComfyUI`
(macOS/Win). Override with `comfy --workspace /custom/path install`.

#### Launch / verify

```bash
comfy launch --background                       # background daemon on :8188
comfy launch -- --listen 0.0.0.0 --port 8190    # LAN-accessible custom port
curl -s http://127.0.0.1:8188/system_stats      # health check
```

---

### Path E: Manual Install (Advanced / Unsupported Hardware)

For Ascend NPU, Cambricon MLU, Intel Arc, or other unsupported hardware.

**Docs:** https://docs.comfy.org/installation/manual_install

```bash
git clone https://github.com/comfyanonymous/ComfyUI.git
cd ComfyUI
pip install torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/cu130
pip install -r requirements.txt
python main.py
```

---

### Post-Install: Download Models

```bash
# SDXL (general purpose, ~6.5 GB)
comfy model download \
  --url "https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors" \
  --relative-path models/checkpoints

# SD 1.5 (lighter, ~4 GB, good for 6 GB cards)
comfy model download \
  --url "https://huggingface.co/stable-diffusion-v1-5/stable-diffusion-v1-5/resolve/main/v1-5-pruned-emaonly.safetensors" \
  --relative-path models/checkpoints

# Flux Dev fp8 (smaller variant, ~12 GB)
comfy model download \
  --url "https://huggingface.co/Comfy-Org/flux1-dev/resolve/main/flux1-dev-fp8.safetensors" \
  --relative-path models/checkpoints

# CivitAI (set token first):
comfy model download \
  --url "https://civitai.com/api/download/models/128713" \
  --relative-path models/checkpoints \
  --set-civitai-api-token "YOUR_TOKEN"
```

List installed: `comfy model list`.

### Post-Install: Install Custom Nodes

```bash
comfy node install comfyui-impact-pack             # popular utility pack
comfy node install comfyui-animatediff-evolved     # video generation
comfy node install comfyui-controlnet-aux          # ControlNet preprocessors
comfy node install comfyui-essentials              # common helpers
comfy node update all
comfy node install-deps --workflow=workflow.json   # install everything a workflow needs
```

### Post-Install: Verify

```bash
python scripts/health_check.py
# → comfy_cli on PATH? server reachable? checkpoints? smoke test?

python scripts/check_deps.py my_workflow.json
# → are this workflow's nodes/models/embeddings installed?

python scripts/run_workflow.py \
  --workflow workflows/sd15_txt2img.json \
  --args '{"prompt": "test", "steps": 4}' \
  --output-dir ./test-outputs
```

## Image Upload (img2img / Inpainting)

The simplest way is to use `--input-image` with `run_workflow.py`:

```bash
python scripts/run_workflow.py \
  --workflow workflows/sdxl_img2img.json \
  --input-image image=./photo.png \
  --args '{"prompt": "make it cyberpunk", "denoise": 0.6}'
```

The flag uploads `photo.png`, then injects its server-side filename into
whatever schema parameter is named `image`. For inpainting, pass both:

```bash
python scripts/run_workflow.py \
  --workflow workflows/sdxl_inpaint.json \
  --input-image image=./photo.png \
  --input-image mask_image=./mask.png \
  --args '{"prompt": "fill with flowers"}'
```

Manual upload via REST:
```bash
curl -X POST "http://127.0.0.1:8188/upload/image" \
  -F "image=@photo.png" -F "type=input" -F "overwrite=true"
# Returns: {"name": "photo.png", "subfolder": "", "type": "input"}

# Cloud equivalent:
curl -X POST "https://cloud.comfy.org/api/upload/image" \
  -H "X-API-Key: $COMFY_CLOUD_API_KEY" \
  -F "image=@photo.png" -F "type=input" -F "overwrite=true"
```

## Cloud Specifics

- **Base URL:** `https://cloud.comfy.org`
- **Auth:** `X-API-Key` header (or `?token=KEY` for WebSocket)
- **API key:** set `$COMFY_CLOUD_API_KEY` once and the scripts pick it up automatically
- **Output download:** `/api/view` returns a 302 to a signed URL; the scripts
  follow it and strip `X-API-Key` before fetching from the storage backend
  (don't leak the API key to S3/CloudFront).
- **Endpoint differences from local ComfyUI:**
  - `/api/object_info`, `/api/queue`, `/api/userdata` — **403 on free tier**;
    paid only.
  - `/history` is renamed to `/history_v2` on cloud (the scripts route
    automatically).
  - `/models/<folder>` is renamed to `/experiment/models/<folder>` on cloud
    (the scripts route automatically).
  - `clientId` in WebSocket is currently ignored — all connections for a
    user receive the same broadcast. Filter by `prompt_id` client-side.
  - `subfolder` is accepted on uploads but ignored — cloud has a flat namespace.
- **Concurrent jobs:** Free/Standard: 1, Creator: 3, Pro: 5. Extras queue
  automatically. Use `run_batch.py --parallel N` to saturate your tier.

## Queue & System Management

```bash
# Local
curl -s http://127.0.0.1:8188/queue | python -m json.tool
curl -X POST http://127.0.0.1:8188/queue -d '{"clear": true}'    # cancel pending
curl -X POST http://127.0.0.1:8188/interrupt                      # cancel running
curl -X POST http://127.0.0.1:8188/free \
  -H "Content-Type: application/json" \
  -d '{"unload_models": true, "free_memory": true}'

# Cloud — same paths under /api/, plus:
python scripts/fetch_logs.py --tail-queue --host https://cloud.comfy.org
```

## Web assets (`comfy-assets.py`)

For front-end work, generation is only half the job — a website also needs the
right aspect ratio, format, dimensions, file size, and consistent art direction.
`scripts/comfy-assets.py` handles the second half.

```bash
# what's available
python scripts/comfy-assets.py --presets

# one asset, correct ratio + JPEG/WebP at a sane weight
python scripts/comfy-assets.py \
  --prompt "editorial photograph of ..." --alt "Descriptive alt text" \
  --preset hero --format jpeg,webp --out ./public/img

# variations from one seed (same visual world)
python scripts/comfy-assets.py --prompt "..." --preset card --batch 4 --seed 7
```

Presets: `hero` 16:9, `og` 1.91:1 (Open Graph safe area), `card` 4:3,
`card-wide` 3:2, `portrait` 4:5, `portrait-lg` 2:3, `square` 1:1,
`mobile` 9:16, `panorama` 21:9.

- Generates at the smallest sensible canvas at-or-above the output size, then
  **only ever downscales** — it refuses to upscale and says so.
- Flattens alpha onto white for JPEG (no alpha channel in JPEG).
- Writes `assets.manifest.json` capturing prompt, alt text, seed, preset,
  dimensions, and per-format file size. Alt text starts as the prompt; override
  it with `--alt`.
- `--seed N` is what makes a set look like one site. Generate a batch, keep the
  seed, and every image shares a visual world.
- Negative prompt defaults to the usual suspects (text, watermark, anatomy).
  Qwen-Image-2.1 renders text well, so **omit** "text" from `--negative` when you
  actually want typography.
- **130–250s per image on this machine.** Batch it; don't generate inline while
  iterating on layout.

## Pitfalls

0. **Model visibility is per-server, not per-machine.** A ComfyUI server only sees
   the model dirs it was told about at boot. Two servers on one Mac routinely see
   different libraries. Before debugging a "missing model," confirm what the
   *running* server actually lists — never infer it from the filesystem:

   ```bash
   curl -s http://127.0.0.1:8188/object_info | python3 -c "
   import json,sys; d=json.load(sys.stdin)
   for n in ('UNETLoader','DiffusionModelLoader','CLIPLoader','VAELoader'):
       for k,v in (d.get(n,{}).get('input',{}).get('required') or {}).items():
           if isinstance(v,list) and v and isinstance(v[0],list) and v[0] and isinstance(v[0][0],str):
               print(f'{n}.{k}:', v[0])"
   ```

   If the dropdown lists only `default`/`fp8_*` weight-type enums and no real
   filenames, the server has no model paths configured. That is the bug.

   Ways model paths get set, and the trap in each:
   - **comfy-cli install:** needs `extra_model_paths.yaml` in the ComfyUI root
     (ComfyUI reads it automatically). Omit `is_default: true` to make the block
     *additive* to the local `models/` dir instead of replacing it.
   - **Comfy Desktop:** generates its own files and passes
     `--extra-model-paths-config <App Support>/Comfy Desktop/instance-model-paths/<id>.yaml`.
     Launching `main.py` by hand WITHOUT that flag reproduces the "invisible
     models" bug exactly. When testing a Desktop install from the shell, copy the
     flag out of `installations.json` / the instance-model-paths dir.
   - Stale Desktop **v1** config (`~/Library/Application Support/ComfyUI/config.json`
     plus `extra_models_config.yaml`) can point at a basePath that no longer
     exists. Check it before assuming a path bug is a permissions bug.

0b. **Two servers on one port, different interfaces, is a silent failure.** A
   loopback-bound server and a tailnet-bound one both "work" on 8188 while
   fighting over the SQLite DB. Symptom is an empty `/history` and error messages
   that are generated then dropped:

   ```
   Failed to initialize database ... Could not acquire lock on
   '/path/user/comfyui.db'. Another ComfyUI process may already be using it.
   ```

   Diagnose with `lsof -nP -iTCP:8188` (LISTEN *and* ESTABLISHED lines) plus
   `lsof /path/user/comfyui.db`. Do not kill a server on the tailnet interface
   reflexively — check for ESTABLISHED connections first; it may be serving
   another machine (e.g. a laptop on the tailnet) and be very much in use.

0c. **Qwen-Image-2.1 (Sept 2026) needs ComfyUI >= 0.37.0.** Merged via Comfy-Org/ComfyUI
   PR #16400. Older ComfyUI has no `TextEncodeQwenImage21` / `QwenImage21Cache`
   nodes and cannot load the weights at all. Check `<install>/comfyui_version.py`
   before downloading 30GB of anything. Nodes land in
   `comfy_extras/nodes_qwen.py`.

   Its official templates are **hardcoded to int8_convrot**
   (`qwen_image_2.1_int8_convrot.safetensors`, `qwen3vl_8b_int8_convrot.safetensors`).
   If you downloaded bf16 instead, the dropdowns default to filenames you don't
   have. Either switch the dropdowns to your bf16 files or fetch the int8 pair.

   T2I and Edit templates want *different* text encoders
   (`qwen3.5_9b_qwen_image_2.1_pe_t2i` vs `..._pe_i2i`); the single
   `qwen3vl_8b_bf16` is the one that serves both.

   Working single-file set (Comfy-Org/Qwen-Image-2.1), bf16, ~32.4 GB total:
   `diffusion_models/qwen_image_2.1_bf16.safetensors` (14.23 GB),
   `text_encoders/qwen3vl_8b_bf16.safetensors` (17.53 GB),
   `vae/qwen_image_2.1_vae_bf16.safetensors` (0.68 GB).

   Minimal working API-format graph (verified on 0.37.4, MPS, 143 s for
   1024x1024 @ 25 steps including weight load):

   ```json
   {"451": {"class_type": "UNETLoader",
            "inputs": {"unet_name": "qwen_image_2.1_bf16.safetensors", "weight_dtype": "default"}},
    "452": {"class_type": "TextEncodeQwenImage21",
            "inputs": {"clip": ["453", 0], "prompt": "...", "negative_prompt": "...",
                       "resolution": 1024, "images": []}},
    "453": {"class_type": "CLIPLoader",
            "inputs": {"clip_name": "qwen3vl_8b_bf16.safetensors", "type": "qwen_image", "device": "default"}},
    "454": {"class_type": "VAELoader",
            "inputs": {"vae_name": "qwen_image_2.1_vae_bf16.safetensors"}},
    "458": {"class_type": "KSampler",
            "inputs": {"model": ["451", 0], "positive": ["452", 0], "negative": ["452", 1],
                       "latent_image": ["452", 2], "seed": 42, "steps": 25, "cfg": 1.0,
                       "sampler_name": "euler", "scheduler": "simple", "denoise": 1.0}},
    "457": {"class_type": "VAEDecode", "inputs": {"samples": ["458", 0], "vae": ["454", 0]}},
    "459": {"class_type": "SaveImage", "inputs": {"filename_prefix": "qwen21", "images": ["457", 0]}}}
   ```

   Two schema facts that are not guessable: `TextEncodeQwenImage21` requires
   `negative_prompt` and `resolution` (no `max_sequence_length`), and its
   **output 2 is a LATENT** — feed that to the KSampler instead of adding an
   `EmptyLatentImage`. Output names are `positive`, `negative`, `latent`.

   Reference images go in as a **dict**, not a dotted key:
   `"images": {"image_1": ["470", 0]}`. A bare `"image_1"` raises
   `TypeError: ... unexpected keyword argument 'image_1'`. See
   `references/template-integrity.md`.

   Background removal specifics: the flattened graph is at
   `~/.hermes/cache/scratch/qwen21_bgremoval.json`. **`resolution` is a total
   pixel BUDGET, not width or height** — aspect ratio preserved, default 1024,
   schema max 4096, and `0` means "no resize beyond a multiple of 32". The
   template ships `0`; the 4096 max does not mean 4096x4096 is tested here.

   **Verified: alpha works, subject preservation does not (yet).** A run on a
   generated greyscale portrait produced valid RGBA with genuine transparency
   (39% fully transparent, correctly placed) but **destroyed the subject** — 86%
   of opaque pixels differed from the input. Most likely cause: the test image
   had soft studio gradients, and background removal needs a clean opaque
   subject against a flat field. Test on a real product-on-white or
   person-against-wall photo first. Transparent pixels also retain non-zero RGB
   (diffusion premultiplication garbage) which can fringe in compositors, and the
   official template uses `SaveImageAdvanced` rather than plain `SaveImage` —
   prefer it for alpha work.

0g. **Model swapping dominates wall-clock.** int8 vs bf16 is ~15% apart in
   isolation, but a queue alternating dtypes pays a 13.5 GB UNet reload plus a
   16.7 GB text-encoder reload per switch — observed 247s for a 25-step job
   (9.28s/it) against 131s with one dtype resident. Pick one dtype per session.

0h. **The 500 on `/prompt` is real and has a known workaround.** `run_workflow.py`
   can get `500 Internal Server Error / Server got itself in trouble` where a
   direct POST of the same payload succeeds. Build the payload, POST with curl,
   poll `/history/<prompt_id>`. Use direct POST when you need real validation
   errors — a 500 hides them.

0i. **Verify generated images; don't infer them from metadata.** An RGBA
   container does not prove a cutout happened. Decode the alpha channel, count
   transparent vs opaque pixels, and diff subject pixels against the input. A
   vision model can hallucinate confidently on generated images (it described a
   norbornane chemical structure in a portrait, twice, on both raw and composited
   versions) — cross-check with pixel statistics before reporting. Compositing
   over a red/grey checkerboard makes both transparency and missing subjects
   immediately visible.

## Watch a job run

Browser at `http://127.0.0.1:8188` is the best view. Terminal options, including
the `ws_monitor.py` client_id gotcha, are in
`references/template-integrity.md`.

0d. **Apple Silicon (MPS) cannot run fp8 weights.** Qwen-Image 1.0's default
   `qwen_image_fp8_e4m3fn.safetensors` dies at load with:

   ```
   TypeError: Trying to convert Float8_e4m3fn to the MPS backend but it does
   not have support for that dtype.
   ```

   Not a memory problem. Use bf16, or int8_convrot / GGUF, on Mac. Qwen-Image-2.1
   already dropped fp8, which is why it works where 1.0 doesn't.

0e. **Verify safetensors by byte size against Content-Length, not by eyeballing
   `du`.** `rc=0` from a resumed `curl --continue-at -` does NOT prove the file is
   complete. And `du -m` reports MiB while HF reports decimal GB, so a correct file
   looks ~7% "short" (13.25 vs 14.23). Compare exact byte counts:

   ```bash
   stat -f "%z" local.safetensors
   curl -sIL "$URL" | grep -i ^content-length | tail -1
   ```

   Header sanity check: first 8 bytes are a little-endian u64 length, then `{"__metadata"`.
   Use `od -c` to inspect — do not grep for specific magic bytes, the length varies
   per file.

0f. **Download scripts: never flatten model subdirectories.** `--output "$(basename
   "$f")"` writes every file into the models/ root where ComfyUI cannot see it.
   Preserve the full relative path (`diffusion_models/foo.safetensors`) and
   `mkdir -p "$(dirname ...)"` first.

1. **API format required** — every script and the `/api/prompt` endpoint expect
   API-format workflow JSON. The scripts detect editor format (top-level
   `nodes` and `links` arrays) and tell you to re-export via
   "Workflow → Export (API)" (newer UI) or "Save (API Format)" (older UI).

2. **Server must be running** — all execution requires a live server.
   `comfy launch --background` starts one. Verify with
   `curl http://127.0.0.1:8188/system_stats`.

3. **Model names are exact** — case-sensitive, includes file extension.
   `check_deps.py` does fuzzy matching (with/without extension and folder
   prefix), but the workflow itself must use the canonical name. Use
   `comfy model list` to discover what's installed.

4. **Missing custom nodes** — "class_type not found" means a required node
   isn't installed. `check_deps.py` reports which package to install;
   `auto_fix_deps.py` runs the install for you.

5. **Working directory** — `comfy-cli` auto-detects the ComfyUI workspace.
   If commands fail with "no workspace found", use
   `comfy --workspace /path/to/ComfyUI <command>` or
   `comfy set-default /path/to/ComfyUI`.

6. **Cloud free-tier API limits** — `/api/prompt`, `/api/view`, `/api/upload/*`,
   `/api/object_info` all return 403 on free accounts. `health_check.py` and
   `check_deps.py` handle this gracefully and surface a clear message.

7. **Timeout for video/audio workflows** — auto-detected when an output node
   is `VHS_VideoCombine`, `SaveVideo`, etc.; the default jumps from 300 s to
   900 s. Override explicitly with `--timeout 1800`.

8. **Path traversal in output filenames** — server-supplied filenames are
   passed through `safe_path_join` to refuse anything escaping `--output-dir`.
   Keep this protection on — workflows with custom save nodes can produce
   arbitrary paths.

9. **Workflow JSON is arbitrary code** — custom nodes run Python, so
   submitting an unknown workflow has the same trust profile as `eval`.
   Inspect workflows from untrusted sources before running.

10. **Auto-randomized seed** — pass `seed: -1` in `--args` (or use
    `--randomize-seed` and omit the seed) to get a fresh seed per run.
    The actual seed is logged to stderr.

11. **`tracking` prompt** — first run of `comfy` may prompt for analytics.
    Use `comfy --skip-prompt tracking disable` to skip non-interactively.
    `comfyui_setup.sh` does this for you.

## Verification Checklist

Use `python scripts/health_check.py` to run the whole list at once. Manual:

- [ ] `hardware_check.py` verdict is `ok` OR the user explicitly chose Comfy Cloud
- [ ] `comfy --version` works (or `uvx --from comfy-cli comfy --help`)
- [ ] `curl http://HOST:PORT/system_stats` returns JSON
- [ ] `comfy model list` shows at least one checkpoint (local) OR
      `/api/experiment/models/checkpoints` returns models (cloud)
- [ ] Workflow JSON is in API format
- [ ] `check_deps.py` reports `is_ready: true` (or only `node_check_skipped`
      on cloud free tier)
- [ ] Test run with a small workflow completes; outputs land in `--output-dir`

## Known quirks: Qwen deployment and the run_workflow.py 500

**ComfyUI version floor.** Qwen models require ComfyUI **0.37.0 or newer**. Older versions ship
without the required nodes. The Studio install is already past this floor, so check
`comfy --version` before assuming a missing node is a model problem.

**Model placement is hierarchical.** Weights go in typed subdirectories under
`/Users/macstudio/ComfyUI-Shared/models/` (`diffusion_models/`, `text_encoders/`, `vae/`), never in
the root. The root is on the search path but the loaders resolve by subdirectory, so a root-level
drop is invisible to the UI.

**`int8_convrot` vs `bf16`.** The official templates target `int8_convrot`. On Apple Silicon the
`bf16` weights are often the better choice. If you stay on the templates you must either select the
`bf16` files manually in the UI or download the `int8` pair; otherwise the node dropdowns default to
filenames you do not have on disk and fail with a bare "file not found."

**Download scripts must preserve the full relative path.** A `curl` loop that flattens the Hugging
Face repo structure into one directory breaks model resolution, because ComfyUI resolves weights by
their subdirectory. Mirror the upstream path exactly.

**`run_workflow.py` returns 500 "Server got itself in trouble."** The submission path through
`run_workflow.py` intermittently fails with that error. It is a client-side submission problem, not a
generation problem. Workaround: POST the full workflow JSON directly to the ComfyUI REST endpoint
`/prompt`; that path is reliable.
