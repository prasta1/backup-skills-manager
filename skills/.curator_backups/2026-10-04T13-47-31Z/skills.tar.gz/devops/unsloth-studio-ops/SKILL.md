---
name: unsloth-studio-ops
description: "Audit/upgrade Unsloth Studio on this Mac Studio. Use on update/review/config asks."
---

# Unsloth Studio Ops

Review, edit, and troubleshoot the **Unsloth Studio** web app (AGPL tuning IDE — NOT Jupyter) that runs on Patrick's Mac Studio. Triggers on "review my unsloth config", "why does unsloth reference LM Studio", "fix the unsloth provider", "unsloth won't start", or "unsloth 500 on chat projects".

## Where it lives
Unsloth Studio runs on **this machine** (the Mac Studio, user `macstudio`), bound tailnet-only at `http://studio.taile85139.ts.net:8888`. Everything below runs locally; no `ssh` hop. Most reviews are read-only; confirm before making any change.

> 2026-10-01: the MacBook is no longer an inference peer for Hermes (single engine is llama.cpp via llama-swap on the Studio, see MEMORY.md). The `MacBook` LM Studio provider row described below is historical; if it is still present, treat it as a candidate for removal rather than a thing to keep alive.

## Config is SQLite, not a file
The app config is a SQLite DB at `~/.unsloth/studio/studio.db` — there is **no yaml/toml to edit**. Key tables:
- `llm_providers` — the LLM backend endpoints (this is what "references LM Studio").
- `chat_projects` — project workspaces; holds `root_path` (see trap below).

### `llm_providers` schema gotcha
Columns are: `id`(TEXT), `provider_type`(TEXT), `display_name`(TEXT), `base_url`(TEXT), `is_enabled`(INTEGER), `created_at`, `updated_at`.

**Do NOT assume `name` / `enabled` columns** — a `SELECT ... WHERE name=...` or referencing `enabled` fails with "no such column". Always `PRAGMA table_info(llm_providers);` first, or select `display_name`/`is_enabled`.

### Live edits need no restart
The server opens per-request SQLite connections under WAL. A direct `UPDATE llm_providers SET display_name='llama-swap' WHERE display_name='MacStudio';` applies immediately — no server restart. API keys are **never** stored server-side (browser holds them RSA-encrypted per request), so there is nothing secret to scrub from the DB.

## Cross-machine root_path trap
`chat_projects.root_path` stores an absolute path. A row carrying a **laptop** path (`/Users/prasta/...`) makes `ensure_chat_project_workspace()` try to `mkdir` up to `/Users/prasta`, raise `PermissionError`, and **500 the entire `GET /api/chat/projects` list** — not just that project. When migrating or reviewing the DB, verify every `root_path` is `/Users/macstudio/...` (Studio-native). If you see `prasta` paths, that DB was written on the laptop and must be path-rewritten before use.

## launchd shape
- `~/Library/LaunchAgents/com.unsloth.studio.plist` — `RunAtLoad:true` + `KeepAlive:true`, execs `~/.unsloth/studio/start-studio.sh`. An audit flagged `KeepAlive` as "wrong shape — open manually when needed"; it was still set as of 2026-08-08. Confirm with the user before changing it to on-demand.
- `start-studio.sh` polls `tailscale ip -4` (up to 5 min) before binding `-H <TSIP>:8888`. This avoids a crash-loop if launchd starts before tailscaled assigns the address. Bind is **tailnet-only** (not `0.0.0.0`) — keeps the UI off the LAN and the `--cloudflare` tunnel off.
- `~/Library/LaunchAgents/com.unsloth.logrotate.plist` — daily 4:30am. Audit flagged **REMOVE**: launchd is the wrong home for logrotate; server holds fds open so rename-style rotation wouldn't work anyway.

## The "why does it reference LM Studio" answer
There is exactly **one** `llm_providers` row tied to LM Studio: a `custom` provider named `MacBook` → `https://macbookpro.taile85139.ts.net:1234/v1` (the laptop's LM Studio over tailnet/HTTPS). LM Studio was **removed from the Studio itself**; the Studio's local endpoint is llama-swap (`:9292/v1`). The `MacBook` row is a deliberate pointer at the laptop used as a remote inference backend. (A separate, unrelated reference is a beginner curriculum doc `~/Documents/Unsloth Studio/Projects/Intro-to-AI-*/sandbox/resources.md` that lists LM Studio as a local-LLM tool — harmless.)

### MacBook provider reliability
The laptop LM Studio is **interactive-only** (GUI-gated). `com.lmstudio.watchdog` (RunAtLoad + StartInterval 300) restarts the server *only when the GUI app is open*; `autoStartOnLaunch:true` in `~/.lmstudio/.internal/http-server-config.json` starts it on app launch. So `MacBook` provider requests fail whenever the laptop's LM Studio GUI is closed. **Do not** re-enable a headless LM Studio service on the laptop — the user deliberately removed it. If the user wants `MacBook` always-on, surface the tradeoff; the fix is re-adding a headless daemon, which contradicts the stable design.

## Verification checklist (read-only review)
```
DB=~/.unsloth/studio/studio.db
sqlite3 -header -column "$DB" "SELECT display_name, provider_type, base_url, is_enabled FROM llm_providers;"
sqlite3 -header -column "$DB" "SELECT name, root_path FROM chat_projects;"
launchctl list | grep unsloth
```

## Version / upgrade pitfall (the silent one)
`unsloth/__init__.py` does `__version__ = unsloth_zoo.__version__`. The version string you read from `import unsloth` is the **zoo's** version, not the core's.

- Symptom: `pip install -U unsloth==2026.8.8` reports "Requirement already satisfied" yet `import unsloth` still prints `2026.8.5`.
- Cause: the core released ahead of `unsloth_zoo` on PyPI (the zoo version may lag the core). pip installed core 2026.8.8, saw `unsloth_zoo>=2026.8.5` satisfied by 2026.8.5, and stopped. No `unsloth_zoo==2026.8.8` exists to pull.
- **This is NOT broken.** Prove the *core* is current by reading `unsloth-<ver>.dist-info/METADATA` `Version:` in the venv. That's the dist-info the running process loaded. Also confirm the live server PID maps to that venv (`ps -o command -p <pid>`).
- Fix: wait for the matching `unsloth_zoo` release, then a plain upgrade in the bundled venv flips the reported version. **Never hand-edit `__version__`** in source — it masks the real zoo version and can fool future upgrade logic.

### Upgrade location matters
Unsloth Studio ships the package in a **bundled venv**, not system site-packages: `~/.unsloth/studio/unsloth_studio/lib/python3.13/site-packages/`. Use that venv's pip/python — `~/.unsloth/studio/unsloth_studio/bin/pip install -U unsloth`. System `pip show unsloth` → "not found" is expected; this is not the install target. Watch the torch pin (`torch<2.12.0`, venv carries 2.10.0) — an upgrade that drags in a newer torch can break the running server.

## Pitfalls
- Don't edit a yaml/toml that doesn't exist — it's SQLite.
- Don't hardcode column names in sqlite queries (`display_name`/`is_enabled`, not `name`/`enabled`).
- Don't touch launchd `KeepAlive`/`RunAtLoad` without confirming the user wants on-demand vs always-on.
- Don't re-enable headless LM Studio on the laptop.
- Don't "fix" the reported version by editing `unsloth/__init__.py` or `_gpu_init.py` — it hides the real zoo version.
- Don't run `pip install -U unsloth` against system pip to "fix" the version — it won't touch the bundled venv.
- Authoritative "what it is" detail (admin user, password reset, tailnet bind rationale) lives in the memory reference `reference_unsloth_studio.md` — read that for recovery paths, not for the ops procedure here.

## Model memory residency controls (defaults are all off)

These are **not** in a yaml/toml — they live as rows in `app_settings` (SQLite) and default to False/0. They're read at model-load time via `model_memory_settings.py` and `openai_auto_switch_settings.py`.

| DB key | Default | Effect | llama.cpp flag |
|---|---|---|---|
| `model_memory_keep_resident` | `false` | Page-lock the model in VRAM after load (`--mlock`); no idle auto-unload | `--mlock` |
| `model_memory_no_ram_reserve` | `false` | Keep default mmap path (no `--mlock`); drop `--no-mmap` | (drops flag) |
| `openai_api_auto_switch_model` | `false` | Auto-load a GGUF named in `/v1` requests before serving | (runtime load) |
| `openai_api_auto_download_model` | `false` | Download a missing GGUF repo named in `/v1` requests | (runtime dl) |
| `openai_api_auto_unload_idle_seconds` | `0` (off) | Unload loaded model after N idle seconds (min 60) | `--unload` on idle |
| `openai_api_auto_unload_keep_kv` | `true` | Persist KV cache to disk on idle unload | slot-save |
| `openai_api_auto_unload_api_only` | `false` | Only idle-unload models loaded via API, spare UI-loaded ones | (runtime filter) |

### Apple Silicon VRAM budget resolution

On macOS, Studio probes the Metal/GPU budget via `_apple_metal_memory_budget_bytes()` in `llama_cpp.py` (~line 5359):
1. Import `mlx.core` → read `mx.device_info()["max_recommended_working_set_size"]`
2. If MLX fails → fall back to `psutil.virtual_memory().total` (full RAM)
3. Multiply by `_APPLE_UNIFIED_MEMORY_FRACTION = 0.85`

The GPU selection logic at load time (`llama_cpp.py` ~line 11788):
- **Auto mode** (default): if the model fits within the Apple VRAM budget → emits `-ngl -1 --fit off` (full GPU, no auto-fit). If it doesn't fit → emits `--fit on` (llama.cpp auto-sizes the offload between GPU and system RAM).
- **Manual mode**: user specifies `gpu_layers` in the model picker. Studio emits `--gpu-layers N --fit off`. `-1` means all layers.

For a 22GB model (Qwen3.6-27B Q4_K_M) on a 64GB MacBook Pro: Studio will likely emit `--fit on` and let llama.cpp spill overflow layers to unified RAM. On the 96GB Studio, it may fit entirely in VRAM with `-ngl -1 --fit off`.

### Checking these settings

```bash
# Check DB for persisted model-memory settings
sqlite3 ~/.unsloth/studio/studio.db "SELECT key, value_json FROM app_settings WHERE key LIKE '%model_memory%' OR key LIKE '%auto_switch%' OR key LIKE '%auto_unload%' OR key LIKE '%idle%';"

# If none appear, defaults (all off) are in effect — this is the fresh-install state.
```

### Tuning recommendation for large-model work

On a 64GB+ MacBook Pro or 96GB Studio, flip `model_memory_keep_resident` ON via the UI (`Settings → Model Memory → "Keep model in GPU memory"`). This page-pins weights and prevents between-request re-fault latency on large GGUFs. Safe when you have ≥3× the model size in RAM; unsafe on 16GB machines.

## References
- `references/live-config-2026-08-08.md` — the actual `llm_providers` rows and launchd plist contents captured this session, for diffing future state.
- `references/version-aliasing.md` — full diagnostic sequence for the `__version__` zoo-aliasing trap (proof the core is current despite a stale import string).
- `references/model-memory-settings.md` — session-specific detail: traced code paths, Apple Silicon VRAM resolution, and auto/manual offload branching.
