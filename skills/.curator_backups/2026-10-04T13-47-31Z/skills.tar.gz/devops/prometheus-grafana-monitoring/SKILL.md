---
name: prometheus-grafana-monitoring
description: "Use when operating the macmon/Prometheus/Grafana stack."
---

# Prometheus + Grafana monitoring (macmon/node_exporter → Prometheus → Grafana) — Studio hub with local and remote node_exporter aggregation

Studio-local system metrics: `macmon serve` exposes a Prometheus endpoint on the Mac Studio; one Prometheus instance (loopback-only) scrapes the Studio's macmon, node_exporter, and blackbox_exporter; Grafana renders. Stack is deployed and verified on this studio — treat it as operational, not experimental.

## Architecture (studio hub — do not drift)

- **Studio** (always-on M3 Ultra) is the hub: macmon serve :9199, node_exporter :9100, blackbox_exporter :9115, Prometheus :9090 (loopback-only), Grafana :3001.
- **Always-on services go on the always-on box.** The Studio runs continuously; no other box hosts the monitoring stack.
- Prometheus binds 127.0.0.1 — never expose it on the tailnet. Grafana (`http://studio.taile85139.ts.net:3001`) is the only front door.

## Port table (conflict-driven, do not drift)

| Service | Port | Why |
|---|---|---|
| macmon serve | 9199 | macmon's default 9090 collides with Prometheus |
| node_exporter | 9100 | Studio only (hub) |
| blackbox_exporter | 9115 | hub only (HTTP probes) |
| Prometheus | 9090 | Homebrew default |
| Grafana | 3001 | OrbStack owns 3000 on the Studio |

Check for port owners before choosing any new port: `lsof -nP -iTCP:<port> -sTCP:LISTEN`.

## Install & lifecycle (Studio only)

```bash
# Studio hub only (Mac Studio M3 Ultra)

brew install prometheus grafana
brew services start prometheus
brew services start grafana

# Install launchd agents (macmon, node_exporter) on this box only
macmon serve --install -p 9199 --host 0.0.0.0
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.macmon.plist
```

Grafana config: append `[server] http_addr=0.0.0.0 / http_port=3001 / domain / root_url` to `/opt/homebrew/etc/grafana/grafana.ini` (later directive wins — don't uncomment the stock section) and restart the service. Back up `/opt/homebrew/etc/prometheus.yml` before replacing it with the fleet config.

## Grafana first boot (must be done in order)

1. **Rotate the admin password immediately** — brew first boot is admin/admin over the tailnet. Generate: `openssl rand -base64 24 | tr -d '/+=' | head -c 20`, then:
   `curl -s -X PUT -u admin:admin -H "Content-Type: application/json" -d '{"oldPassword":"admin","newPassword":"<pw>","confirmNew":"<pw>"}' localhost:3001/api/user/password` <!-- gitleaks:allow — Grafana factory default, rotated in this very step -->
2. **Add the Prometheus datasource**: POST `/api/datasources` `{"name":"Prometheus","type":"prometheus","access":"proxy","url":"http://localhost:9090","isDefault":true,"jsonData":{"httpMethod":"POST"}}` — record the returned `uid`.
3. **Import the dashboard**: POST `/api/dashboards/db` with `{"dashboard": {...}, "overwrite": true}` from `templates/grafana-dashboard.json`. If the datasource uid differs on a fresh install, replace it in the JSON or use `${DS_PROMETHEUS}` (the import flow rewrites it).

## launchd agent health (textfile collector)

node_exporter's `--collector.textfile.directory` lets a shell script export per-service liveness without writing an exporter. Run `agent_health_textfile.sh` on a 60s launchd `StartInterval`; it emits `agent_running{label=...}` and `agent_last_exit_status{label=...}` gauges for every launchd agent matching meemeep / com.macmon / com.blackbox / sh.brew / ai.(hermes|llama-swap|mnemosyne). Wire the dir into node_exporter.args: `--collector.textfile.directory=/opt/homebrew/var/node_exporter/textfiles`. This turns "Lorg ran 14h ago" into a panel; a dead agent reads 0 with no alert rules needed. Full recipe in references/exporters-and-scrape-targets.md.

## Verify end to end

1. **Check target completeness before target health.** Compare the intended studio targets with both `/api/v1/status/config` and `/api/v1/targets`. The bundled `scripts/targets-check.py` reports only configured active targets; all listed targets can be `up` while a host is missing from the scrape config. Confirm the expected macmon (`studio`) and node_exporter targets are present.
2. **Check target health:** `curl -s localhost:9090/api/v1/targets` — every configured target `health` must be `up`, not `unknown` (allow one scrape interval after start).
3. **Check data flow:** `curl -s 'localhost:9090/api/v1/query?query=macmon_gpu_freq_mhz'` returns a value.
4. **Check Grafana:** `curl -s localhost:3001/api/health` → `database: ok`; with an authorized API request, datasource health via `/api/datasources/uid/<uid>/health` should report "Successfully queried the Prometheus API." A 401 means the check was unauthenticated, not that the datasource is unhealthy.
5. **Check tailnet path from a separate host:** request `http://studio.taile85139.ts.net:9199/metrics` (macmon) and confirm HTTP 200 with a nonempty body. A successful localhost scrape proves only the local path.

## Pitfalls

- **Skill consolidation: `prometheus-grafana-monitoring` replaces `fleet-monitoring-stack`.** The older skill (`fleet-monitoring-stack`) is retired; keep only the current class-level umbrella. Both the MacBook and Studio run this stack, but this skill is authored on the MacBook (development host per 2026-09-24 convention) and copied to the Studio (`scp ... studio:`). Always verify with the Studio's live `/opt/homebrew/etc/prometheus.yml` before trusting template copies.
- **Probe remote Macs for brew/macmon with absolute paths, never `which`.** Non-interactive SSH shells (BatchMode) get a minimal PATH (`/usr/bin:/bin:/usr/sbin:/sbin`) and never source shell profiles, so `which brew` returns nothing even when Homebrew is installed. `ssh studio 'which brew'` → empty does NOT mean "no brew". Use `/opt/homebrew/bin/macmon --version`. This exact mistake produced a wrong architecture conclusion (box declared brew-free when it had brew all along).
- **`launchctl bootstrap` → "Bootstrap failed: 5: Input/output error" is benign when the label is already registered** — it is a re-registration warning, not a failure. Confirm with `launchctl list | grep <label>` and a curl of the port; the service is normally up and answering.
- **Don't inline Python one-liners with nested quotes over SSH** — the quoting layers break (`Argument expected for the -c option`, ImageMagick `import` hijacking the name). Write the helper to a local file, `scp` it, run it remotely.
- **A target-health script cannot detect missing targets.** Compare the live scrape config and active targets with the intended studio inventory; these scripts enumerate only configured targets, so a perfect `N/N up` can still hide an omitted service.
- **A wildcard listener and a successful localhost scrape do not prove tailnet access.** Probe `/metrics` from a separate host (`studio.taile85139.ts.net:9199`); compare with localhost and confirm HTTP status plus a nonempty body, because address binding alone does not verify the remote request path.
- **Verify by reading the machine back, not the command output.** A target that reads `unknown` right after Prometheus starts just hasn't had its first scrape; sleep one interval and re-query before concluding targets are broken.
- **blackbox_exporter is not in Homebrew core.** The core formula named `blackbox` is StackExchange's secret-storage tool — wrong. Install the official darwin-arm64 release binary from GitHub releases + a launchd plist with KeepAlive.
- **Prometheus config changes need `brew services restart prometheus`, not /-/reload.** brew's default args omit `--web.enable-lifecycle`, so the reload endpoint returns 403.
- **brew-generated plists have RunAtLoad but not KeepAlive** (prometheus, grafana, node_exporter) — without a manual KeepAlive=true a crash leaves the service dead. Add it with PlistBuddy; note `brew upgrade` regenerates those plists and silently drops the manual edit. (Pattern in macos-launch-agents.)
- **Grafana unit IDs: `decmbytes` = MB, `decgbytes` = GB.** A wrong unit makes the axis label lie about the values (the Memory panel shipped as MB while showing GB). Check `fieldConfig.defaults.unit` whenever a panel's labels don't match its numbers.
- **Edit an existing dashboard via API, not by hand.** GET /api/dashboards/uid/<uid>, mutate the JSON (drop `id` before POSTing back), POST /api/dashboards/db with `overwrite:true`, then GET again and confirm the field actually stuck.

## Files

- `templates/prometheus-fleet.yml` — studio-local scrape config: `studio` (macmon :9199), `node-studio` (:9100), `blackbox-http` probes against localhost endpoints.
- `templates/grafana-dashboard.json` — 9-panel studio-only dashboard (GPU freq/ratio/power, CPU P+E freqs, CPU ratio, package power, temps with thresholds, RAM, fans) for the Studio host.
- `references/macmon-metrics.md` — verified `macmon_*` metric names, grouped, with the deprecated ones called out.
- `references/exporters-and-scrape-targets.md` — node_exporter install/args, blackbox binary install, textfile collector recipe, extended fleet prometheus.yml shape.
- `scripts/targets-check.py` — verify every Prometheus target's health via the API; run after any config change.

## Runtime note (2026-09-25)
Active model for this session: `poolside/laguna-xs-2.1:free` via `nous`. Previous fallback: `thinkingmachines/inkling:free` via OpenRouter. Use this metadata when answering model/provider questions.
