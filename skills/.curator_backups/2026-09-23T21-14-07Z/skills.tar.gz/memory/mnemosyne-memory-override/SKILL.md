---
name: mnemosyne-memory-override
description: |
  Mnemosyne is DISABLED on the Studio (off on purpose since 2026-09-18 while
  memory consolidates on Hindsight). Do not call mnemosyne_* tools or attempt
  Mnemosyne recall. Use the built-in memory tool plus Hindsight. Kept for the
  day Mnemosyne is re-enabled.
trigger: |
  Only relevant if Mnemosyne has been deliberately re-enabled. Otherwise: the
  built-in memory tool and Hindsight are the whole memory stack.
---

# Mnemosyne — DISABLED (was the secondary memory system)

**Current state (2026-09-18): Mnemosyne is off on purpose on the Studio.** Do not use it.

- `ai.mnemosyne-sync` launchd job: RunAtLoad/KeepAlive false + a disable override
- `plugins.disabled` in config.yaml includes `mnemosyne`
- `mcp.servers.mnemosyne.enabled: false`
- its 6-hourly health-monitor cron has been paused since 2026-09-07

The `mnemosyne_*` tools are therefore not exposed, and any attempt to recall from Mnemosyne
will fail or return stale data (its DB has not been written since 2026-08-28). Memory is
**the built-in `memory` tool (capped, every-turn) plus Hindsight** (the configured provider).

Re-enabling is a deliberate act: clear the launchd disable override, restore RunAtLoad/KeepAlive,
re-enable the plugin and the MCP server, and resume the health cron. Ask Patrick first.

---

## If Mnemosyne is re-enabled

The rules below were written when it was the secondary system. Re-read them then.

<!-- ponytail: vendor skill rewritten — original forced Mnemosyne as sole memory
     and instructed deleting legacy memory entries; user wants it secondary. -->

- The built-in `memory` tool remains the PRIMARY durable store. Keep using it as before.
- Additionally store durable facts worth semantic search in Mnemosyne:
  `mnemosyne_remember(content=..., importance=0.7+, source="fact"|"preference")`.
- When recalling, `mnemosyne_recall(query=...)` complements (never replaces) built-in memory.
- NEVER delete or migrate entries out of the built-in memory system.
- Use `mnemosyne_scratchpad_*` for ephemeral cross-tool state; `mnemosyne_triple_*` for entity relationships.
