# Operations Notes (migrated from MEMORY.md 2026-09-13)

Procedural/troubleshooting content migrated out of the always-injected memory store during the
2026-09-13 prune. Memory is capped at 12K chars and re-sent on every turn, so procedures belong
here where they load only when relevant. Source snapshot: `git -C ~/.hermes show 91b3be0:memories/MEMORY.md`.

## Alert routing on the Studio (audited 2026-09-16)

Everything infra-alerting is **Discord-only, and has been since 2026-08-28**; Telegram keeps only
two paths (deadman + gateway lifecycle notices), both documented below. Map:

| Producer | Where it pages |
|---|---|
| Outcomes 1h, Memory 5m, Health 5m, Embedding 15m, Auth 15m, Gateway Lifecycle 1m, Weekly Report | Discord #alert-infra `1522663709091168537` (via cron `deliver`) |
| `hermes-git-backup.sh` (launchd, daily 03:30) | Discord #alert-infra, posted by the script itself via `hermes send -t discord` — independent of the cron ticker |
| `watchdog_deadman.sh` (launchd, 10m) | **Telegram DM only** (`hermes send -t telegram`: home channel) — ticker staleness + broken alert path |
| Gateway start/stop notices | Both DMs (Discord `1539964352575307797` + Telegram `2058810010`) |
| Briefs / Gmail triage | #news-brief `1542864535826735194` / #alert-email `1544358067318038568` |

**Coverage gaps that remain:** Prometheus/node_exporter/blackbox/Grafana all run with **zero alert
rules**; Mnemosyne `sync-serve` has no watcher (its 6h health cron is disabled);
`llama_swap_monitor.py` posts to #alert-infra but nothing schedules it (dormant).

**How to audit this class of question:** read `j['deliver']` for every job in
`~/.hermes/cron/jobs.json`, then grep `~/.hermes/scripts/*.sh` for direct `"$HERMES_BIN" send -t`
calls (script-level sends bypass cron routing entirely), then
`/usr/libexec/PlistBuddy -c "Print :ProgramArguments" ~/Library/LaunchAgents/*.plist` for launchd
producers. `delivery_outcome` in `~/.hermes/cron/executions.db` shows `delivered` vs `suppressed`
(empty output) vs null, but not the target.

## Prometheus / node_exporter / Grafana (Studio)

All three are brew services (`sh.brew.prometheus`, `sh.brew.node_exporter`, `sh.brew.grafana`).
Prometheus 3.14 binds loopback `:9090`; since 2026-09-16 it is also reachable tailnet-only at
`https://studio.taile85139.ts.net:9090` via `tailscale serve --bg --https=9090 http://127.0.0.1:9090`.
**Grafana is on `:3001`; `:3000` is Open WebUI (OrbStack).** Retention 15d.

- **No alert rules anywhere**: Prometheus has no `rule_files`, Grafana has 0 rows in `alert_rule` and
no receivers. The stack can be read, never pages.
- Metric sources: `macmon` (job `studio`/`macbook`, `:9199`, CPU/GPU/RAM/power/temp), node_exporter
(`:9100`) with the **textfile collector** at `/opt/homebrew/var/node_exporter/textfiles`, and
blackbox HTTP probes (`:9115`). Collector jobs (`com.*.textfile`) rewrite `agent_health.prom`,
`hermes_usage.prom`, `claude_code_usage.prom` every few minutes; series land under `job="node-studio"`.
- `hermes_model_*` labels: `host`, `model`, `provider`, `kind` (input/output/cache_read/reasoning),
`tier` (cloud/local/unknown). `claude_code_*` adds `project`. `agent_running` /
`agent_last_exit_status` are keyed by launchd `label`.
- **Prometheus has no saved dashboards or image export**, so the repeatable views are
  (a) bookmarks: `/query?gN.expr=...&gN.tab=0|1&gN.range_input=24h` (any number of graphs, tab=1 is
  the table view), and (b) `~/.hermes/monitoring/prom_snapshot.py --hours N`, which renders
  `fleet/studio/usage/claude_code.png` from the query API. Query cheatsheet:
`~/.hermes/monitoring/prometheus-queries.md`.
- **macOS tailnet self-test trap:** you cannot curl your own `100.x` address from the node that owns
it (no `tailscale0`); a `000` there is not evidence the service is unreachable. Verify from another
node.

## The outcomes watchdog (`scripts/watchdog_outcomes.sh`)

Hourly `no_agent` job `a51280fccc82`; stdout is the alert, empty output = healthy. Sections: cron
status/delivery errors, git-backup freshness, **hindsight dump freshness (added 2026-09-16)**, runaway
`hermes serve`, MCP servers enabled-but-failing. Tunables are env vars:
`OUTCOMES_MAX_SERVE`, `OUTCOMES_BACKUP_MAX_AGE_H` (36), `OUTCOMES_MCP_MAX_AGE_SEC` (8h),
`OUTCOMES_HINDSIGHT_MAX_AGE_H` (**80h** — the dump job is Mon/Wed/Fri, so 36h false-pages every
Monday), `OUTCOMES_ALERT_REPEAT` (5 cycles before auto-ack and quiet for 24h).

- The hindsight check reads the **newest dump's mtime** (`~/backups/hindsight/hindsight-*.dump`),
not the log text — the log's `Sun Sep 13 03:10:07 EDT 2026` stamps need locale/zone parsing.
- `alert_key <key> <msg>` turns the key into a **filename**, so the key is sanitized to
`[:alnum:]._:-` before use. An unsanitized key (a cron message containing `/` and a newline) built a
nonexistent nested path, the state write failed under `set -e`, and the watchdog died silently —
taking every alert it exists to send with it.
- Silence one alert by hand: `~/.hermes/scripts/ack_outcomes.sh <key>` (`-r` to un-ack). State lives
in `~/.hermes/state/watchdog-outcomes/<key>.{count,first_seen,last_seen,ack_until,sig}`.
- **Test edits in an isolated `HERMES_HOME`**, not just `bash -n`: the script dies on a missing
`cron/jobs.json`, so a real-state dry run proves nothing about the branches you added.

Procedural/troubleshooting content migrated out of the always-injected memory store during the
2026-09-13 prune. Memory is capped at 12K chars and re-sent on every turn, so procedures belong
here where they load only when relevant. Source snapshot: `git -C ~/.hermes show 91b3be0:memories/MEMORY.md`.

Procedural/troubleshooting content migrated out of the always-injected memory store during the
2026-09-13 prune. Memory is capped at 12K chars and re-sent on every turn, so procedures belong
here where they load only when relevant. Source snapshot: `git -C ~/.hermes show 91b3be0:memories/MEMORY.md`.

## macOS / Tailscale networking

- macOS Tailscale uses the **utun4** interface; there is **no `tailscale0`**. Binding a process to
a `100.x` address directly will not work.
- The Hermes web UI on `127.0.0.1:8787` is exposed to the tailnet with `tailscale serve`, which maps
HTTPS `studio.taile85139.ts.net` to `http://127.0.0.1:8787`. Do not force a `utun`/`100.x` bind.
- Clients reach it only while on the tailnet with **MagicDNS enabled** (see also the Tailscale
binding quirk in SKILL.md).

## Gateway: lifecycle, launchd, Photon

- The Studio gateway runs as a launchd service. Restart with the modern syntax:

```bash
launchctl bootout gui/$(id -u)/ai.hermes.gateway
sleep 3
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/ai.hermes.gateway.plist
```

- **The agent cannot restart the gateway from inside it** — the guard blocks it (SIGTERM would kill
the command before it completed), and a detached/delayed wrapper is refused too. Hand the user
`/restart` in chat (graceful; drains active runs first) or `hermes gateway restart` from a shell
outside the app.
- **Photon sidecar** needs `npm install` in `plugins/platforms/photon/sidecar/`.
- API server listens on **:8642**; desktop app remote is `studio.taile85139.ts.net:9119`.
- MBP convenience aliases: `hstudio`, `hrun` (plus `hwork`, `hpersonal`).

## Gateway lifecycle notifications

Sent per-platform to the HOME channel, gated by `gateway_restart_notification` (currently `true`).
There is **no dedicated alerts-channel routing in core** (feature request filed:
NousResearch/hermes-agent #76780). These are the **only** messages that still reach Telegram: the
start/stop notice goes to the Telegram DM `2058810010` *and* the Discord DM
`1539964352575307797`.

**Destination control lives in the cron job's `deliver`, not in config.** `telegram.allowed_chats`
is an *inbound group gate* (`plugins/platforms/telegram/adapter.py::_check_group_trigger_rules`,
skipped entirely when empty) — it never routed outbound alerts. To retire a platform as an alert
target, edit every job's `deliver` string (set with `hermes cron ...`; tracked in
`~/.hermes/cron/jobs.json`, which the git backup commits, so the switch is auditable).

Legacy Telegram alerts channel: `-1003940233719` ("Hermes Alerts"). It was the watchdog fan-out
target until 2026-08-28, when every watchdog job's `deliver` became Discord-only. The bot is still
an admin of it; `allowed_chats` no longer lists it. To stop it cold, remove the bot from the
channel (or leave it — nothing targets it).

## config.yaml corruption pattern (Hermes)

List-valued fields (`plugins.enabled`, `model_catalog.excluded_providers`) sometimes get written as
Python/JSON **strings** instead of YAML lists. They still load, and are silently ignored. Fixed
`plugins.enabled` on the Studio 2026-08-02; filed Linear DEV-347.

**Always type-check list fields when auditing config.** To hide a provider from Hermes pickers use
`model_catalog.excluded_providers` — `hermes tools disable` does **not** hide providers.

Remember `hermes config set <key> <value>` is the only sanctioned write path; the `patch` tool
refuses `config.yaml` outright.

## `memory` tool: `replace` on `target=user` clobbers the whole file

Verified 2026-09-17. Calling the memory tool with `action=replace`, `target=user`, and an `old_text`
substring that matched inside the **first** entry rewrote `USER.md` down to that entry plus the
trailing one. 5,528 chars and 9 `##` sections became 769 chars and 2 entries. The other 8 sections
(Identity, Professional, Qualcomm accounts, Home AI Stack, Communication Preferences, Technical
Conventions, Community, Interests) were gone from disk.

**Never use the memory tool to edit USER.md.** Edit `~/.hermes/memories/USER.md` directly with the
`patch` tool, then re-check the section count. Same care for MEMORY.md.

Recovery path, in order:

1. `git -C ~/.hermes show HEAD:memories/USER.md` — `memories/` is in the .gitignore allowlist, so the
   pre-clobber version is in git. This is the fastest and most complete source.
2. `~/.hermes/memories/USER.md.bak-prune-*` — prune-era backups, older but present.
3. Before restoring, confirm byte size **and** `grep -c '^## '` against the known-good counts.

Then prove the restore with `git diff memories/USER.md`: the diff must contain only the intended
change. A diff showing whole-file replacement means the restore is wrong.

One follow-on trap: `memories/` is whitelisted, so any stray file dropped there (e.g. a
`.CLOBBERED-*` rescue copy) gets committed by the next backup run. Clean up rescue copies.

## Disabling an MCP server

`hermes mcp` has **no `disable` subcommand**. Manually comment out or remove the server in
`~/.hermes/config.yaml` under **both** `mcp.servers` and any later top-level block, then restart the
gateway. (See also the MCP auth/reload traps in SKILL.md — an already-registered server keeps
retrying with its captured config until the process reloads.)

## Dashboard auth internals

Dashboard auth uses an `scrypt` `password_hash` plus an HMAC secret. A past OAuth mismatch turned
out to be a **redirect URI mismatch**, fixed by matching the dashboard's canonical URL.

## Git / GitHub

- GitHub hard-blocks objects over **100 MB** (e.g. `state.db`). Keep them excluded from commits or
pushes fail.
- Hermes backup remote: origin is `https://github.com/prasta1/backup-hermes-macstudio.git`.

## Skills directory hygiene (historical churn, resolved)

`~/.hermes/skills/` accumulated symlinks/submodule pointers to `~/.agents/skills/`, which produced
unworkable ~394-file git churn. Symlinked external skill roots also make "every SKILL.md change is a
normal file modification" an unsafe assumption when staging.

**Standing rule: skills live as real directories under `~/.hermes/skills/`.** If the churn returns,
restore by copying the real trees from `~/.agents/skills/` back in as normal directories.

## OOM triage

Distinguish three cases: **container cap hit** vs **leak** vs **host-pressure collateral kill**.
LM Studio Metal OOM plus orphan helper processes plus low `vm_stat` free pages indicates *host
pressure*, not a container limit.

## Hermes-webui vs gateway (separate launchd jobs)

`hermes-webui/server.py` (`com.hermes.webui`, :8787) and the gateway (`ai.hermes.gateway`, :8642) are
**separate launchd jobs**. The 409 `agent_runtime_stale` fix is to set config.yaml
`webui_chat_backend: gateway` and export the gateway-mode env vars in `hermes-webui-launch.sh`.
That workaround is retired.

**Quirk:** `/api/health/agent`'s `gateway_chat` field reads **env vars only**, never config.yaml.

## `hermes update` merge conflict on the custom `local` branch

The updater tracks `local` (fork branch: discord brief embeds, config/email fixes) and merges
`origin/main` **in place** rather than resetting. On conflict it aborts the whole update and
leaves the tree unchanged — nothing was half-applied, so resolve in
`~/.hermes/hermes-agent` and re-run.

1. **Preview without touching the tree:** `git merge-tree --write-tree --name-only local origin/main`
   (git ≥ 2.38) prints the conflicted paths. Expect it to be one file, not many.
2. `git merge origin/main` — let every other file auto-merge.
3. **Resolve by keeping BOTH sides; never drop the local side.** Read both diffs against the
   merge base (`git diff $(git merge-base local origin/main) <side> -- <path>`).
4. **The trap: an upstream refactor of the block your local code sits next to.** Keeping the
   local hunk verbatim re-introduces a stale override that silently reverts upstream's
   refactor. In the Sep-2026 merge, upstream replaced `DiscordAdapter.send_exec_approval` with
   `_EA_*` constants + `_exec_approval_cmd_budget` + `_send_exec_approval_prompt`, moving the
   public method to `BasePlatformAdapter`. Correct resolution: keep the local additions
   (`_parse_brief_content`, `_send_brief_embed`), **delete** the local `send_exec_approval`
   override, splice upstream's block after it.
   Verify the deletion landed: `'send_exec_approval' in DiscordAdapter.__dict__` must be
   `False` while `hasattr(...)` stays `True` via the base class.
5. **Take upstream's helper swaps inside the same hunk** — e.g. local `return {"error": ...}`
   became upstream `send_error(...)` from `gateway.platforms._shared`. Keep upstream.
6. Verify before committing: no leftover markers (`grep -n '^<<<<<<<\|^>>>>>>>\|^=======$'`),
   `python3 -m py_compile <file>`, then import the plugin for real:
   `./venv/bin/python3 -c "import importlib; importlib.import_module('plugins.platforms.discord.adapter')"`.
   The runtime venv (`~/.hermes/hermes-agent/venv`) has the deps; it does **not** have pytest, so
   `scripts/run_tests.sh` errors with "no virtualenv with pytest found" unless a `.venv` is built.
7. `git add <paths> && git commit --no-edit`, confirm
   `git rev-list --left-right --count local...origin/main` ends in `0`, then re-run `hermes update`
   to finish dependency sync + service restart.

**Never `git reset --hard` or rebase to "fix" this** — local commits must survive.

## Codebase review method

When reviewing an entire codebase with no fixed point, classify findings as: **hard break**,
**latent risk**, **polish/data quality**. Report exact `file:line` references and lead with what is
currently broken before latent risk or polish.
