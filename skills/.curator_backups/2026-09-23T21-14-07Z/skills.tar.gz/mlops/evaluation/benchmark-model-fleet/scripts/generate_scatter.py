#!/usr/bin/env python3
"""Generate scatter plots from benchmark CSV results — dark dramatic edition.

Design:
  - Near-black paper, generous negative space, crisp grid.
  - Uniform marker size across all active models (no size encoding → clean comparison).
  - Type encoded by shape + colour only: square / triangle / circle / diamond.
  - oMLX models get a subtle accent ring so the new benchmark run reads at a glance.
  - Annotations placed with side-biased nudging to avoid overlap; hairline leaders.
  - Deleted models: dim grey ×, no leader, label set back.

Usage:
    python3 generate_scatter.py --results-dir ~/.hermes/benchmark_results
                                 --model-config references/model-config.json
                                 --label Coding
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from adjustText import adjust_text
import csv
import os
import json
import argparse

# ---------------------------------------------------------------------------
# Palette — dark paper, high-contrast data, one accent for the new run.
# ---------------------------------------------------------------------------
BG        = '#14141A'   # near-black with blue undertone
PANEL     = '#181820'   # slightly lighter plot floor
INK       = '#F0EDE6'   # warm off-white text
MUTED     = '#7A7A84'   # axis labels, tick labels, secondary
GRID      = '#26262E'   # subtle warm grid
LEADER    = '#484852'   # hairline leader

# Data colours — muted but distinct on dark ground
COLORS = {
    "MoE":        '#6B9BD6',   # soft blue
    "Vision":     '#E0A565',   # warm amber
    "Standard":   '#D97A6B',   # muted brick
    "Embeddings": '#6E6E76',   # neutral grey
}

MARKERS = {
    "MoE":        's',
    "Vision":     '^',
    "Standard":   'o',
    "Embeddings": 'D',
}

DELETED_COLOR = '#4A4A52'

# oMLX accent — a single saturated highlight that reads as "newly benchmarked"
OMLX_ACCENT     = '#F2C14E'   # warm gold
OMLX_GLOW_ALPHA = 0.35
OMLX_GLOW_SCALE = 1.22

# Uniform marker size for every active model — no size encoding
MARKER_SIZE = 185
MARKER_EDGE = 1.4

# ---------------------------------------------------------------------------
# Legend handles (shared)
# ---------------------------------------------------------------------------
def _legend_handles():
    return [
        Line2D([0], [0], marker='s', color='w', markerfacecolor=COLORS['MoE'],
               markersize=12, label='MoE', markeredgecolor='#FFFFFF', markeredgewidth=0.9),
        Line2D([0], [0], marker='^', color='w', markerfacecolor=COLORS['Vision'],
               markersize=12, label='Vision', markeredgecolor='#FFFFFF', markeredgewidth=0.9),
        Line2D([0], [0], marker='o', color='w', markerfacecolor=COLORS['Standard'],
               markersize=12, label='Standard', markeredgecolor='#FFFFFF', markeredgewidth=0.9),
        Line2D([0], [0], marker='D', color='w', markerfacecolor=COLORS['Embeddings'],
               markersize=10, label='Embeddings', markeredgecolor='#FFFFFF', markeredgewidth=0.9),
        Line2D([0], [0], marker='x', color='w', markerfacecolor=DELETED_COLOR,
               markersize=13, label='Deleted',
               markeredgecolor=DELETED_COLOR, markeredgewidth=2.4, linestyle='None'),
    ]

LEGEND_HANDLES = _legend_handles()

# ---------------------------------------------------------------------------
# Shared style
# ---------------------------------------------------------------------------
def _style_figure(fig, ax, title):
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(PANEL)

    ax.set_title(title, fontsize=16, fontweight='600', color=INK,
                 pad=30, loc='left', family='DejaVu Sans')

    ax.set_xlabel('', fontsize=1, labelpad=1)
    ax.set_ylabel('', fontsize=1, labelpad=1)

    ax.tick_params(colors=MUTED, labelsize=10.5, length=0, pad=8)
    for spine in ('top', 'right'):
        ax.spines[spine].set_visible(False)
    for spine in ('left', 'bottom'):
        ax.spines[spine].set_color(GRID)
        ax.spines[spine].set_linewidth(1.0)

    ax.yaxis.grid(True, color=GRID, linewidth=0.9, alpha=0.9, zorder=0)
    ax.xaxis.grid(False)
    ax.set_axisbelow(True)

    return fig, ax

def _place_axis_labels(ax, xlabel, ylabel):
    ax.text(
        0.5, -0.108, xlabel,
        transform=ax.transAxes,
        ha='center', va='top',
        fontsize=11.5, color=MUTED, fontweight='500',
        family='DejaVu Sans',
    )
    ax.text(
        -0.098, 0.5, ylabel,
        transform=ax.transAxes,
        ha='center', va='center',
        fontsize=11.5, color=MUTED, fontweight='500',
        rotation=90,
        family='DejaVu Sans',
    )

# ---------------------------------------------------------------------------
# Annotation helpers
# ---------------------------------------------------------------------------
def _stamp_marker(ax, x, y, color, marker, size=MARKER_SIZE,
                  edge='white', edge_width=MARKER_EDGE, alpha=0.95, z=6):
    ax.scatter(x, y, s=size, c=color, marker=marker,
               alpha=alpha, edgecolors=edge, linewidths=edge_width, zorder=z)

def _resolve_labels(ax, labels, pts_x, pts_y, x_pad, y_pad):
    """De-overlap annotations with adjustText; markers act as keep-out zones."""
    if len(labels) < 2:
        return
    adjust_text(
        labels,
        x=pts_x,
        y=pts_y,
        expand_points=(x_pad, y_pad),
        expand_text=(1.15, 1.15),
        only_move='text',
        ax=ax,
        autoalign='auto',
        lim=500,
        precision=0.001,
    )

def _annotate_active(ax, name, x, y, xytext, extra='', accent=False,
                     marker='o', color=None, labels=None):
    """Active model label with hairline leader; appended to labels for adjustText.

    xytext is in DATA coordinates (not offset points) so adjustText can
    reposition labels relative to markers.
    """
    label = f"{name}   ·   {extra}" if extra else name

    if accent:
        _stamp_marker(ax, x, y, 'none', marker,
                      size=int(MARKER_SIZE * OMLX_GLOW_SCALE),
                      edge=OMLX_ACCENT, edge_width=1.8,
                      alpha=OMLX_GLOW_ALPHA, z=4)

    if color is None:
        color = COLORS.get('Standard', '#FFFFFF')
    _stamp_marker(ax, x, y, color, marker, edge='#FFFFFF', z=6)

    ann = ax.annotate(
        label,
        (x, y),
        xytext=xytext,
        textcoords='data',
        fontsize=10,
        fontweight='500',
        color=INK,
        ha='left' if xytext[0] > x else 'right',
        va='center',
        arrowprops=dict(
            arrowstyle='-',
            color=LEADER,
            alpha=0.85,
            lw=0.8,
            shrinkA=2,
            shrinkB=4,
        ),
        zorder=12,
    )
    if labels is not None:
        labels.append(ann)
    return ann

def _annotate_deleted(ax, name, x, y):
    """Deleted-model label — offset-points, not routed through adjustText."""
    ax.scatter(x, y, s=90, c=DELETED_COLOR, marker='x',
               alpha=0.65, zorder=3, linewidths=2.2)
    ax.annotate(
        name,
        (x, y),
        xytext=(6, -10),
        textcoords='offset points',
        fontsize=9,
        color=MUTED,
        ha='left',
        va='center',
        fontstyle='italic',
        zorder=9,
    )

def _legend(ax):
    ax.legend(
        handles=LEGEND_HANDLES,
        loc='upper left',
        bbox_to_anchor=(0.014, 0.985),
        borderaxespad=0.6,
        fontsize=11,
        frameon=True,
        facecolor='#1E1E26',
        edgecolor=GRID,
        labelcolor=INK,
        labelspacing=0.8,
        handletextpad=0.7,
        borderpad=0.8,
        handlelength=1.5,
    )


# ---------------------------------------------------------------------------
# Plot 1 — Coding Speed × Quality
# ---------------------------------------------------------------------------
def plot_coding_speed_quality(models, output_path, label='Coding'):
    fig, ax = plt.subplots(figsize=(15.5, 10.5))
    _style_figure(fig, ax, f'Model Fleet   ·   {label} Speed × Quality')
    _place_axis_labels(ax,
                       'Coding Speed  (tokens / sec)',
                       'Quality Score  (0 – 1)')

    rows = [(m, m['coding_spd'], m['quality']) for m in models
            if m.get('coding_spd') is not None]
    if not rows:
        print('  (no coding data to plot)')
        plt.savefig(output_path, dpi=190, bbox_inches='tight', facecolor=BG,
                    pad_inches=0.35)
        plt.close()
        return

    xs = [r[1] for r in rows]
    ys = [r[2] for r in rows]
    x_max = max(xs) * 1.15
    y_max = max(ys) * 1.08 if ys else 1.0

    ax.set_xlim(0, x_max)
    ax.set_ylim(0.55, y_max)

    labels = []
    pts_x, pts_y = [], []

    # Split oMLX vs fleet so accent ring draws last (on top)
    omlx_rows = [r for r in rows if r[0].get('source') == 'omlx']
    fleet_rows = [r for r in rows if r[0].get('source') != 'omlx']

    for m, x, y in fleet_rows:
        if m['deleted']:
            _annotate_deleted(ax, m['name'], x, y)
            continue
        color = COLORS.get(m['type'], COLORS['Standard'])
        marker = MARKERS.get(m['type'], 'o')
        _stamp_marker(ax, x, y, color, marker)
        tx = x + 9 if x < x_max * 0.76 else x - 9
        ty = y + 0.022
        _annotate_active(ax, m['name'], x, y, (tx, ty),
                         extra=f"{m.get('size_gb', '?')} GB",
                         marker=marker, color=color, labels=labels)
        pts_x.append(x)
        pts_y.append(y)

    for m, x, y in omlx_rows:
        if m['deleted']:
            _annotate_deleted(ax, m['name'], x, y)
            continue
        tx = x + 9 if x < x_max * 0.76 else x - 9
        ty = y + 0.022
        _annotate_active(ax, m['name'], x, y, (tx, ty),
                         extra=f"{m.get('size_gb', '?')} GB  ·  oMLX",
                         accent=True, labels=labels)
        pts_x.append(x)
        pts_y.append(y)

    _resolve_labels(ax, labels, pts_x, pts_y, x_pad=5.0, y_pad=0.035)
    _legend(ax)

    plt.tight_layout(rect=(0.0, 0.0, 1.0, 1.0))
    plt.savefig(output_path, dpi=190, bbox_inches='tight', facecolor=BG,
                pad_inches=0.35)
    plt.close()
    print(f"  Saved: {os.path.basename(output_path)}")


# ---------------------------------------------------------------------------
# Plot 2 — Vision Speed × Output Detail
# ---------------------------------------------------------------------------
def plot_vision_speed_detail(models, output_path):
    fig, ax = plt.subplots(figsize=(15.5, 10.5))
    _style_figure(fig, ax, 'Model Fleet   ·   Vision Speed × Output Detail')
    _place_axis_labels(ax,
                       'Vision Speed  (tokens / sec)',
                       'Output Detail  (characters)')

    rows = [(m, m['vision_spd'], m.get('vision_chars', 0) or 0)
            for m in models if m.get('vision_spd') is not None]
    if not rows:
        print('  (no vision data to plot)')
        plt.savefig(output_path, dpi=190, bbox_inches='tight', facecolor=BG,
                    pad_inches=0.35)
        plt.close()
        return

    xs = [r[1] for r in rows]
    ys = [r[2] for r in rows]
    x_max = max(xs) * 1.15
    y_max = max(ys) * 1.16 if ys else 1200

    ax.set_xlim(0, x_max)
    ax.set_ylim(0, y_max)

    labels = []
    pts_x, pts_y = [], []

    for m, x, y in sorted(rows, key=lambda r: r[1]):
        if m['deleted']:
            _annotate_deleted(ax, m['name'], x, y)
            continue
        color = COLORS.get(m['type'], COLORS['Standard'])
        marker = MARKERS.get(m['type'], 'o')
        _stamp_marker(ax, x, y, color, marker)
        tx = x + 9 if x < x_max * 0.76 else x - 9
        ty = y + max(25, y * 0.025)
        _annotate_active(ax, m['name'], x, y, (tx, ty),
                         extra=f"{m.get('size_gb', '?')} GB",
                         marker=marker, color=color, labels=labels)
        pts_x.append(x)
        pts_y.append(y)

    _resolve_labels(ax, labels, pts_x, pts_y, x_pad=5.0, y_pad=max(25, y_max * 0.02))
    _legend(ax)

    plt.tight_layout(rect=(0.0, 0.0, 1.0, 1.0))
    plt.savefig(output_path, dpi=190, bbox_inches='tight', facecolor=BG,
                pad_inches=0.35)
    plt.close()
    print(f"  Saved: {os.path.basename(output_path)}")


# ---------------------------------------------------------------------------
# Plot 3 — Speed × Efficiency (tok/s per GB)
# ---------------------------------------------------------------------------
def plot_speed_efficiency(models, output_path, label='Coding'):
    fig, ax = plt.subplots(figsize=(15.5, 10.5))
    _style_figure(fig, ax, f'Model Fleet   ·   {label} Speed × Efficiency')
    _place_axis_labels(ax,
                       'Speed  (tokens / sec)',
                       'Efficiency  (tokens / sec per GB)')

    rows = []
    for m in models:
        spd = m.get('coding_spd')
        sz = m.get('size_gb')
        if spd is None or not sz:
            continue
        rows.append((m, spd, spd / sz))

    if not rows:
        print('  (no efficiency data to plot)')
        plt.savefig(output_path, dpi=190, bbox_inches='tight', facecolor=BG,
                    pad_inches=0.35)
        plt.close()
        return

    xs = [r[1] for r in rows]
    ys = [r[2] for r in rows]
    x_max = max(xs) * 1.15
    y_max = max(ys) * 1.18 if ys else 60

    ax.set_xlim(0, x_max)
    ax.set_ylim(0, y_max)

    labels = []
    pts_x, pts_y = [], []

    omlx_rows = [r for r in rows if r[0].get('source') == 'omlx']
    fleet_rows = [r for r in rows if r[0].get('source') != 'omlx']

    for m, x, y in fleet_rows:
        if m['deleted']:
            _annotate_deleted(ax, m['name'], x, y)
            continue
        color = COLORS.get(m['type'], COLORS['Standard'])
        marker = MARKERS.get(m['type'], 'o')
        _stamp_marker(ax, x, y, color, marker)
        tx = x + 9 if x < x_max * 0.76 else x - 9
        ty = y + max(0.5, y * 0.04)
        _annotate_active(ax, m['name'], x, y, (tx, ty),
                         extra=f"{y:.1f} tok/s/GB",
                         marker=marker, color=color, labels=labels)
        pts_x.append(x)
        pts_y.append(y)

    for m, x, y in omlx_rows:
        if m['deleted']:
            _annotate_deleted(ax, m['name'], x, y)
            continue
        tx = x + 9 if x < x_max * 0.76 else x - 9
        ty = y + max(0.5, y * 0.04)
        _annotate_active(ax, m['name'], x, y, (tx, ty),
                         extra=f"{y:.1f} tok/s/GB  ·  oMLX",
                         accent=True, labels=labels)
        pts_x.append(x)
        pts_y.append(y)

    _resolve_labels(ax, labels, pts_x, pts_y, x_pad=5.0,
                    y_pad=max(0.5, y_max * 0.04))
    _legend(ax)

    plt.tight_layout(rect=(0.0, 0.0, 1.0, 1.0))
    plt.savefig(output_path, dpi=190, bbox_inches='tight', facecolor=BG,
                pad_inches=0.35)
    plt.close()
    print(f"  Saved: {os.path.basename(output_path)}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Generate scatter plots — dark dramatic edition')
    parser.add_argument('--results-dir',
                        default=os.path.expanduser('~/.hermes/benchmark_results'))
    parser.add_argument('--output-dir', default=None)
    parser.add_argument('--model-config', default=None,
                        help='JSON file with model metadata (name, size_gb, type, deleted)')
    parser.add_argument('--label', default='Coding',
                        help='Task family shown in plot titles and filenames')
    args = parser.parse_args()

    output_dir = args.output_dir or args.results_dir
    os.makedirs(output_dir, exist_ok=True)

    config_path = args.model_config or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), '..', 'references',
        'model-config.json')
    models = []
    if os.path.exists(config_path):
        with open(config_path) as f:
            models = json.load(f)
    else:
        print(f'WARNING: model config not found at {config_path} — plots will be empty')

    slug = args.label.lower().replace(' ', '_')
    print('Generating dark plots…')
    plot_coding_speed_quality(
        models, os.path.join(output_dir, f'scatter_{slug}.png'), args.label)
    plot_vision_speed_detail(
        models, os.path.join(output_dir, 'scatter_vision.png'))
    plot_speed_efficiency(
        models, os.path.join(output_dir, f'scatter_{slug}_efficiency.png'),
        args.label)
    print('\nAll plots generated.')
