#!/usr/bin/env python3
"""Merge benchmark CSVs + on-disk GGUF sizes into the model-config.json the
plots and the final report read.

Replaces hand-transcribing 15 models x 4 fields out of the CSVs.

Sizes and model->file mapping come from the llama-swap config, so a model whose
GGUF path is broken shows up as 0.0 GB — which is itself a useful signal.

Usage:
    python3 build_model_config.py --results-dir ~/.hermes/benchmark_results/run-X \
        --llama-swap-config ~/.hermes/llama-swap/config.yaml \
        --out ~/.hermes/benchmark_results/run-X/model-config.json
"""
import argparse
import csv
import glob
import json
import os
import re
import statistics

# Substring -> type, first match wins. Drives bubble colour in the scatter plots.
TYPE_HINTS = [
    ("vl", "Vision"), ("vision", "Vision"), ("glm-4-6", "Vision"),
    ("moe", "MoE"), ("a3b", "MoE"), ("a4b", "MoE"), ("coder-30b", "MoE"),
    ("kat-coder", "MoE"), ("gpt-oss", "MoE"), ("laguna", "MoE"),
    ("bge", "Embeddings"), ("rerank", "Embeddings"),
]


def expand_shards(paths):
    """A config names only shard 1 of a split GGUF ('-00001-of-00003.gguf'), but the
    model on disk is all of them — count every sibling or the size is a big undercount."""
    out = []
    for p in paths:
        m = re.search(r'-(\d{5})-of-(\d{5})\.gguf$', p)
        if m:
            out += sorted(glob.glob(re.sub(r'-\d{5}-of-\d{5}\.gguf$',
                                           f'-*-of-{m.group(2)}.gguf', p)))
        else:
            out.append(p)
    return out


def model_sizes(config_path):
    """model id -> (size_gb, [missing paths]) from the llama-swap config."""
    text = open(config_path).read()
    out = {}
    for block in re.split(r'\n(?=  [a-zA-Z0-9_.-]+:\n)', text):
        m = re.match(r'  ([a-zA-Z0-9_.-]+):', block)
        if not m:
            continue
        paths = re.findall(r'(?:-m|--model|--mmproj)\s+(\S+)', block)
        if not paths:
            continue
        total, missing = 0, []
        for p in expand_shards(paths):
            try:
                total += os.path.getsize(p)
            except OSError:
                missing.append(p)
        out[m.group(1)] = (round(total / 1e9, 1), missing)
    return out


def read_rows(results_dir, prefix):
    rows = []
    for path in glob.glob(os.path.join(results_dir, f"{prefix}_*.csv")):
        with open(path) as f:
            head = f.readline()
            if not head.startswith("model,"):
                print(f"  skipping headerless CSV (pre-fix format): {os.path.basename(path)}")
                continue
            f.seek(0)
            rows += list(csv.DictReader(f))
    return rows


def agg(rows, model, field, drop_zero=True, fn=statistics.mean):
    """drop_zero=True for speeds (0 tok/s means the call failed).
    drop_zero=False for scores — a genuine 0.0 quality must not be averaged away."""
    vals = []
    for r in rows:
        if r["model"] != model or r.get("error"):
            continue
        try:
            v = float(r.get(field) or 0)
        except ValueError:
            continue
        if v > 0 or not drop_zero:
            vals.append(v)
    return round(fn(vals), 2) if vals else None


def guess_type(name):
    low = name.lower()
    for hint, t in TYPE_HINTS:
        if hint in low:
            return t
    return "Standard"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", required=True)
    ap.add_argument("--llama-swap-config",
                    default=os.path.expanduser("~/.hermes/llama-swap/config.yaml"))
    ap.add_argument("--out", required=True)
    ap.add_argument("--family", default="coding_bench",
                    help="CSV prefix to read for the speed/quality columns, e.g. "
                         "'structured_extraction_bench'. Defaults to coding_bench.")
    args = ap.parse_args()

    coding = read_rows(args.results_dir, args.family)
    vision = read_rows(args.results_dir, "vision_bench")
    sizes = model_sizes(args.llama_swap_config) if os.path.exists(args.llama_swap_config) else {}

    names = sorted({r["model"] for r in coding} | {r["model"] for r in vision})
    entries = []
    for n in names:
        size, missing = sizes.get(n, (None, []))
        e = {
            "name": n,
            "coding_spd": agg(coding, n, "median_tok_s"),
            "quality": agg(coding, n, "quality_score", drop_zero=False),
            "vision_spd": agg(vision, n, "median_tok_s"),
            "vision_chars": agg(vision, n, "quality_chars", drop_zero=False),
            "size_gb": size,
            "type": guess_type(n),
            "deleted": False,
        }
        if missing:
            e["broken_paths"] = missing
        entries.append(e)

    with open(args.out, "w") as f:
        json.dump(entries, f, indent=2)
    print(f"\nWrote {len(entries)} models -> {args.out}")
    for e in entries:
        flag = "  !! GGUF path broken" if e.get("broken_paths") else ""
        print(f"  {e['name']:<22} spd={str(e['coding_spd']):>7} qual={str(e['quality']):>5} "
              f"{str(e['size_gb']):>5}GB {e['type']}{flag}")


if __name__ == "__main__":
    main()
