#!/usr/bin/env python3
"""Consolidate benchmark CSVs into ranked summary tables.

Reads individual run CSVs from the benchmark output directory and produces
a consolidated ranking covering coding speed, vision performance, and
disk efficiency. Coding and vision numbers come from the CSVs (never stale
config values); the model config supplies only size and deleted status.

Usage:
    python3 generate_final_report.py --results-dir ~/.hermes/benchmark_results
                                      --model-config references/model-config.json
"""
import csv
import os
import json
import argparse
import glob
from datetime import datetime
from collections import defaultdict


def load_csv(path):
    rows = []
    with open(path) as f:
        for row in csv.DictReader(f):
            rows.append(row)
    return rows


def main():
    parser = argparse.ArgumentParser(description="Generate consolidated benchmark report")
    parser.add_argument("--results-dir", default=os.path.expanduser("~/.hermes/benchmark_results"))
    parser.add_argument("--model-config", required=False)
    args = parser.parse_args()

    results_dir = args.results_dir

    # Load model metadata (size, deleted status only — numbers come from CSVs)
    config_path = args.model_config or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "references", "model-config.json"
    )
    with open(config_path) as f:
        models = json.load(f)

    def meta_for(name):
        return next((mm for mm in models if mm["name"] == name), None)

    # Load all CSVs
    coding_csvs = sorted(glob.glob(os.path.join(results_dir, "coding_bench_*.csv")))
    vision_csvs = sorted(glob.glob(os.path.join(results_dir, "vision_bench_*.csv")))

    coding_rows = []
    for p in coding_csvs:
        coding_rows.extend(load_csv(p))

    vision_rows = []
    for p in vision_csvs:
        vision_rows.extend(load_csv(p))

    print("=" * 120)
    print(f"COMPLETE MODEL FLEET REPORT — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("=" * 120)

    # --- Coding Performance Ranking (from CSVs, not config) ---
    coding_data = defaultdict(lambda: {"speeds": [], "quals": []})
    for r in coding_rows:
        if r.get("error"):
            continue  # failed call, not a genuine 0.0 score
        m = r["model"]
        if float(r.get("median_tok_s", 0)) > 0:
            coding_data[m]["speeds"].append(float(r["median_tok_s"]))
            coding_data[m]["quals"].append(float(r.get("quality_score", 0)))

    print("\n--- CODING PERFORMANCE RANKING (from benchmark CSVs, ranked by speed) ---\n")
    print(f"{'Rank':>4} {'Model':<32} {'Speed':>8} {'Qual':>5} {'Size':>8} {'Status':<12}")
    print("-" * 80)

    ranked_coding = sorted(coding_data.items(),
                           key=lambda x: sum(x[1]["speeds"]) / len(x[1]["speeds"]), reverse=True)
    for i, (m, data) in enumerate(ranked_coding, 1):
        spd = sum(data["speeds"]) / len(data["speeds"])
        qual = sum(data["quals"]) / len(data["quals"]) if data["quals"] else 0.0
        meta = meta_for(m)
        size = f"{meta['size_gb']} GB" if meta else "?"
        status = "DELETED" if meta and meta["deleted"] else "ACTIVE"
        print(f"{i:>4} {m:<30} {spd:>6.1f}  {qual:>4.2f} {size:>8} {status:<12}")

    # --- Vision Performance ---
    vision_data = defaultdict(lambda: {"speeds": [], "chars": [], "inputs": []})
    for r in vision_rows:
        m = r["model"]
        if float(r.get("median_tok_s", 0)) > 0:
            vision_data[m]["speeds"].append(float(r["median_tok_s"]))
            vision_data[m]["chars"].append(int(r.get("quality_chars", 0)))
            vision_data[m]["inputs"].append(int(r.get("prompt_tokens", 0)))

    print("\n--- VISION PERFORMANCE RANKING ---\n")
    print(f"{'Rank':>4} {'Model':<32} {'Speed':>8} {'Chars':>8} {'Input':>8} {'Size':>8} {'Status':<12}")
    print("-" * 85)
    ranked_vision = sorted(vision_data.items(), key=lambda x: sum(x[1]["speeds"])/len(x[1]["speeds"]), reverse=True)
    for i, (m, data) in enumerate(ranked_vision, 1):
        spd = sum(data["speeds"]) / len(data["speeds"])
        ch = sum(data["chars"]) / len(data["chars"])
        ic = sum(data["inputs"]) / len(data["inputs"])
        meta = meta_for(m)
        size = f"{meta['size_gb']} GB" if meta else "?"
        status = "DELETED" if meta and meta["deleted"] else "ACTIVE"
        print(f"{i:>4} {m:<30} {spd:>6.1f} {ch:>8.0f} {ic:>8.0f} {size:>8} {status:<12}")

    # --- Speed × Vision Comparison ---
    print("\n--- CODING vs VISION SPEED COMPARISON ---\n")
    print(f"{'Model':<32} {'Coding tok/s':>14} {'Vision tok/s':>14} {'Size':>8}")
    print("-" * 72)
    all_names = sorted(set(coding_data) | set(vision_data) | {m["name"] for m in models},
                       key=lambda n: (sum(coding_data[n]["speeds"])/len(coding_data[n]["speeds"])
                                      if coding_data.get(n) and coding_data[n]["speeds"] else 0),
                       reverse=True)
    for m in all_names:
        cd = coding_data.get(m)
        cspd = f"{sum(cd['speeds'])/len(cd['speeds']):.1f}" if cd and cd["speeds"] else "—"
        vd = vision_data.get(m)
        vstr = f"{sum(vd['speeds'])/len(vd['speeds']):.1f}" if vd and vd["speeds"] else "—"
        meta = meta_for(m)
        size = f"{meta['size_gb']} GB" if meta else "?"
        status = " (DELETED)" if meta and meta["deleted"] else ""
        print(f"  {m:<30} {cspd:>14} {vstr:>14} {size:>8}{status}")

    print(f"\n{'='*120}")


if __name__ == "__main__":
    main()
