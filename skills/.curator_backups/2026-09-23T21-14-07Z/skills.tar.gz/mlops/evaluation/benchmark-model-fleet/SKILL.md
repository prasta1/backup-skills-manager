---
name: benchmark-model-fleet
description: Benchmark LLM speed, vision, quality and scatter plots.
version: 0.2.0
author: Hermes
categories: [mlops, evaluation]
tags: [Benchmarking, LLM, Visualization, Matplotlib]
---

# Model Fleet Benchmark & Visualization

Benchmark a fleet of llama-swap-hosted models — coding speed, vision performance, quality scoring, and scatter plot generation. Originally built to audit and right-size a 171 GB model fleet down to 110 GB (recovering 61 GB) while mapping speed × quality trade-offs.

**What it does**: Run coding/vision benchmarks against a llama-swap endpoint, compute quality scores via deterministic pattern matchers, generate matplotlib scatter plots (Speed × Quality, Vision Speed × Detail, Speed × Efficiency), and produce consolidated ranked reports.

**What it does NOT do**: Manage model lifecycle (loading, removal, disk cleanup). That's handled by separate llama-swap config operations. This skill only benchmarks, scores, visualizes, and reports.

**Key dependency**: llama-swap running with an OpenAI-compatible API (default `llama-swap-studio` = `http://127.0.0.1:9292`), matplotlib installed (`pip3 install matplotlib`). stdlib otherwise.

## When to Use

- Audit a model fleet's speed/quality tradeoffs before deletions
- Compare thinking vs non-thinking model variants
- Benchmark vision models (mmproj) with consistent image input
- Generate scatter plots showing deleted models greyed-out alongside active ones
- Produce ranked tables for reporting to stakeholders

## Prerequisites

- llama-swap running: `llama-swap :9292` (OpenAI-compatible endpoint). Verify with `scripts/discover_endpoints.py`.
- matplotlib: `pip3 install matplotlib`
- A test image for vision benchmarks: `scripts/test_image.png` (the benchmark sends base64 data URIs, not URLs — llama-swap mmproj requires `data:image/png;base64,...`)
- Knowledge of model names as served by llama-swap (e.g. `ms-qwen3-coder-30b`)

## How to Run

Invoke through the `terminal` tool. All scripts live in `scripts/`; run them from the skill root.

```bash
# 1. See what's live and what model ids each endpoint serves
python3 scripts/discover_endpoints.py --models

# 2. Run coding benchmarks (built-in coding prompts; requires --models or --all-models)
python3 scripts/benchmark.py --models ms-qwen3-coder-30b ms-devstral-24b
python3 scripts/benchmark.py --all-models          # every LLM the endpoint reports

# 3. Run vision benchmarks (uses scripts/test_image.png by default)
#    (models are unloaded after each benchmark by default; pass --no-unload to keep them resident)
python3 scripts/benchmark.py --vision --models ms-qwen3-vl-8b ms-glm-4-6-vision
python3 scripts/benchmark.py --models ms-qwen3-coder-30b --no-unload   # keep loaded after
python3 scripts/benchmark.py --vision --models ms-qwen3-vl-8b ms-glm-4-6-vision

# 4. Generate scatter plots (uses references/model-config.json for metadata)
python3 scripts/generate_scatter.py --results-dir ~/.hermes/benchmark_results

# 5. Generate consolidated ranked report
python3 scripts/generate_final_report.py --results-dir ~/.hermes/benchmark_results
```

Results land in `~/.hermes/benchmark_results/` (override with `--results-dir`):
- `coding_bench_<timestamp>.csv` / `vision_bench_<timestamp>.csv` — raw per-model results
- `scatter_coding.png`, `scatter_vision.png`, `scatter_coding_efficiency.png`
- ranked tables printed to stdout by `generate_final_report.py`

## Quick Reference

| Command | Purpose |
|---------|---------|
| `scripts/discover_endpoints.py` | Probe all registered endpoints, list live ones + model ids |
| `scripts/benchmark.py` | Coding/vision benchmark, writes CSV. **The canonical benchmark.** |
| `scripts/build_model_config.py` | Merge CSVs + on-disk GGUF sizes into model-config.json |
| `scripts/generate_scatter.py` | Matplotlib scatter plots (speed×quality, vision, efficiency) |
| `scripts/generate_final_report.py` | Consolidated ranked tables |
| `scripts/prompts.py` | Built-in coding & vision prompts + quality scorers |
| `prompts/*.py` | Task families for `--prompts-file`: web_frontend, data_analysis, structured_extraction, tool_calling, instruction_following, sql_generation |
| `references/endpoints.json` | Endpoint registry (llama-swap, LM Studio, oMLX, mlx_lm, Ollama, vLLM) |
| `references/model-config.json` | Model metadata (name, size_gb, type, deleted status) — **the one source of truth** |
| `references/benchmark-methodology.md` | Full methodology docs |

**Key API endpoints**:
- `POST http://127.0.0.1:9292/v1/chat/completions` — completion request
- `GET http://127.0.0.1:9292/v1/models` — list available models

**Endpoints**: `--endpoint` takes a registry name from `references/endpoints.json` (`llama-swap-studio`, `llama-swap-studio-tailnet`, `llama-swap-mbp`, `lm-studio`, `omlx`, `mlx-lm`, `ollama`, `vllm`) or a full URL. Default is `llama-swap-studio`. Run `scripts/discover_endpoints.py` first — most endpoints are down at any given time, which is expected. A dead endpoint fails preflight in <0.1s instead of retrying 30x per call, and ids the server does not serve are skipped with a warning.

**Auth**: endpoints that require a key (e.g. oMLX) set an `api_key` field in `endpoints.json` — `file:/path/to.json#/json/pointer` (read from a JSON file), `env:VARNAME`, or a literal. Both `discover_endpoints.py` and `benchmark.py` send it as a Bearer header. oMLX serves on **:8010** (settings.json `server.port`), not 8000, and requires its key.

**Task families**: `--prompts-file prompts/<family>.py` swaps the rubric. CSVs are named after the family so runs do not collide. Deterministic scoring is best for sql_generation (queries are executed against an in-memory SQLite and result sets compared), excellent for structured_extraction / tool_calling / instruction_following, good for web_frontend and data_analysis, and impossible for summarization or creative writing — do not fake those with pattern matchers.

## Procedure

1. **Verify llama-swap is running**: `python3 scripts/discover_endpoints.py` — confirm `llama-swap-studio` is UP and note the model ids. llama-swap loads models on-demand, so first requests may take time (retry on 503).

2. **Prepare test image** (for vision benchmarks): a PNG at `scripts/test_image.png`. The benchmark reads it as base64 and sends `data:image/png;base64,...` — llama-swap mmproj does NOT fetch URLs.

3. **Edit `references/model-config.json`**: List every model to benchmark with its metadata:
   ```json
   [{"name": "ms-qwen3-coder-30b", "size_gb": 16, "type": "MoE", "deleted": false}]
   ```
   Fields: `name` (llama-swap model ID), `size_gb` (for bubble size + efficiency), `type` (MoE/Vision/Standard/Embeddings for coloring), `deleted` (grey X marker on plots), plus `coding_spd`/`quality`/`vision_spd`/`vision_chars` (results go here after benchmarking). This is the single source of truth for plots and reports.

4. **Run coding benchmarks**: `python3 scripts/benchmark.py --models <id> ...` (or `--all-models`). For each model: 1 warmup + 3 timed runs per prompt. Median tok/s is recorded. Quality scored via pattern matchers (0.8 default for non-scored models).

5. **Run vision benchmarks**: `python3 scripts/benchmark.py --vision --models <id> ...`. Same pattern, but sends base64 image URI.

6. **Generate scatter plots**: `python3 scripts/generate_scatter.py --results-dir <dir>`. Plots are saved as `scatter_coding.png`, `scatter_vision.png`, `scatter_coding_efficiency.png`. Pass `--model-config` to override the default `references/model-config.json`.

7. **Generate final report**: `python3 scripts/generate_final_report.py` consolidates all CSVs into ranked tables.

## Pitfalls

- **Streaming endpoints inflate tok/s if elapsed is measured before the body read**: oMLX (and any SSE/chunked server) sends headers before the body finishes streaming. If `elapsed` is captured on entering the `urlopen` context (before `resp.read()`), it under-measures time and tok/s balloons (a 27B MLX model read as 255 tok/s when the real number was 34). Measure elapsed AFTER `resp.read()` completes. llama-swap buffers the full body so it was unaffected, but the fix is correct for every endpoint.
- **Qwen3 thinking models**: When `max_tokens=512`, Qwen3 thinking models put all output in `reasoning_content` and leave `content` empty — quality scores show 0.0. Fix: pass `--enable-thinking=false` with `--max-tokens 512`, or `--max-tokens 2048` with thinking enabled.
- **Vision URL vs base64**: llama-swap mmproj API does not support URL image fetching. URL-based image inputs fail with errors. Always use `data:image/png;base64,...`.
- **On-demand model loading**: llama-swap swaps models in on first request. Retry on HTTP 503/502/504 with 5s delay, up to 30 attempts.
- **4B models are deceptively fast**: Tiny models (qwen3-4b, phi4-mini) hit 110+ tok/s but quality is capped at 0.80 — speed without capability. Compare quality, not just speed.
- **Deleted model labels overlap**: On coding plot, the three 110+ tok/s 4B models cluster near each other. Use vision or efficiency plot for clearer separation.
- **Legend placement**: Always top-left, outside the plot area via `bbox_to_anchor=(0.02, 0.98)`, to avoid obscuring top-right performers.
- **Embeddings in the config**: `model-config.json` includes bge embedding/reranker entries (`type: "Embeddings"`). They plot as grey diamonds; they are not benchmarked (no coding/vision scores).

## Verification

```bash
# Verify all scripts run cleanly
python3 scripts/generate_scatter.py --output-dir /tmp/skill_test --results-dir /dev/null
python3 scripts/generate_final_report.py --model-config references/model-config.json
```

Check that `scatter_coding.png`, `scatter_vision.png`, and `scatter_coding_efficiency.png` are created with:
- Legend in top-left corner
- Deleted models as grey X markers with grey labels
- Model name annotations on active model bubbles
- Bubble size proportional to disk usage

---

Load methodology details on demand:
`skill_view(name='benchmark-model-fleet', file_path='references/benchmark-methodology.md')`

## lm-evaluation-harness Benchmarking

For evaluating LLMs on academic benchmarks (MMLU, GSM8K, HumanEval, HellaSwag, TruthfulQA, ARC, WinoGrande), use the EleutherAI lm-evaluation-harness — the industry standard used by HuggingFace and major labs. Full task reference and API/distributed/custom-task guides live in the archived `evaluating-llms-harness` skill under `~/.hermes/skills/.archive/`.

### Quick setup

```bash
pip install lm-eval
```

### Core reasoning benchmarks

- MMLU (Massive Multitask Language Understanding) — 57 subjects, multiple choice
- GSM8K — Grade school math word problems
- HellaSwag — Common sense reasoning
- TruthfulQA — Truthfulness and factuality
- ARC (AI2 Reasoning Challenge) — Science questions

### Code benchmarks

- HumanEval — Python code generation (164 problems)
- MBPP (Mostly Basic Python Problems) — Python coding

### Backend options

- **HuggingFace**: standard, slower
- **vLLM**: 5-10x faster with PagedAttention

### Common issues

- **Slow evaluation:** use vLLM backend, reduce num_fewshot to 0, or evaluate subset of MMLU (mmlu_stem)
- **Out of memory:** use --batch_size 1 or load_in_8bit=True
- **HumanEval not executing code:** pip install human-eval and use --allow_code_execution
- **Different results than reported:** verify num_fewshot count and exact task name

### When to use vs benchmark-model-fleet

- Use **lm-evaluation-harness** when: benchmarking on academic standards (MMLU, GSM8K), comparing model quality with standardized prompts, reporting reproducible metrics
- Use **benchmark-model-fleet** (this skill) when: auditing a local model fleet for speed/quality tradeoffs, right-sizing deployments, generating scatter plots of model performance
