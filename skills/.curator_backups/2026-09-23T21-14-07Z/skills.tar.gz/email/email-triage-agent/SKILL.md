---
name: email-triage-agent
description: Gmail inbox triage - classify + draft replies, staged for approval.
version: 1.0.0
author: Ionga
tags: [email, gmail, imap, himalaya, triage, draft, automation]
metadata:
  hermes:
    tags: [email, gmail, imap, himalaya, triage, draft, automation]
---

# Email Triage Agent

## When to Use

When you want a local LLM to triage your Gmail inbox, classify each thread, and draft reply emails that you review before sending. The agent runs Himalaya against your configured Gmail account, uses a local model (Devstral) to classify and draft, and stages everything as pending drafts for explicit approval.

## Prerequisites

- Himalaya v2 installed (`brew install himalaya`)
- Gmail App Password configured in `~/.hermes/.env` as `GMAIL_APP_PASSWORD`
- Himalaya config at `~/.config/himalaya/config.toml` with your Gmail account
- `studio-devstral-24b` model available via llama-swap

## Quick Start

```bash
# Triage unread inbox, draft replies, stage for approval
hermes chat --toolsets "email,file,terminal,skills" -q "/email-triage-agent run"

# Review staged drafts
hermes chat --toolsets "email,file,terminal,skills" -q "/email-triage-agent review"

# Send approved drafts (this triggers the send-gate)
hermes chat --toolsets "email,file,terminal,skills" -q "/email-triage-agent send"
```

## Configuration

Set the following in your Hermes profile or environment:

- `GMAIL_APP_PASSWORD` — 16-char Gmail App Password (in `~/.hermes/.env`)
- `EMAIL_TRIAGE_MODEL` — model to use (defaults to `studio-devstral-24b`)
- `EMAIL_TRIAGE_LIMIT` — max threads to process per run (default: 20)
- `EMAIL_TRIAGE_FOLDERS` — comma-separated IMAP folders to scan (default: `INBOX`)
- `EMAIL_DRAFT_DIR` — where staged drafts live (default: `~/.hermes/email-drafts`)
- `EMAIL_TRIAGE_STAGE_CLASSES` — classifications that get a draft file (default: `action,reply,urgent-reply`). Everything else is logged to `classified.log` instead of being staged.

## Workflow

### 1. Scan (Read)
- Himalaya lists unread envelopes from the configured Gmail account
- For each unread thread, fetches full message content via `himalaya message read`
- Extracts sender, subject, date, body text

### 2. Classify (Local LLM)
Using the local model, each thread is classified as:
- **urgent-reply** — needs a reply within 24h (people you know, time-sensitive)
- **reply** — needs a reply but not urgent
- **action** — needs action but no reply (review a doc, click a link, follow up)
- **waiting** — waiting on the sender, no action needed
- **reference** — keep for reference, no action
- **noise** — newsletters, promotions, alerts (no action)

### 3. Draft (Local LLM)
For threads classified as `urgent-reply` or `reply`:
- The local model drafts a reply in Patrick's voice
- Reply preserves thread context, answers every question, states uncertainty
- Draft is saved as a file: `EMAIL_DRAFT_DIR/<timestamp>_<id>.toml`
- Drafts include: original subject, reply-to, body, classification, confidence

### 4. Stage (Approval)
- Only `action`, `reply` and `urgent-reply` threads are written as draft files
- `noise`, `reference` and `waiting` are appended to `EMAIL_DRAFT_DIR/classified.log` and are NOT staged — this keeps the review queue to threads a human actually needs to see
- Drafts are NOT sent automatically
- Staged drafts sit in `EMAIL_DRAFT_DIR/` as pending
- Use `/email-triage-agent review` to see pending drafts
- Use `/email-triage-agent send` to send approved drafts (requires explicit approval)

### 5. Send (Gated)
- A deterministic shell script reads staged drafts
- You must explicitly mark each draft as approved in a JSON index
- Only approved drafts are sent via `himalaya message send`
- Each sent draft is logged to `EMAIL_DRAFT_DIR/sent.log`

### 6. Interactive review (chat seat only)

Buttons are the standard review surface, and they need NO platform code: the shipped `clarify`
tool renders as real Discord buttons (`ClarifyChoiceView`). Procedure:

1. `python3 triage.py review-choices` — emits JSON: one question per staged draft, three
   choices (`Discard draft` / `Approve and send` / `Leave staged`), chunked into calls of <=5
   questions because that is clarify's per-call cap.
2. Pass each chunk straight to the `clarify` tool.
3. Act on the answers: `triage.py discard <id>` for Discard, `triage.py approve <id>` for
   Approve. Approve only sets the flag; `triage.py send` is still the sole sender.
4. Reorder `choices` per batch before sending: the first choice is the one clarify labels
   "(Recommended)", so a mostly-noise queue leads with Discard and a real reply leads with Approve.

Cron CANNOT do this — `clarify` needs a live human to click, so the interactive review is a
chat-seat action. Cron keeps posting its text summary.

## Draft File Format

Staged drafts are TOML files:

```toml
id = "550695"
thread_id = "18f3a2..."
classification = "reply"
classification_confidence = 0.92
sender = "Bring a Trailer Updates <updates@bringatrailer.com>"
subject = "No Reserve: Arova-Porsche 212 Skibob now live on BaT"
date = "2026-08-30T20:32:00Z"
draft_to = "updates@bringatrailer.com"
draft_subject = "Re: No Reserve: Arova-Porsche 212 Skibob"
draft_body = "Hey — this is interesting, thanks for the heads up. ...
draft_created_at = "2026-08-30T21:45:00Z"
approved = false
```

## Pitfalls

- **`.processed_ids` must be MERGED, never overwritten.** A run only sees its own batch, so overwriting the file makes the next run forget every earlier thread. Those threads are still unread in Gmail, so they get re-fetched, re-classified and re-staged as duplicate drafts — the loop that made the queue grow without bound. `save_processed_ids` unions with `load_processed_ids` for exactly this reason; keep it that way.
- **Purging a draft does not change Gmail.** Discarded drafts leave the underlying thread unread. That is intended (the id stays in `.processed_ids` so it is not re-triaged), but do not report the email as handled or archived.
- **The draft directory is `~/.hermes/email-drafts`** (`EMAIL_DRAFT_DIR`). Any other path written into a report is wrong: earlier runs invented `~/.hermes/email-draft-agent/email-draft-dir`, which has never existed. Reports must copy the `Draft dir: <path>` line the script prints, never restate it from memory.
- **`drafts.json` is a per-run index, not a queue.** `run` overwrites it with the current batch. The real queue is the `draft_*.toml` glob that `review` counts, so the index and the queue drift apart after the first run.
- **`discard <envelope_id>` removes staged drafts** (logs to `discarded.log`). The id stays in `.processed_ids`, so a discarded thread is NOT re-triaged and a false-positive draft cannot come back next run.
- **Never trust a `reply` classification on a no-reply sender.** Marketing nudges from card issuers and banks are sent from unmonitored inboxes that say "do not reply to this email". Read the body, then discard the draft instead of staging a reply that goes nowhere.
- **Noise threads still get a draft file written**, with an empty body and sometimes a populated `draft_to`. The send-gate skips empty bodies, so nothing blank can send, but treat a reply target on a noise draft as noise itself.
- **Buttons already exist; do not build a new Discord view.** The discord adapter ships `_HermesView` plus `ExecApprovalView` (Allow/Deny), `ChoicePickerView`, `ClarifyChoiceView`, `ModelPickerView`, `SlashConfirmView`, `UpdatePromptView`. Agent-initiated buttons come from the `clarify` tool. Reaching for a bespoke `custom_id` router or a new adapter view is unnecessary surface.
- **`clarify` caps: 5 questions per call, 4 choices per question, and it needs a live user.** `review-choices` batches to 5; anything more becomes a second call. Never call it from cron.
- **Tuning is deferred, not shipped.** Four levers are defined (prompt sharpening, confidence gate, sender allowlist, post-classifier keyword promotion) but not implemented. As of 2026-09-19 Patrick chose hand triage, so the cron summary + chat-seat clarify review is the control loop. Do not re-propose fine-tune / precision-recall calibration — it is out of scope at AE bandwidth.
- **Gmail throttling:** IMAP LIST over a large mailbox can be slow; the limit flag controls batch size
- **Env var expansion:** Himalaya v2 doesn't expand `${VAR}` in config — use `password.command = ["sh", "-c", "echo $GMAIL_APP_PASSWORD"]`
- **Large emails:** Some senders (Credit Karma, Bring a Trailer) send 100KiB+ messages — the model context window may truncate; this is expected, not a bug
- **Don't trust classification blindly:** always review the draft content, not just the classification
- **Never auto-send:** the send-gate script must be invoked explicitly

## Verification

```bash
# Check staged drafts (only actionable threads)
ls -la ~/.hermes/email-drafts/

# Non-actionable threads: logged, not staged
tail -20 ~/.hermes/email-drafts/classified.log

# Check send log
cat ~/.hermes/email-drafts/sent.log

# Verify IMAP still working
GMAIL_APP_PASSWORD="…" himalaya envelope list -a gmail
```

## Commands

- `/email-triage-agent run` — scan inbox, classify, draft, stage
- `/email-triage-agent review` — list pending drafts with classifications
- `python3 triage.py discard <envelope_id> [...]` — delete staged drafts for those threads (use for false positives)
- `python3 triage.py approve <envelope_id> [...]` — mark drafts approved (sets `approved = true`, logs to `approved.log`). Reversible, and sends NOTHING; actual delivery still requires `triage.py send`.
- `python3 triage.py review-choices` — emit `clarify` question JSON for the whole staged queue (batched <=5 per call), for the interactive button review.
- `/email-triage-agent send` — send approved drafts via send-gate
- `/email-triage-agent test-model` — verify the local model is reachable
