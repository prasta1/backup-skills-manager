#!/usr/bin/env python3
"""
Email Triage Agent — scan Gmail inbox, classify threads, draft replies, stage for approval.

Usage:
    triage.py run       — scan + classify + draft + stage
    triage.py review    — list pending drafts
    triage.py send      — send approved drafts (requires send-gate approval)
    triage.py test-model — verify the local model is reachable

Uses Himalaya v2 (Homebrew) for IMAP access, Devstral local model for classification/drafting.
"""
import json
import os
import re
import sys
import subprocess
from datetime import datetime, timezone
from pathlib import Path

# ── Config ──
DRAFT_DIR = Path(os.environ.get("EMAIL_DRAFT_DIR", "~/.hermes/email-drafts")).expanduser()
MODEL = os.environ.get("EMAIL_TRIAGE_MODEL", "ms-devstral-24b")
LIMIT = int(os.environ.get("EMAIL_TRIAGE_LIMIT", "20"))
ACCOUNT = "gmail"
LLAMA_SWAP_URL = "http://127.0.0.1:9292/v1/chat/completions"

# Only these classifications get a staged draft file. Everything else (noise,
# reference, waiting) is recorded as a log line instead, so the review queue
# holds only threads worth a human look. Override with EMAIL_TRIAGE_STAGE_CLASSES.
STAGE_CLASSES = {
    c.strip() for c in os.environ.get(
        "EMAIL_TRIAGE_STAGE_CLASSES", "action,reply,urgent-reply"
    ).split(",") if c.strip()
}

# Use Homebrew himalaya (v2.1.0), not the broken nix one
HIMALAYA_BIN = "/opt/homebrew/bin/himalaya"

DRAFT_DIR.mkdir(parents=True, exist_ok=True)
SENT_LOG = DRAFT_DIR / "sent.log"
DISCARD_LOG = DRAFT_DIR / "discarded.log"
APPROVED_LOG = DRAFT_DIR / "approved.log"
CLASSIFIED_LOG = DRAFT_DIR / "classified.log"
INDEX_FILE = DRAFT_DIR / "drafts.json"


def himalaya_json(args, timeout_s=60):
    """Run himalaya CLI with --json output. Returns parsed JSON."""
    env = dict(os.environ)
    result = subprocess.run(
        [HIMALAYA_BIN, "--json", *args],
        capture_output=True, text=True, env=env, timeout=timeout_s
    )
    if result.returncode != 0:
        raise RuntimeError(f"Himalaya error: {result.stderr or result.stdout}")
    return json.loads(result.stdout)


def himalaya_text(args, timeout_s=60):
    """Run himalaya CLI without JSON output."""
    env = dict(os.environ)
    result = subprocess.run(
        [HIMALAYA_BIN, *args],
        capture_output=True, text=True, env=env, timeout=timeout_s
    )
    if result.returncode != 0:
        raise RuntimeError(f"Himalaya error: {result.stderr or result.stdout}")
    return result.stdout


def llm_request(prompt, max_tokens=2048, temp=0.7):
    """Call the local model via llama-swap."""
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": temp,
    }
    result = subprocess.run(
        ["curl", "-s", "--max-time", "120", "-X", "POST",
         LLAMA_SWAP_URL, "-H", "Content-Type: application/json",
         "-d", json.dumps(payload)],
        capture_output=True, text=True, timeout=130
    )
    if result.returncode != 0 or not result.stdout:
        raise RuntimeError(f"LLM call failed: {result.stderr}")
    data = json.loads(result.stdout)
    return data["choices"][0]["message"]["content"].strip()


PROCESSED_FILE = DRAFT_DIR / ".processed_ids"
MAX_TRACKED_IDS = 2000


def load_processed_ids():
    """Load set of envelope IDs we've already triaged."""
    if PROCESSED_FILE.exists():
        return set(PROCESSED_FILE.read_text().strip().splitlines())
    return set()


def save_processed_ids(ids):
    """Persist processed envelope IDs by MERGING with those already tracked.

    Do not overwrite. A run only ever sees its own batch, so overwriting makes
    the next run forget every thread triaged earlier; those threads are still
    unread in Gmail, so they get re-fetched, re-classified and re-staged as
    duplicate drafts — the feedback loop that made the queue grow without bound.
    """
    tracked = load_processed_ids() | {str(i) for i in ids if i}
    ordered = sorted(tracked, key=lambda x: (int(x) if x.isdigit() else 0, x))
    PROCESSED_FILE.write_text("\n".join(ordered[-MAX_TRACKED_IDS:]) + "\n")


def fetch_new_envelopes():
    """Get recent email envelopes from Gmail INBOX, skipping already-processed ones."""
    print("📥 Fetching recent envelopes from Gmail...")
    data = himalaya_json([
        "envelope", "list", "-a", ACCOUNT,
        "--page-size", str(LIMIT * 3)
    ], timeout_s=60)

    if isinstance(data, dict) and "envelopes" in data:
        envelopes = data["envelopes"]
    elif isinstance(data, dict) and "data" in data:
        envelopes = data["data"]
    elif isinstance(data, list):
        envelopes = data
    else:
        envelopes = []

    processed = load_processed_ids()
    # Himalaya v2: flags is [{"raw": "\\Seen"}, {"raw": "\\Answered"}, ...]
    def is_unseen(env):
        flags = env.get("flags", [])
        for f in flags:
            if isinstance(f, dict):
                raw = f.get("raw", "").lower()
                if "unseen" in raw:
                    return True
            elif isinstance(f, str) and "unseen" in f.lower():
                return True
        return False

    # Prefer truly unseen, but Gmail IMAP sometimes doesn't expose \Unseen reliably.
    # Fall back to "not flagged as Seen" for robustness.
    unseen = [e for e in envelopes if is_unseen(e)]
    if len(unseen) < len(envelopes):
        # Include ones without flags (often unseen on Gmail IMAP)
        noflag = [e for e in envelopes if is_unseen(e) or not e.get("flags")]
        print(f"  Found {len(envelopes)} envelopes — {len(unseen)} unseen, {len(noflag)} without \\Seen flag")
        candidates = noflag
    else:
        print(f"  Found {len(unseen)} unseen envelopes out of {len(envelopes)} total")
        candidates = unseen

    # Filter out already-processed IDs
    new = [e for e in candidates if e.get("id") not in processed]
    print(f"  New (unprocessed): {len(new)} — skipping {len(candidates) - len(new)} already processed")
    return new[:LIMIT]


def fetch_message_body(message_id):
    """Fetch full message body by envelope ID."""
    try:
        return himalaya_text(["message", "read", "-a", ACCOUNT, message_id], timeout_s=60)
    except Exception as e:
        return f"[Could not fetch full message: {e}]"


def classify_and_draft(envelope):
    """Use local LLM to classify + draft reply."""
    msg_id = envelope.get("id", "")
    subject = envelope.get("subject", "(no subject)")

    from_list = envelope.get("from", [])
    if isinstance(from_list, list) and from_list:
        from_obj = from_list[0]
        if isinstance(from_obj, dict):
            from_name = from_obj.get("name", "") or ""
            from_email = from_obj.get("email", "") or ""
        else:
            from_name = str(from_list)
            from_email = ""
    else:
        from_name = str(from_list)
        from_email = ""

    date_str = envelope.get("date", "")
    sender_display = f"{from_name} <{from_email}>" if from_email else from_name

    body_text = fetch_message_body(msg_id)
    if len(body_text) > 8000:
        body_text = body_text[:8000] + "\n...[truncated]"

    prompt = f"""You are an email triage assistant working for Patrick. Analyze the following email and return ONLY valid JSON.

Email:
---
From: {sender_display}
Subject: {subject}
Date: {date_str}

{body_text}
---

{{"classification": "reply", "confidence": 0.92, "reply_to": "{from_email}", "reply_subject": "Re: {subject}", "reply_body": "Concise reply in Patrick's voice.", "reasoning": "Brief explanation of classification."}}

Classification options: urgent-reply, reply, action, waiting, reference, noise.
- newsletters/promotions/automated → noise
- job alerts, LinkedIn, shopping → noise or reference
- personal/important senders → reply or urgent-reply
- Never fabricate sender email — use the one above
- reply_subject = "Re: " + original subject
If not reply-worthy, set reply_body to empty string. Return ONLY JSON."""

    print(f"  ⏳ Classifying: {subject[:60]}...")
    try:
        raw = llm_request(prompt, max_tokens=2048, temp=0.3)
        # Strip any non-JSON wrapper — find first { and last }
        first_brace = raw.find("{")
        last_brace = raw.rfind("}")
        if first_brace >= 0 and last_brace > first_brace:
            clean = raw[first_brace:last_brace + 1]
        else:
            clean = raw
        data = json.loads(clean)
        return data
    except Exception as e:
        print(f"  ❌ LLM error on {msg_id}: {e}")
        return {
            "classification": "reference",
            "confidence": 0.0,
            "reply_to": from_email,
            "reply_subject": f"Re: {subject}",
            "reply_body": "",
            "reasoning": f"LLM error: {e}",
        }


def save_draft(envelope, result):
    """Save a classified/drafted email as a staged TOML file."""
    msg_id = envelope.get("id", "unknown")
    now = datetime.now(timezone.utc).isoformat()
    from_list = envelope.get("from", [])
    sender_str = json.dumps(from_list) if from_list else ""

    draft = {
        "id": msg_id,
        "classification": result.get("classification", "reference"),
        "confidence": result.get("confidence", 0.0),
        "sender": sender_str,
        "subject": envelope.get("subject", ""),
        "date": envelope.get("date", ""),
        "reply_to": result.get("reply_to", ""),
        "reply_subject": result.get("reply_subject", ""),
        "reply_body": result.get("reply_body", ""),
        "reasoning": result.get("reasoning", ""),
        "draft_created_at": now,
        "approved": False,
    }

    filename = DRAFT_DIR / f"draft_{msg_id}_{int(datetime.now().timestamp())}.toml"
    with open(filename, "w") as f:
        f.write(f'# Staged email draft — not yet approved for sending\n')
        f.write(f'# Created: {now}\n')
        f.write(f'# Classification: {draft["classification"]} ({draft["confidence"] * 100:.0f}% confident)\n')
        f.write(f'# Reason: {draft["reasoning"]}\n\n')
        f.write(f'id = "{draft["id"]}"\n')
        f.write(f'classification = "{draft["classification"]}"\n')
        f.write(f'classification_confidence = {draft["confidence"]}\n')
        f.write(f'sender = {draft["sender"]}\n')
        f.write(f'subject = "{draft["subject"]}"\n')
        f.write(f'date = "{draft["date"]}"\n')
        f.write(f'draft_to = "{draft["reply_to"]}"\n')
        f.write(f'draft_subject = "{draft["reply_subject"]}"\n')
        f.write(f'draft_body = """\n{draft["reply_body"]}\n"""\n')
        f.write(f'draft_created_at = "{draft["draft_created_at"]}"\n')
        f.write(f'approved = false\n')

    status = draft["reply_body"][:0] if not draft["reply_body"] else "📝"
    print(f"  {status} Staged: {draft['classification']} | {draft['subject'][:50]}")
    return filename


def log_classification(env, result):
    """Record a non-actionable thread as a log line instead of a staged draft."""
    from_list = env.get("from", [])
    sender = ""
    if from_list:
        first = from_list[0] if isinstance(from_list, list) else from_list
        sender = first.get("email", "") if isinstance(first, dict) else str(first)
    subject = env.get("subject", "").replace("\n", " ")
    with open(CLASSIFIED_LOG, "a") as log:
        log.write(
            f"{datetime.now(timezone.utc).isoformat()} | {result.get('classification', 'reference')} "
            f"| {env.get('id', '')} | {sender} | {subject}\n"
        )
    print(f"  ·  Logged ({result.get('classification', 'reference')}): {subject[:60]}")
    return None


def cmd_run():
    """Main: scan, classify, draft, stage."""
    print("=" * 60)
    print(f"📧 Email Triage Agent — run @ {datetime.now().isoformat()}")
    print(f"   Model: {MODEL} | Draft dir: {DRAFT_DIR}")
    print(f"   Staging: {','.join(sorted(STAGE_CLASSES))} (others logged, not staged)")
    print("=" * 60)

    envelopes = fetch_new_envelopes()
    if not envelopes:
        print("📭 No new emails to triage. Nothing to do.")
        return

    results = []
    processed_ids = set()
    for env in envelopes:
        result = classify_and_draft(env)
        processed_ids.add(env.get("id"))
        if result["classification"] in STAGE_CLASSES:
            draft_file = save_draft(env, result)
            staged = True
        else:
            draft_file = log_classification(env, result)
            staged = False
        results.append({
            "envelope_id": env.get("id"),
            "subject": env.get("subject", ""),
            "classification": result["classification"],
            "has_reply": bool(result.get("reply_body", "")),
            "staged": staged,
            "draft_file": str(draft_file) if draft_file else None,
        })

    with open(INDEX_FILE, "w") as f:
        json.dump(results, f, indent=2)

    print("\n" + "=" * 60)
    print("📊 Summary")
    print("=" * 60)
    by_class = {}
    for r in results:
        c = r["classification"]
        by_class[c] = by_class.get(c, 0) + 1
    for cls, count in sorted(by_class.items(), key=lambda x: -x[1]):
        print(f"  {cls}: {count}")
    reply_count = sum(1 for r in results if r["has_reply"])
    staged_count = sum(1 for r in results if r["staged"])
    print(f"\n  Total threads: {len(results)}")
    print(f"  Drafts with replies: {reply_count}")
    print(f"  Staged drafts: {staged_count}  (logged, not staged: {len(results) - staged_count})")
    print(f"  Draft dir: {DRAFT_DIR}")
    print(f"  Classified log: {CLASSIFIED_LOG}")
    print(f"  Index: {INDEX_FILE}")
    print(f"\n  Review: python3 {__file__} review")
    print(f"  Send:   python3 {__file__} send  (only approved drafts)")

    # Persist processed IDs to avoid re-triaging
    save_processed_ids(processed_ids)


def cmd_review():
    """List all staged drafts."""
    drafts = sorted(DRAFT_DIR.glob("draft_*.toml"))
    if not drafts:
        print("📭 No staged drafts found.")
        return

    print(f"📋 {len(drafts)} staged drafts in {DRAFT_DIR}:\n")
    for f in drafts:
        content = f.read_text()
        approved = "approved = true" in content
        status = "✅ APPROVED" if approved else "⏳ PENDING"
        subject = re.search(r'subject = "(.*)"', content)
        cls = re.search(r'classification = "(.*)"', content)
        conf = re.search(r'classification_confidence = (.*)', content)
        sender = re.search(r'sender = (\[.*?\])', content, re.DOTALL)

        subj = (subject.group(1)[:60] if subject else "(no subject)")
        c = cls.group(1) if cls else "?"
        c2 = conf.group(1) if conf else "?"
        s = (sender.group(1)[:50] if sender else "?")

        print(f"  [{status}] {c} ({c2})")
        print(f"    From: {s}")
        print(f"    Subj: {subj}")
        print(f"    File: {f.name}")
        print()

    print(f"Draft dir: {DRAFT_DIR}")
    print(f"Discard:   python3 {__file__} discard <envelope_id> [...]")


def cmd_discard(ids):
    """Delete staged drafts for the given envelope ids and drop them from the index.

    The envelope id stays in .processed_ids so the thread is NOT re-triaged and the
    false positive cannot come back on the next run.
    """
    if not ids:
        print("Usage: triage.py discard <envelope_id> [...]")
        return 1

    dropped, missing = [], []
    for env_id in ids:
        matches = sorted(DRAFT_DIR.glob(f"draft_{env_id}_*.toml"))
        if not matches:
            missing.append(env_id)
            continue
        for f in matches:
            f.unlink()
            dropped.append(f.name)
        with open(DISCARD_LOG, "a") as log:
            log.write(f"{datetime.now(timezone.utc).isoformat()} | DISCARDED | {env_id} | {','.join(m.name for m in matches)}\n")

    if INDEX_FILE.exists():
        try:
            index = json.loads(INDEX_FILE.read_text())
            kept = [e for e in index if str(e.get("envelope_id")) not in set(ids)]
            INDEX_FILE.write_text(json.dumps(kept, indent=2) + "\n")
            print(f"  Index: {len(index)} → {len(kept)} entries")
        except Exception as e:
            print(f"  ⚠️  Index not updated: {e}")

    for n in dropped:
        print(f"  🗑️  Deleted: {n}")
    for m in missing:
        print(f"  ⚠️  No draft found for envelope {m}")

    print(f"\n📊 Discarded {len(dropped)} draft file(s) for {len(ids) - len(missing)} envelope(s)")
    print(f"   Log: {DISCARD_LOG}")
    print(f"   Note: envelope ids remain in .processed_ids — these threads will not be re-triaged.")
    return 0


def cmd_approve(ids):
    """Mark staged drafts as approved (gated send: does NOT send anything).

    Approval is a reversible local flag. Actual sending stays behind `triage.py send`,
    so a misclick can never put mail on the wire.
    """
    if not ids:
        print("Usage: triage.py approve <envelope_id> [...]")
        return 1

    approved, missing = [], []
    for env_id in ids:
        matches = sorted(DRAFT_DIR.glob(f"draft_{env_id}_*.toml"))
        if not matches:
            missing.append(env_id)
            continue
        for f in matches:
            content = f.read_text()
            if "approved = true" in content:
                print(f"  ↺  Already approved: {f.name}")
                approved.append(f.name)
                continue
            f.write_text(content.replace("approved = false", "approved = true", 1))
            with open(APPROVED_LOG, "a") as log:
                log.write(f"{datetime.now(timezone.utc).isoformat()} | APPROVED | {env_id} | {f.name}\n")
            approved.append(f.name)
            print(f"  👍 Approved: {f.name}")

    for m in missing:
        print(f"  ⚠️  No draft found for envelope {m}")

    print(f"\n📊 Approved {len(approved)} draft(s). Nothing was sent.")
    print(f"   Log: {APPROVED_LOG}")
    print(f"   Send: python3 {__file__} send  (only approved drafts)")
    return 0


def cmd_review_choices(limit=5):
    """Emit clarify-tool questions for the staged queue, ready to pass straight to `clarify`.

    The interactive review runs on the chat seat, not in cron: `clarify` needs a live user
    to click. One question per draft, three choices each, batched into calls of <=5
    questions (clarify's per-call cap). Output is JSON: a list of calls, each a list of
    question objects.
    """
    drafts = sorted(DRAFT_DIR.glob("draft_*.toml"))
    if not drafts:
        print("[]")
        return 0

    questions = []
    for f in drafts:
        content = f.read_text()
        env_id = f.name.split("_")[1]
        subj = (re.search(r'^subject = "(.*)"', content, re.M) or [None, "(no subject)"])[1]
        cls = (re.search(r'^classification = "(.*)"', content, re.M) or [None, "?"])[1]
        to = (re.search(r'^draft_to = "(.*)"', content, re.M) or [None, ""])[1]
        target = f" to {to}" if to else ""
        questions.append({
            "question": (
                f"[{env_id}] {cls}: {subj[:70]}{target}. What should I do with this draft?"
            ),
            # First choice is labelled "(Recommended)" by the clarify tool. Order it per
            # batch: mostly-noise queues lead with Discard, a real reply leads with Approve.
            "choices": ["Discard draft", "Approve and send", "Leave staged"],
        })

    calls = [questions[i:i + limit] for i in range(0, len(questions), limit)]
    print(json.dumps(calls, indent=2))
    print(f"\n# {len(drafts)} staged draft(s) in {DRAFT_DIR}", file=sys.stderr)
    print(f"# {len(calls)} clarify call(s), max {limit} questions each", file=sys.stderr)
    return 0


def cmd_send():
    """Send approved drafts via himalaya."""
    drafts = sorted(DRAFT_DIR.glob("draft_*.toml"))
    if not drafts:
        print("📭 No drafts found.")
        return

    sent = 0
    skipped = 0
    for f in drafts:
        content = f.read_text()
        if "approved = true" not in content:
            print(f"  ⏸️  Skipped (not approved): {f.name}")
            skipped += 1
            continue

        to_match = re.search(r'draft_to = "(.*)"', content)
        subj_match = re.search(r'draft_subject = "(.*)"', content)
        body_match = re.search(r'draft_body = """\n(.*)\n"""', content, re.DOTALL)

        to_addr = to_match.group(1) if to_match else ""
        subject = subj_match.group(1) if subj_match else ""
        body = body_match.group(1) if body_match else ""

        if not to_addr or not body:
            print(f"  ❌ Missing fields in {f.name}")
            skipped += 1
            continue

        print(f"  📤 Sending: {subject[:50]} → {to_addr}")
        try:
            result = subprocess.run(
                [HIMALAYA_BIN, "message", "send", "-a", "gmail",
                 "--from", "Patrick Ruster <ruster.patrick@gmail.com>",
                 "--to", to_addr,
                 "--subject", subject],
                input=body, capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                print(f"  ✅ Sent: {subject[:50]}")
                with open(SENT_LOG, "a") as log:
                    log.write(f"{datetime.now(timezone.utc).isoformat()} | SENT | {subject} | {to_addr} | {f.name}\n")
                f.unlink()
                sent += 1
            else:
                print(f"  ❌ Failed: {result.stderr[:200]}")
                skipped += 1
        except Exception as e:
            print(f"  ❌ Error: {e}")
            skipped += 1

    print(f"\n📊 Send results: {sent} sent, {skipped} skipped")
    if sent:
        print(f"   Log: {SENT_LOG}")


def cmd_test_model():
    """Verify the local model is reachable."""
    print(f"Testing model: {MODEL}")
    try:
        result = llm_request(
            "Reply with exactly: DEVSTRAL_EMAIL_TEST_OK",
            max_tokens=8, temp=0.1
        )
        print(f"✅ Response: {result}")
        if "DEVSTRAL_EMAIL_TEST_OK" in result:
            print(f"✅ Model {MODEL} is reachable and responsive.")
            return True
        else:
            print(f"⚠️ Model responded but content unexpected.")
            return False
    except Exception as e:
        print(f"❌ Model test failed: {e}")
        return False


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: triage.py [run|review|review-choices|approve <envelope_id> [...]|discard <envelope_id> [...]|send|test-model]")
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "run":
        cmd_run()
    elif cmd == "review":
        cmd_review()
    elif cmd == "discard":
        sys.exit(cmd_discard(sys.argv[2:]))
    elif cmd == "approve":
        sys.exit(cmd_approve(sys.argv[2:]))
    elif cmd == "review-choices":
        cmd_review_choices()
    elif cmd == "send":
        cmd_send()
    elif cmd == "test-model":
        ok = cmd_test_model()
        sys.exit(0 if ok else 1)
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)
